"""the 60 — v8 geometry.  build123d algebra mode."""
import math, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build123d import *
from params import *

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
os.makedirs(OUT, exist_ok=True)
D = math.radians

# ---------------------------------------------------------------- helpers
def cyl(r, z0, z1):
    return Pos(0, 0, z0) * Cylinder(r, z1 - z0, align=(Align.CENTER, Align.CENTER, Align.MIN))
def tube(ro, ri, z0, z1, eps=0.01):
    return cyl(ro, z0, z1) - cyl(ri, z0 - eps, z1 + eps)
def frustum(r0, r1, z0, z1):
    return Pos(0, 0, z0) * Cone(r0, r1, z1 - z0, align=(Align.CENTER, Align.CENTER, Align.MIN))
def polar(az, r, z=0.0):
    a = D(az); return Pos(r * math.cos(a), r * math.sin(a), z) * Rot(0, 0, az)
def blk(radial, tangential, z0, z1, az, r, t=0.0):
    return polar(az, r, (z0 + z1) / 2) * Pos(0, t, 0) * Box(radial, tangential, z1 - z0)
def xyblk(x0, x1, y0, y1, z0, z1):
    return Pos((x0+x1)/2, (y0+y1)/2, (z0+z1)/2) * Box(x1-x0, y1-y0, z1-z0)
def zbore(d, z0, z1, az=0.0, r=0.0):
    return polar(az, r, z0) * Cylinder(d/2, z1-z0, align=(Align.CENTER, Align.CENTER, Align.MIN))
def rbore(d, r0, r1, az, z, t=0.0):
    a = D(az)
    return (Pos(0,0,z) * Rot(0,0,az) * Pos((r0+r1)/2, t, 0) * Rot(0,90,0)
            * Cylinder(d/2, r1-r0, align=(Align.CENTER, Align.CENTER, Align.CENTER)))
def sector(az_mid, arc, r_out, z0, z1, r_in=0.0):
    """wedge between two radii over an arc, centred on az_mid"""
    n = max(8, int(arc/4))
    pts = []
    for i in range(n+1):
        a = D(az_mid - arc/2 + arc*i/n); pts.append((r_out*math.cos(a), r_out*math.sin(a)))
    for i in range(n, -1, -1):
        a = D(az_mid - arc/2 + arc*i/n); pts.append((max(r_in,0.01)*math.cos(a), max(r_in,0.01)*math.sin(a)))
    with BuildPart() as bp:
        with BuildSketch(Plane.XY.offset(z0)) as sk:
            with BuildLine():
                Polyline(*pts, close=True)
            make_face()
        extrude(amount=z1-z0)
    return bp.part
def ring_of(fn, azs):
    out = None
    for az in azs:
        s = fn(az); out = s if out is None else out + s
    return out

# ---------------------------------------------------------------- knob
def body_profile():
    """one piece: crown lip, straight bore, V-groove, skirt, chamfers"""
    rb, rk, ri, rg = R_SKIRT_BORE, R_KNOB, R_CROWN_IN, R_GROOVE_ROOT
    zs, zt, zcb = Z_SKIRT_BOT, Z_KNOB_TOP, Z_CROWN_BOT
    f = WHEEL_V_FLAT / 2
    return [(rb, zs), (rk - CH_BOT, zs), (rk, zs + CH_BOT),
            (rk, zt - CH_TOP), (rk - CH_TOP, zt),
            (ri + CH_IN, zt), (ri, zt - CH_IN),
            (ri, zcb), (rb, zcb),
            (rb, Z_GROOVE1), (rg, Z_RIDGE_MID + f), (rg, Z_RIDGE_MID - f), (rb, Z_GROOVE0)]
def revolve_profile(pts):
    return revolve(Plane.XZ * Polygon(*pts, align=None), Axis.Z)

def knob_body_smooth():
    """The turned shape only: lip, bore, groove, skirt, chamfers.  No knurl."""
    return revolve_profile(body_profile())

def knob_body(knurl=None):
    """The real knob.  The diamond knurl is the only surface the hand ever
    touches, so it is part of the part, not a drawing note.  It is cut band by
    band in knurl.py (subprocess + BREP checkpoints) and cached; this returns
    the cached solid.  Pass knurl=False for the bare turned shape."""
    if (KNURL_ON if knurl is None else knurl):
        from knurl import apply_knurl
        return apply_knurl(None)
    return knob_body_smooth()

# ---------------------------------------------------------------- base plate
def base_plate():
    p = cyl(PLATE_R, 0, BASE_PLATE_T)
    p -= zbore(GIM_PLATE_HOLE_D, -1, BASE_PLATE_T + 1, GIM_AZ, GIM_R)     # gimbal drops through
    p -= Pos(SPEAKER_OFF,0,0)*zbore(SPEAKER_APERTURE, -1, BASE_PLATE_T + 1)   # speaker fires down
    p -= sector(AZ_PORTS, 42.0, PLATE_R + 2, -1, BASE_PLATE_T + 1, r_in=TUNNEL_R_BACK)  # cable notch
    for az in PLATE_SCREW_AZ:
        p -= zbore(3.4, -1, BASE_PLATE_T + 1, az, PLATE_SCREW_R)
    return p

# ---------------------------------------------------------------- base shell
def gimbal_keepout():
    """everything the motor and its band need free"""
    k = zbore(GIM_OD + 2.0, Z_GIM_BOT - 0.5, Z_GIM_TOP + 0.6, GIM_AZ, GIM_R)
    k += sector(GIM_AZ, 26.0, R_SKIRT_BORE + 0.5, Z_BELL_BOT - 0.5, Z_GIM_TOP + 0.6, r_in=GIM_R)
    return k

def base_shell():
    s = tube(PLINTH_R_OUT, PLINTH_R_IN, Z_PLATE_TOP, Z_PLINTH_TOP)        # plinth
    s += tube(LED_WALL_R_OUT, LED_WALL_R_IN, Z_PLINTH_TOP, HALO_Z1)       # LED wall
    s += tube(R_LEDGE_OUT, R_LEDGE_IN, Z_LEDGE_BOT, Z_LEDGE_TOP)          # ledge
    s += tube(LED_WALL_R_OUT, R_LEDGE_IN, HALO_Z1, Z_LEDGE_BOT)           # outer wall up to the ledge
    s += tube(R_INNER_ROOF, 22.0, Z_LEDGE_TOP - 1.4, Z_LEDGE_TOP - 0.4)   # inner roof over the electronics
    s += Pos(SPEAKER_OFF,0,0)*cyl(SPEAKER_D/2 + 2.0, Z_PLATE_TOP, Z_PLATE_TOP + SPEAKER_T + 1.0)
    s -= Pos(SPEAKER_OFF,0,0)*cyl(SPEAKER_D/2 + 0.3, Z_PLATE_TOP - 1, Z_PLATE_TOP + SPEAKER_T + 0.3)
    # floor ribs tying the cradle, the screw bosses and the outer wall together
    for az in (40, 80, 120, 160, 220, 260, 320):
        s += blk(LED_WALL_R_IN - SPEAKER_D/2 - 2, 3.0, Z_PLATE_TOP, Z_PLATE_TOP + 2.2,
                 az, (SPEAKER_D/2 + 2 + LED_WALL_R_IN) / 2)
    s += tube(LED_WALL_R_IN, LED_WALL_R_IN - 2.0, Z_PLATE_TOP, HALO_Z1)  # inner skin of the wall
    for az in WHEEL_AZ:                                                   # wheel posts
        s += zbore(WHEEL_POST_D, Z_LEDGE_TOP, Z_POST_TOP_BUSH, az, BUSH_R)
        s -= zbore(BUSH_D + 0.1, Z_LEDGE_BOT - 1, Z_POST_TOP_BUSH + 1, az, BUSH_R)
    for az in DISC_MOUNT_AZ:                                              # display posts
        s += zbore(DISC_POST_D, Z_LEDGE_TOP, Z_DISC_BOT - 0.2, az, DISC_POST_R)
        s -= zbore(4.3, Z_LEDGE_BOT - 1, Z_DISC_BOT + 1, az, DISC_POST_R)
    for az in PLATE_SCREW_AZ:                                             # M3 inserts, ribbed out to the wall
        s += zbore(6.0, Z_PLATE_TOP, Z_PLATE_TOP + INSERT_M3_L + 1.5, az, PLATE_SCREW_R)
        s += blk(LED_WALL_R_IN - PLATE_SCREW_R + 1.0, 4.0, Z_PLATE_TOP, Z_PLATE_TOP + 2.2,
                 az, (PLATE_SCREW_R + LED_WALL_R_IN) / 2)
        s -= zbore(INSERT_M3_D, Z_PLATE_TOP - 0.5, Z_PLATE_TOP + INSERT_M3_L + 0.3, az, PLATE_SCREW_R)
    s -= sector(AZ_PORTS, 44.0, PLATE_R + 2, Z_PLATE_TOP - 1, Z_PLINTH_TOP + 0.01, r_in=TUNNEL_R_BACK)
    s -= blk(CLUTCH_SERVO_W + 1.0, CLUTCH_SERVO_L + 1.0, Z_PLATE_TOP - 1,
             Z_PLATE_TOP + CLUTCH_SERVO_H + 0.4, CLUTCH_AZ, CLUTCH_R)          # servo pocket
    s -= gimbal_keepout()                                                 # notch for the motor
    s -= Pos(SPEAKER_OFF,0,0)*cyl(SPEAKER_APERTURE/2, -1, Z_PLATE_TOP + 0.01)
    return s

def halo_diffuser():
    with BuildPart() as bp:
        with BuildSketch(Plane.XZ) as sk:
            with BuildLine():
                Polyline((DIFF_R_IN, HALO_Z0), (DIFF_R_OUT_BOT, HALO_Z0),
                         (DIFF_R_OUT_TOP, HALO_Z1), (DIFF_R_IN, HALO_Z1), close=True)
            make_face()
        revolve(axis=Axis.Z)
    return bp.part

# ---------------------------------------------------------------- wheels
def wheel_collar(az=None):
    h = WHEEL_W
    z0 = Z_WHEEL0 if az is not None else 0.0
    r = WHEEL_AXIS_R if az is not None else 0.0
    a = az if az is not None else 0.0
    with BuildPart() as bp:
        with BuildSketch(Plane.XZ) as sk:
            with BuildLine():
                Polyline((WHEEL_OD/2 - WHEEL_V_H, 0), (WHEEL_OD/2, h/2 - WHEEL_V_FLAT/2),
                         (WHEEL_OD/2, h/2 + WHEEL_V_FLAT/2), (WHEEL_OD/2 - WHEEL_V_H, h),
                         (WHEEL_BORE/2 + 1.6, h), (WHEEL_BORE/2 + 1.6, 0), close=True)
            make_face()
        revolve(axis=Axis.Z)
    return polar(a, r, z0) * bp.part

def ecc_bush(az=None, retracted=False):
    e = -WHEEL_ECC if retracted else WHEEL_ECC
    b = Pos(0,0,0) * Cylinder(BUSH_FLANGE_D/2, BUSH_FLANGE_T, align=(Align.CENTER, Align.CENTER, Align.MIN))
    b += Pos(0,0,-6.0) * Cylinder(BUSH_D/2, 6.0, align=(Align.CENTER, Align.CENTER, Align.MIN))
    b += Pos(e,0,BUSH_FLANGE_T) * Cylinder(WHEEL_BORE/2, WHEEL_W, align=(Align.CENTER, Align.CENTER, Align.MIN))
    b -= Pos(0,0,-6.1) * Cylinder(BUSH_HEX/2*1.1, 3.0, align=(Align.CENTER, Align.CENTER, Align.MIN))
    if az is None: return b
    return polar(az, BUSH_R, Z_POST_TOP_BUSH) * b

# ---------------------------------------------------------------- references
def ref_gimbal(engaged=True):
    dr = 0.0 if engaged else 2*CLUTCH_ECC
    return zbore(GIM_OD, Z_GIM_BOT, Z_GIM_TOP, GIM_AZ, GIM_R - dr)
def ref_servo():
    return blk(CLUTCH_SERVO_W, CLUTCH_SERVO_L, Z_PLATE_TOP, Z_PLATE_TOP + CLUTCH_SERVO_H,
               CLUTCH_AZ, CLUTCH_R)
def ref_speaker():
    return Pos(SPEAKER_OFF,0,0) * cyl(SPEAKER_D/2, Z_PLATE_TOP, Z_PLATE_TOP + SPEAKER_T)
def ref_disc():
    return cyl(R_DISC, Z_DISC_BOT, Z_DISC_TOP)
def ref_pcb():
    return Pos(PCB_OFFSET, 0, (Z_PCB_BOT+Z_PCB_TOP)/2) * Box(PCB_L, PCB_W, PCB_T)
def ref_components():
    return Pos(PCB_OFFSET, 0, (Z_COMP_BOT+Z_PCB_BOT)/2) * Box(PCB_L, PCB_W, Z_PCB_BOT-Z_COMP_BOT)
def ref_supercaps():
    out = None
    for i in (0, 1):
        c = rbore(SUPERCAP_D, SUPERCAP_R - SUPERCAP_L/2, SUPERCAP_R + SUPERCAP_L/2,
                  SUPERCAP_AZ + i*16, Z_PLATE_TOP + SUPERCAP_D/2)
        out = c if out is None else out + c
    return out
def ref_buzzer():
    return blk(LRA_D, LRA_D, Z_PLATE_TOP, Z_PLATE_TOP + LRA_H + 0.4, BUZZ_AZ, BUZZ_R)
def ref_led_board():
    return tube(LED_WALL_R_OUT + LED_BOARD_T, LED_WALL_R_OUT, HALO_Z0 + 0.3, HALO_Z1 - 0.3) - gimbal_keepout()
def ref_pad():
    return frustum(PLATE_R_BOT - 0.3, PLATE_R_BOT, -PAD_T, 0.0)
def ref_encoder():
    return blk(1.4, 6.0, Z_CODE0, Z_CODE1, ENC_AZ, R_LEDGE_OUT - ENC_GAP - 0.7)

def made_parts(knurl=None):
    m = {"base_plate": base_plate(), "base_shell": base_shell(),
         "halo_diffuser": halo_diffuser(), "knob_body": knob_body(knurl)}
    for i, az in enumerate(WHEEL_AZ):
        m[f"collar_{i}"] = wheel_collar(az)
        m[f"bush_{i}"]   = ecc_bush(az)
    return m
def ref_parts(engaged=True):
    return {"gimbal": ref_gimbal(engaged), "servo": ref_servo(), "speaker": ref_speaker(),
            "disc": ref_disc(), "pcb": ref_pcb(), "components": ref_components(),
            "supercaps": ref_supercaps(), "buzzer": ref_buzzer(),
            "led_board": ref_led_board(), "pad": ref_pad(), "encoder": ref_encoder()}

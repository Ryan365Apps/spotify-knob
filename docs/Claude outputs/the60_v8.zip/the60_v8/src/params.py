"""the 60 (Cadrane) — v8 parameter block.  Every dimension lives here.

v8 (2026-09-03).  A different machine from v7.1.

  The detent is no longer mechanical.  A gimbal BLDC is pressed against the
  knob's bore and renders the feel electrically: 60 clicks, 12, 4, none,
  springs, end stops, ramps — all software.  It also spins the knob.  An
  eccentric clutch on a micro servo disengages it completely for true
  free-spin.

  DELETED from v7.1: 60 steel balls and their 60 blind holes; the 6 magnets;
  carrier rings A and B; the rocker; the seat ring; the ring gearmotor and
  worm; the six magnet towers and their ledge slots; the separate drive
  motor, tyre hub, O-ring and lift-off solenoid.

  KEPT: the one-piece Ø125 knob with its straight Ø116 bore, the three
  623ZZ V-wheels on eccentric bushes, the halo, the steel plate, the ports.

  Display numbers are now taken from Waveshare's published STEP, not assumed.
Units mm, degrees.  z = 0 is the steel plate's underside; the pad is below.
V = unverified (measure before trusting).
"""
import math as _m

# ---------------------------------------------------- DISPLAY (Waveshare STEP)
DISC_OD, DISC_T     = 115.00, 6.00
LENS_OD, LENS_VA    = 112.50, 88.20
ACTIVE_OD           = 87.60
PCB_L, PCB_W, PCB_T = 85.50, 65.00, 1.60
PCB_OFFSET          = 4.50     # board centre offset from the disc centre, +x
DISC_TO_PCB_TOP     = 7.50     # front glass to PCB top face
PCB_TO_LOWEST       = 6.40     # PCB rear face to the tallest part (USB-A)
DISPLAY_DEPTH       = DISC_TO_PCB_TOP + PCB_T + PCB_TO_LOWEST   # 15.50
DISC_MOUNT_PCD      = 106.07   # 4 x M4 at (+-37.5, +-37.5)
DISC_MOUNT_AZ       = [45, 135, 225, 315]
DISC_MOUNT_THREAD   = "M4 x 5 deep into the display housing"
PCB_FREE_HOLES      = (58.00, 49.00)   # four Ø3 on this rectangle

# ---------------------------------------------------- GIMBAL (iPower GM3506)
GIM_OD, GIM_H       = 40.00, 17.80     # overall; the bell is the drive surface
GIM_BELL_OD         = 40.00
GIM_BELL_Z0         = 6.80             # V  bell underside above the base plate
GIM_BORE            = 8.60             # hollow shaft, takes the encoder magnet
GIM_R               = 58.00 - GIM_BELL_OD / 2          # 38.00 centre radius
GIM_AZ              = 0.0      # anywhere: the motor sits entirely below the board
GIM_TORQUE          = "59-98 mNm (600-1000 g.cm), 24N22P, 5.6 ohm"
GIM_BAND_T          = 0.60             # rubber band on the bell, Shore 40-70 (V)
GIM_PRELOAD_N       = 5.0              # press force the eccentric sets
GIM_RATIO           = 2 * 58.00 / GIM_BELL_OD          # 2.90 : 1

# ---------------------------------------------------- CLUTCH
CLUTCH_ECC          = 1.20             # eccentric throw; 2 x this is the lift
CLUTCH_SERVO        = "AGFRC C1.5CLS PRO, 21.4 x 15.2 x 6.0, 9 mm, 2.4 N"
CLUTCH_SERVO_L, CLUTCH_SERVO_W, CLUTCH_SERVO_H = 21.4, 15.2, 6.0
CLUTCH_AZ, CLUTCH_R = 225.0, 38.0

# ---------------------------------------------------- other bought parts
WHEEL               = "623ZZ 3x10x4 + V-collar Ø13.2 on an eccentric bush"
WHEEL_OD, WHEEL_W, WHEEL_BORE = 13.20, 4.00, 3.00
WHEEL_V_H, WHEEL_V_FLAT = 1.30, 0.60
WHEEL_ECC           = 0.90
BUSH_D, BUSH_FLANGE_D, BUSH_HEX = 5.00, 7.00, 2.00
WHEEL_AZ            = [60, 180, 300]   # the only 120-spaced set where the board is under r 46 at all three
ENC                 = "AEDR-8300 + index, reading a code strip on the bore"
ENC_GAP             = 2.00
ENC_AZ              = 60.0
LRA_D, LRA_H        = 10.0, 3.6        # the Buzzer (VLV101040A is 10x10x4)
BUZZ_AZ, BUZZ_R     = 130.0, 34.0
SPEAKER_D, SPEAKER_T = 40.0, 8.5       # Soberton SP-4005-1, Fo 430 Hz, 93 dB
SPEAKER_APERTURE    = 36.0
SPEAKER_OFF         = -6.0    # speaker pushed away from the gimbal so the two clear
SUPERCAP_D, SUPERCAP_L = 8.0, 12.0     # Abracon AHCR-S04R0SA206Q, 2 in series
SUPERCAP_AZ, SUPERCAP_R = 285.0, 30.0
PORT_BOARD_L, PORT_BOARD_W, PORT_BOARD_T = 40.0, 14.0, 1.6   # V, still an envelope
PORT_BOARD_Z0       = 0.95
AZ_PORTS            = 90.0
USBC_W, USBC_H, USBC_DEPTH = 9.0, 3.2, 7.5
JACK_D, JACK_BODY_L, JACK_BODY_W, JACK_BODY_H = 6.0, 14.5, 6.0, 5.0
JACK_AXIS_Z         = 2.20
LIGHT_SENSOR_HOLE   = 2.5
AZ_LIGHT_SENSOR     = 110.0

# ---------------------------------------------------- standing rules
GAP_ROTATE, GAP_STATIC, GAP_RUN = 0.40, 0.15, 0.30
WALL_MIN            = 1.60
INSERT_M3_D, INSERT_M3_L = 4.0, 5.7

# ---------------------------------------------------- radii
R_DISC              = DISC_OD / 2                      # 57.50
R_SKIRT_BORE        = R_DISC + 0.50                    # 58.00 straight bore
R_KNOB              = 62.50
R_CROWN_IN          = ACTIVE_OD / 2 + 0.70             # 44.50
SKIRT_WALL          = R_KNOB - R_SKIRT_BORE            #  3.60
R_GROOVE_ROOT       = R_SKIRT_BORE + WHEEL_V_H         # 59.30
WHEEL_AXIS_R        = R_GROOVE_ROOT - WHEEL_OD/2 - 0.07  # 52.63
BUSH_R              = WHEEL_AXIS_R - WHEEL_ECC         # 51.73
WHEEL_R_RETRACTED   = BUSH_R - WHEEL_ECC               # 50.83
WHEEL_POST_D        = 8.00
R_LEDGE_OUT         = R_SKIRT_BORE - GAP_ROTATE        # 57.60
R_LEDGE_IN          = 49.00
R_INNER_ROOF        = 49.50
DISC_POST_R         = DISC_MOUNT_PCD / 2               # 53.04
DISC_POST_D         = 6.80                             # M4 boss
TUNNEL_W, TUNNEL_R_BACK = 34.0, 46.0
PLATE_SCREW_AZ      = [60, 180, 300]                   # paired with the wheel posts
PLATE_SCREW_R       = 40.0
GIM_PLATE_HOLE_D    = GIM_OD + 4.0                     # 44 hole in the steel plate

# ---------------------------------------------------- z stack, built bottom-up
PAD_T               = 1.50
BASE_PLATE_T        = 3.00
Z_PLATE_TOP         = BASE_PLATE_T                     #  3.0
# the gimbal sits on the pad, through a hole in the plate
Z_GIM_BOT           = 0.0
Z_GIM_TOP           = Z_GIM_BOT + GIM_H                # 17.8
Z_BELL_BOT          = Z_GIM_BOT + GIM_BELL_Z0          #  6.8
# the halo drops so the bell clears it
PLINTH_H            = 0.50
Z_PLINTH_TOP        = Z_PLATE_TOP + PLINTH_H           #  3.5
HALO_H              = 3.00
HALO_Z0, HALO_Z1    = Z_PLINTH_TOP, Z_PLINTH_TOP + HALO_H   # 3.5 - 6.5
Z_SKIRT_BOT         = HALO_Z1 + 0.60                   #  7.1  shadow gap
# the display sits above the motor
Z_COMP_BOT          = Z_GIM_TOP + 1.00                 # 18.8
Z_PCB_BOT           = Z_COMP_BOT + PCB_TO_LOWEST       # 25.2
Z_PCB_TOP           = Z_PCB_BOT + PCB_T                # 26.8
Z_DISC_BOT          = Z_PCB_TOP + (DISC_TO_PCB_TOP - DISC_T)   # 28.3
Z_DISC_TOP          = Z_DISC_BOT + DISC_T              # 34.3  the glass
RIM_GAP, CROWN_T    = 0.40, 3.00
Z_CROWN_BOT         = Z_DISC_TOP + RIM_GAP             # 34.7
Z_KNOB_TOP          = Z_CROWN_BOT + CROWN_T            # 37.7
# the wheels sit in the groove just under the display
Z_WHEEL1            = Z_DISC_BOT - 0.40                # 27.9
Z_WHEEL0            = Z_WHEEL1 - WHEEL_W               # 23.9
Z_RIDGE_MID         = (Z_WHEEL0 + Z_WHEEL1) / 2        # 25.9
Z_GROOVE0           = Z_RIDGE_MID - WHEEL_V_H - WHEEL_V_FLAT/2   # 24.3
Z_GROOVE1           = Z_RIDGE_MID + WHEEL_V_H + WHEEL_V_FLAT/2   # 27.5
BUSH_FLANGE_T       = 0.60
Z_POST_TOP_BUSH     = Z_WHEEL0 - BUSH_FLANGE_T         # 23.3
# the ledge carries the wheel posts and the display posts, above the motor
Z_LEDGE_TOP         = Z_GIM_TOP + 0.60                 # 18.4
Z_LEDGE_BOT         = Z_LEDGE_TOP - 1.80               # 16.6
# the bell drives the bore between the halo and the ledge
Z_DRIVE0, Z_DRIVE1  = Z_SKIRT_BOT + 0.4, Z_LEDGE_BOT - 0.4   # 7.5 - 16.2
# code band for the encoder, on the bore above the ledge
Z_CODE0, Z_CODE1    = Z_LEDGE_TOP + 0.6, Z_LEDGE_TOP + 3.6   # 19.0 - 22.0

HEIGHT              = Z_KNOB_TOP + PAD_T               # 39.2
KNOB_FRACTION       = (Z_KNOB_TOP - Z_SKIRT_BOT) / Z_KNOB_TOP

# halo geometry
LED_WALL_R_IN, LED_WALL_R_OUT = 55.50, 57.00
LED_BOARD_T         = 1.20
DIFF_R_IN           = LED_WALL_R_OUT + LED_BOARD_T + 0.30   # 58.50
DIFF_R_OUT_BOT      = 61.60
DIFF_R_OUT_TOP      = R_KNOB
PLINTH_R_IN, PLINTH_R_OUT = 55.50, 61.10
PLATE_R, PLATE_R_BOT = 61.50, 61.10
LED_N               = 90

# knurl
KNURL_ON            = True
KNURL_N, KNURL_DEPTH, KNURL_HELIX_DEG = 56, 1.00, 30.0
KNURL_ROOT_OFF      = 0.50     # cutter root sunk this far past the knurl depth
KNURL_BAND_OV       = -0.03    # band-to-band overlap; bands must NOT overlap (v5/v6 lesson)
KNURL_BANDS, KNURL_LAND = 8, 0.80
CH_TOP, CH_IN, CH_BOT = 2.50, 1.00, 1.20
KNURL_Z0            = Z_SKIRT_BOT + CH_BOT + KNURL_LAND
KNURL_Z1            = Z_KNOB_TOP - CH_TOP - KNURL_LAND
KNURL_PITCH         = _m.pi * 2 * R_KNOB / KNURL_N       # 7.0 mm circumferential
PRINT_MATERIAL, LAYER = "PETG", 0.20

"""v8 general arrangement: real plan slices + a parametric section."""
import os, math, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mp
from model import *
Rect=mp.Rectangle; Circ=mp.Circle; Poly=mp.Polygon

BLUE="#1f4e9c"; RED="#b02020"; GOLD="#8a6d00"; GRN="#1a7a3c"; ORG="#c46a10"; PUR="#5a3a9a"
made=made_parts(); refs=ref_parts(True)
knurled=made["knob_body"]          # the real part: the knurl is geometry, not a note
allp={**made,**refs}
COL={"base_plate":"0.45","base_shell":"#7a6a4a","halo_diffuser":"#9ab","knob_body":"0.15",
     "gimbal":GOLD,"servo":PUR,"speaker":ORG,"disc":BLUE,"pcb":GRN,"components":GRN,
     "supercaps":GRN,"buzzer":RED,"led_board":"#c8892a","pad":"0.7","encoder":"0.4"}
for i in range(3): COL[f"collar_{i}"]="#8a4a8a"; COL[f"bush_{i}"]="#8a4a8a"

def slice_edges(shape, z):
    slab = Pos(0,0,z) * Box(300,300,0.02, align=(Align.CENTER,Align.CENTER,Align.CENTER))
    try: sec = shape & slab
    except Exception: return []
    out=[]
    if sec is None: return out
    for e in sec.edges():
        pts=[e.position_at(t) for t in [i/16 for i in range(17)]]
        if abs(pts[0].Z - z) > 0.05: continue
        out.append([(p.X,p.Y) for p in pts])
    return out

fig=plt.figure(figsize=(20,11))
fig.suptitle("the 60 — v8 general arrangement.  Gimbal-driven haptics, no detent hardware.  Knurl restored.",
             fontsize=13.5, weight="bold", y=0.975)

# ---- plan at the motor level
ax=fig.add_axes([0.02,0.06,0.42,0.85]); ax.set_aspect("equal"); ax.axis("off")
ax.set_xlim(-72,72); ax.set_ylim(-68,68)
ax.set_title("plan at z = 10 (through the motor, the halo and the knurl)", fontsize=10.5, weight="bold")
for seg in slice_edges(knurled, 10.0):                 # the knob's REAL section, knurl and all
    xs,ys=zip(*seg); ax.plot(xs,ys,color="0.15",lw=0.7)
ax.add_patch(Circ((0,0),R_SKIRT_BORE,fill=False,ec="0.8",ls=":",lw=0.9))
for n in ("base_plate","base_shell","halo_diffuser","gimbal","servo","speaker","supercaps","buzzer","led_board"):
    for seg in slice_edges(allp[n], 10.0):
        xs,ys=zip(*seg); ax.plot(xs,ys,color=COL[n],lw=1.2)
for n in ("base_plate","speaker","servo","supercaps"):
    for seg in slice_edges(allp[n], 5.0):
        xs,ys=zip(*seg); ax.plot(xs,ys,color=COL[n],lw=1.0,alpha=0.55)
def lab(az,r,t,c):
    a=math.radians(az); ax.annotate(t,(r*math.cos(a),r*math.sin(a)),ha="center",va="center",fontsize=8,color=c)
lab(GIM_AZ,GIM_R,"GIMBAL\nGM3506\nØ40 × 17.8",GOLD)
lab(180,SPEAKER_OFF*-1+2,"SPEAKER\nØ40 × 8.5",ORG)
lab(CLUTCH_AZ,CLUTCH_R,"clutch\nservo",PUR)
lab(285,30,"supercaps",GRN); lab(130,34,"Buzzer",RED)
for az in WHEEL_AZ:
    a=math.radians(az); x,y=BUSH_R*math.cos(a),BUSH_R*math.sin(a)
    ax.add_patch(Circ((x,y),WHEEL_POST_D/2,fc="#f0e0f0",ec="#8a4a8a",lw=1.1))
for az in DISC_MOUNT_AZ:
    a=math.radians(az); x,y=DISC_POST_R*math.cos(a),DISC_POST_R*math.sin(a)
    ax.add_patch(Circ((x,y),DISC_POST_D/2,fc="#eee",ec="0.45",lw=0.9))
lab(180,BUSH_R+9,"wheel posts 60/180/300","#8a4a8a")
lab(45,DISC_POST_R+9,"display M4 on Ø106.07","0.35")
ax.annotate("", xy=(R_SKIRT_BORE,0), xytext=(GIM_R+GIM_BELL_OD/2-6,0),
            arrowprops=dict(arrowstyle="->",lw=1.4,color=GOLD))
ax.annotate("the bell drives the bore\n2.90 : 1", (30,-9), fontsize=8.5, color=GOLD)

# ---- section
bx=fig.add_axes([0.475,0.42,0.51,0.50])
bx.set_xlim(0,68); bx.set_ylim(-3,40); bx.set_aspect(1.0)
bx.set_title("radial section",fontsize=10.5,weight="bold")
bx.set_xlabel("radius r (mm)",fontsize=8.5); bx.set_ylabel("z (mm)",fontsize=8.5); bx.tick_params(labelsize=7.5)
def rr(r0,r1,z0,z1,**kw): bx.add_patch(Rect((r0,z0),r1-r0,z1-z0,**kw))
rr(0,PLATE_R_BOT,-PAD_T,0,fc="#eee",ec="0.6",lw=0.6)
rr(0,PLATE_R,0,Z_PLATE_TOP,fc="#ccc",ec="0.4",lw=0.9)
rr(GIM_R-GIM_OD/2,GIM_R+GIM_OD/2,Z_GIM_BOT,Z_GIM_TOP,fc="#ffeaa8",ec=GOLD,lw=1.4)
rr(GIM_R-GIM_BELL_OD/2,R_SKIRT_BORE,Z_BELL_BOT,Z_GIM_TOP,fc="#ffe680",ec=GOLD,lw=1.0)
rr(0,SPEAKER_D/2-SPEAKER_OFF,Z_PLATE_TOP,Z_PLATE_TOP+SPEAKER_T,fc="#f2e2c8",ec=ORG,lw=1.0)
rr(PLINTH_R_IN,PLINTH_R_OUT,Z_PLATE_TOP,Z_PLINTH_TOP,fc="#e8e8e8",ec="0.5",lw=0.8)
rr(DIFF_R_IN,DIFF_R_OUT_BOT,HALO_Z0,HALO_Z1,fc="#dfe9f5",ec="#9ab",lw=0.9)
rr(LED_WALL_R_IN,LED_WALL_R_OUT,HALO_Z0,HALO_Z1,fc="#e8e8e8",ec="0.6",lw=0.7)
rr(R_LEDGE_IN,R_LEDGE_OUT,Z_LEDGE_BOT,Z_LEDGE_TOP,fc="#f0e8d8",ec="0.4",lw=1.0)
rr(22,R_INNER_ROOF,Z_LEDGE_TOP-1.4,Z_LEDGE_TOP-0.4,fc="#f0e8d8",ec="0.4",lw=0.8)
rr(BUSH_R-4,BUSH_R+4,Z_LEDGE_TOP,Z_POST_TOP_BUSH,fc="#f0e0f0",ec="#8a4a8a",lw=1.0)
rr(WHEEL_AXIS_R-WHEEL_OD/2,WHEEL_AXIS_R+WHEEL_OD/2,Z_WHEEL0,Z_WHEEL1,fc="#f5e5f5",ec="#8a4a8a",lw=1.0)
rr(0,PCB_L/2+PCB_OFFSET,Z_COMP_BOT,Z_PCB_BOT,fc="#e9f0e4",ec=GRN,lw=0.8,ls="--")
rr(0,PCB_L/2+PCB_OFFSET,Z_PCB_BOT,Z_PCB_TOP,fc="#dbe8d2",ec=GRN,lw=0.9)
rr(0,R_DISC,Z_DISC_BOT,Z_DISC_TOP,fc="#dde6ee",ec=BLUE,lw=1.0)
pts=body_profile(); bx.add_patch(Poly(pts,closed=True,fc="#f7f7f7",ec="0.15",lw=1.6))
bx.plot([R_KNOB-KNURL_DEPTH]*2,[KNURL_Z0,KNURL_Z1],color=RED,lw=1.3,ls="--")
bx.annotate(f"knurl root\n-{KNURL_DEPTH:.1f} mm",(R_KNOB-KNURL_DEPTH-0.5,(KNURL_Z0+KNURL_Z1)/2),
            fontsize=7.5,ha="right",va="center",color=RED)
for r,z,t,c in [(GIM_R,9,"GM3506",GOLD),(52,12,"bell → bore",GOLD),(14,7,"speaker",ORG),
                (53,17.5,"ledge","0.3"),(52,25.5,"V-wheel","#8a4a8a"),(25,22,"main board",GRN),
                (25,31,"display",BLUE),(60,33,"knob","0.2"),(59,5,"halo","#5a7a9a")]:
    bx.annotate(t,(r,z),fontsize=8,ha="center",va="center",color=c)
bx.grid(alpha=0.2,lw=0.4)

# ---- knurl detail
kx=fig.add_axes([0.026,0.085,0.132,0.150]); kx.set_aspect("equal")
kx.set_title("knurl detail (plan at z = 20)",fontsize=8.0,weight="bold",color=RED,pad=2)
for seg in slice_edges(knurled, 20.0):
    xs,ys=zip(*seg); kx.plot(xs,ys,color="0.15",lw=1.1)
kx.add_patch(Circ((0,0),R_KNOB,fill=False,ec="0.75",ls=":",lw=0.8))
kx.add_patch(Circ((0,0),R_KNOB-KNURL_DEPTH,fill=False,ec=RED,ls="--",lw=0.9))
kx.set_xlim(-11,11); kx.set_ylim(R_KNOB-4.6,R_KNOB+1.4)
kx.set_xticks([]); kx.set_yticks([])
for sp in kx.spines.values(): sp.set_edgecolor("0.6")
kx.annotate(f"{KNURL_N} starts · {KNURL_PITCH:.2f} pitch · {KNURL_DEPTH:.1f} deep · {KNURL_HELIX_DEG:.0f}° helix",
            (0,R_KNOB-4.25),fontsize=6.8,ha="center",color=RED)

tx=fig.add_axes([0.475,0.02,0.51,0.36]); tx.axis("off")
tx.text(0,1.0,"v8 — what changed, and the numbers",fontsize=10.5,weight="bold",va="top")
tx.text(0,0.93,
 f"GONE:  60 steel balls and their 60 blind holes; the 6 magnets; carrier\n"
 f"       rings A and B; the rocker; the seat ring; the ring gearmotor and\n"
 f"       worm; the six towers and their ledge slots; the separate drive\n"
 f"       motor, tyre hub, O-ring and lift-off solenoid.\n\n"
 f"NEW:   one iPower GM3506 gimbal, O40 x 17.8, sitting on the pad through a\n"
 f"       hole in the steel plate. Its bell runs a rubber band against the\n"
 f"       knob's bore: {GIM_RATIO:.2f}:1, so 59-98 mNm at the motor becomes\n"
 f"       {59*GIM_RATIO:.0f}-{98*GIM_RATIO:.0f} mNm at your hand. Detents, springs, end stops and\n"
 f"       self-turning are all software on that one torque.\n"
 f"       An eccentric clutch on a micro servo lifts it {2*CLUTCH_ECC:.1f} mm clear for\n"
 f"       true free-spin. Spring-preloaded, so no holding current either way.\n\n"
 f"HEIGHT {HEIGHT:.1f} mm, up from 34.3. The motor is 17.8 tall and has to sit\n"
 f"       under the display board, which sets everything above it.\n"
 f"       The knob is now {Z_KNOB_TOP-Z_SKIRT_BOT:.1f} mm = {KNOB_FRACTION*100:.0f} % of the side (was 71 %).\n"
 f"       The halo dropped to z {HALO_Z0}-{HALO_Z1} so the bell clears it.\n\n"
 f"CHECKS 0 failures, 0 warnings. Knob clear at 0/17/45/73 deg; clutch\n"
 f"       releases to {2*CLUTCH_ECC:.1f} mm; everything inside O125 and under the knob top.\n\n"
 f"KNURL  {KNURL_N} starts, {KNURL_PITCH:.2f} pitch, {KNURL_DEPTH:.1f} deep, {KNURL_HELIX_DEG:.0f} deg helix, z {KNURL_Z0:.1f}-{KNURL_Z1:.1f}.\n"
 f"       MISSING from the first v8 build: the parameters came across from\n"
 f"       v7.1, the geometry did not. Wall under the root {SKIRT_WALL-KNURL_DEPTH:.2f} mm.\n\n"
 f"MASS   made parts {sum(s.volume/1000*(7.85 if n=='base_plate' else 1.27) for n,s in made.items()):.0f} g. The knob is {made['knob_body'].volume/1000*2.7:.0f} g in aluminium,\n"
 f"       up from 118 g -- it is 7 mm taller. Good for the flywheel feel,\n"
 f"       but worth a decision: hollowing the crown would take some back.",
 fontsize=7.5,va="top",family="monospace",linespacing=1.32)
fig.savefig(os.path.join(OUT,"v8_ga.png"),dpi=105,facecolor="white")
print("wrote out/v8_ga.png")

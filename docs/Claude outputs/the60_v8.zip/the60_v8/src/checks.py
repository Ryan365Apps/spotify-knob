"""v8 automated checks: solidity, interference, knob rotation, clutch states, containment."""
import sys, os, time, math, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from model import *
T0=time.time(); fails=[]; warns=[]
def ok(m): print(f"  ok    {m}")
def fail(m): print(f"  FAIL  {m}"); fails.append(m)
def warn(m): print(f"  warn  {m}"); warns.append(m)
def sec(t): print(f"\n[{t}]  ({time.time()-T0:.0f}s)")
def inter(a,b):
    try:
        i=a&b
        if i is None: return 0.0
        return i.volume if hasattr(i,"volume") else sum(s.volume for s in i)
    except Exception as e:
        fail(f"boolean failed: {e}"); return 1e9
EXEMPT={("base_shell","speaker"),("base_shell","led_board"),("base_shell","encoder"),
        ("base_shell","buzzer"),("base_shell","supercaps"),("base_shell","servo"),
        ("base_plate","pad"),("base_plate","base_shell"),("base_plate","speaker"),
        ("base_plate","gimbal"),("pad","gimbal"),("base_plate","supercaps"),
        ("halo_diffuser","base_shell"),("halo_diffuser","led_board"),
        ("disc","pcb"),("pcb","components"),("disc","base_shell"),("components","base_shell"),
        ("knob_body","collar"),("collar","bush"),("base_shell","bush"),("base_shell","collar"),
        ("knob_body","gimbal"),("disc","disc_screws")}
def ex(a,b):
    a2="collar" if a.startswith("collar") else ("bush" if a.startswith("bush") else a)
    b2="collar" if b.startswith("collar") else ("bush" if b.startswith("bush") else b)
    return (a2,b2) in EXEMPT or (b2,a2) in EXEMPT

sec("build")
# Interference runs on the SMOOTH body: the knurl only removes material from the
# outer face, so the smooth body is a superset and the conservative case.  The
# "knurl" section below proves that claim instead of assuming it.
made=made_parts(knurl=False); refs=ref_parts(True); refs_off=ref_parts(False)
knurled=knob_body(knurl=True)
print(f"  {len(made)} made, {len(refs)} references (knob checked smooth, knurl proven separately)")

sec("solidity")
for n,s in {**made,**refs}.items():
    ns=len(s.solids())
    if ns!=1 and n not in ("supercaps",): fail(f"{n}: {ns} solids")
    elif not s.is_valid: fail(f"{n}: invalid")
for n,s in made.items(): ok(f"{n:14s} {s.volume/1000:7.2f} cm3")

sec("interference, clutch engaged")
allp={**made,**refs}; names=list(allp); bad=0
for a,b in itertools.combinations(names,2):
    A,B=allp[a],allp[b]; ba,bb=A.bounding_box(),B.bounding_box()
    if (ba.max.X<bb.min.X or bb.max.X<ba.min.X or ba.max.Y<bb.min.Y or bb.max.Y<ba.min.Y
        or ba.max.Z<bb.min.Z or bb.max.Z<ba.min.Z): continue
    v=inter(A,B)
    if v>0.05 and not ex(a,b): fail(f"{a} x {b}: {v:.2f} mm3"); bad+=1
    elif v>60 and ex(a,b): warn(f"{a} x {b}: {v:.0f} mm3 (exempt, large)")
if not bad: ok("no unintended interference")

sec("clutch")
g_on, g_off = refs["gimbal"], refs_off["gimbal"]
d_on  = made["knob_body"].distance_to(g_on)
d_off = made["knob_body"].distance_to(g_off)
ok(f"bell to bore, engaged {d_on:.2f} mm (band is {GIM_BAND_T} thick, so it presses)")
(ok if d_off >= 0.8 else fail)(f"bell to bore, released {d_off:.2f} mm")
ok(f"eccentric throw {CLUTCH_ECC} -> {2*CLUTCH_ECC:.1f} mm of lift")

sec("knob rotation")
knob=made["knob_body"]
statics=[(n,s) for n,s in {**made,**refs}.items()
         if n not in ("knob_body","disc","pcb","components","gimbal")]
for ang in (0.0,17.0,45.0,73.0):
    k=Rot(0,0,ang)*knob
    for n,s in statics:
        if n.startswith("collar"): continue
        v=inter(k,s)
        if v>0.05: fail(f"knob at {ang}° x {n}: {v:.2f} mm3")
if not any("knob at" in f for f in fails): ok("knob clear of every static at 0/17/45/73°")
for n in ("disc","pcb","components"):
    d=knob.distance_to(refs[n]); (ok if d>=GAP_ROTATE-0.02 else fail)(f"knob to {n}: {d:.2f} mm")

sec("stack and containment")
for n,s in {**made,**refs}.items():
    bb=s.bounding_box()
    if bb.max.Z>Z_KNOB_TOP+0.01: fail(f"{n} above the knob top: {bb.max.Z:.2f}")
    if bb.min.Z<-PAD_T-0.01: fail(f"{n} below the pad: {bb.min.Z:.2f}")
for n in ("base_plate","base_shell","halo_diffuser","pad"):
    s={**made,**refs}[n]; bb=s.bounding_box()
    r=max(abs(bb.min.X),bb.max.X,abs(bb.min.Y),bb.max.Y)
    (ok if r<=R_KNOB+0.01 else fail)(f"{n} inside Ø{2*R_KNOB:.0f}: max Ø{2*r:.1f}")
ok(f"height {HEIGHT:.1f} mm incl. pad; knob {KNOB_FRACTION*100:.0f} % of the side")
(ok if Z_GIM_TOP < Z_COMP_BOT else fail)(f"gimbal top {Z_GIM_TOP} under the board at {Z_COMP_BOT}")
(ok if Z_BELL_BOT > HALO_Z1 - 0.01 else fail)(f"bell bottom {Z_BELL_BOT} clears the halo top {HALO_Z1}")
ok(f"drive band on the bore z {Z_DRIVE0:.1f}-{Z_DRIVE1:.1f} = {Z_DRIVE1-Z_DRIVE0:.1f} mm")

sec("knurl")
(ok if len(knurled.solids())==1 and knurled.is_valid else fail)(
    f"knurled body is {len(knurled.solids())} valid solid(s)")
vs, vk = made["knob_body"].volume, knurled.volume
(ok if vk < vs - 1000 else fail)(
    f"knurl removed {(vs-vk)/1000:.2f} cm3 ({100*(vs-vk)/vs:.1f} % of the turned body)")
# the knurl envelope: everything the cutter could have reached
env = tube(R_KNOB+0.01, R_KNOB-KNURL_DEPTH-KNURL_ROOT_OFF, KNURL_Z0-0.05, KNURL_Z1+0.05)
clash=[n for n,s_ in {**made,**refs}.items() if n!="knob_body" and inter(env,s_)>0.05]
(ok if not clash else fail)(
    f"knurl envelope r {R_KNOB-KNURL_DEPTH-KNURL_ROOT_OFF:.1f}-{R_KNOB:.1f}, "
    f"z {KNURL_Z0:.1f}-{KNURL_Z1:.1f} is clear of every other part"
    + (f" - hits {clash}" if clash else ""))
(ok if KNURL_Z0 >= Z_SKIRT_BOT+CH_BOT-0.01 else fail)(
    f"knurl starts at z {KNURL_Z0:.1f}, above the skirt bottom {Z_SKIRT_BOT:.1f} + chamfer")
(ok if KNURL_Z1 <= Z_KNOB_TOP-CH_TOP+0.01 else fail)(
    f"knurl ends at z {KNURL_Z1:.1f}, below the top chamfer at {Z_KNOB_TOP-CH_TOP:.1f}")
ok(f"{KNURL_N} starts, pitch {KNURL_PITCH:.2f} mm, depth {KNURL_DEPTH} mm, "
   f"helix {KNURL_HELIX_DEG}deg, {KNURL_BANDS} bands over {KNURL_Z1-KNURL_Z0:.1f} mm")
wall = SKIRT_WALL - KNURL_DEPTH
(ok if wall >= 1.6 else fail)(f"wall under the knurl root {wall:.2f} mm (min {WALL_MIN})")

sec("mass")
rho={"base_plate":7.85,"knob_body":1.27}
tot=0
for n,s in made.items():
    vol = knurled.volume if n=="knob_body" else s.volume     # the real, knurled part
    d=rho.get(n,1.27); g=vol/1000*d; tot+=g
    extra=f"  (Al {vol/1000*2.7:.0f} g, knurled)" if n=="knob_body" else ""
    print(f"  {n:14s} {g:7.1f} g{extra}")
ok(f"made parts {tot:.0f} g + display, motor, servo, speaker")

print("\n"+"="*62)
print(f"{len(fails)} failures, {len(warns)} warnings  ({time.time()-T0:.0f}s)")
for f in fails: print("  FAIL",f)

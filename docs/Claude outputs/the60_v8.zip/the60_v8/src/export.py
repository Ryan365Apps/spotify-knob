import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from model import *
from build123d import export_step, export_stl, Compound
T0=time.time()
made=made_parts(); refs=ref_parts(True)
NOTE={"base_plate":"STEEL - laser-cut 3 mm S275; Ø44 hole for the gimbal, Ø36 speaker aperture",
      "base_shell":"print upright on the plinth, 0.20 mm layers, no supports",
      "halo_diffuser":"print on its underside; natural/translucent PETG",
      "knob_body":"ONE PIECE, KNURLED. print TOP FACE DOWN, 0.16 mm layers, no supports; 56-start diamond knurl 1.0 deep, 30 deg helix, z 9.1-34.4; bore smooth, no peg holes",
      "collar_0":"x3, axis vertical, 0.12 mm; press over a 623ZZ",
      "bush_0":"x3, pin up, 0.12 mm; brass in production"}
pd=os.path.join(OUT,"parts"); os.makedirs(pd, exist_ok=True)
for n,s in made.items():
    if (n.startswith("collar_") and n!="collar_0") or (n.startswith("bush_") and n!="bush_0"): continue
    shape = wheel_collar() if n=="collar_0" else (ecc_bush() if n=="bush_0" else s)
    export_step(shape, os.path.join(pd,f"{n}.step"), write_pcurves=False)
    export_stl(shape, os.path.join(pd,f"{n}.stl"), tolerance=0.02, angular_tolerance=0.1)
    print(f"  {n:14s} {shape.volume/1000:7.2f} cm3  {NOTE.get(n,'')}", flush=True)
# NAMED assembly (D1-D3: every child labelled, all in position)
kids=[]
for n,s in {**made,**refs}.items():
    c = Compound(children=[]) if False else s
    try: c.label = n
    except Exception: pass
    kids.append(c)
asm = Compound(children=kids); asm.label = "the60_v8"
export_step(asm, os.path.join(OUT,"the60_v8_assembly.step"), write_pcurves=False)
made_off = made_parts(); refs_off = ref_parts(False)
kids2=[]
for n,s in {**made_off,**refs_off}.items():
    try: s.label=n
    except Exception: pass
    kids2.append(s)
a2=Compound(children=kids2); a2.label="the60_v8_clutch_released"
export_step(a2, os.path.join(OUT,"the60_v8_assembly_clutch_released.step"), write_pcurves=False)
with open(os.path.join(pd,"README.txt"),"w") as f:
    f.write("the 60 - v8 - printable parts\n\n")
    f.write("The knob carries the real diamond knurl (56 starts, 1.0 mm deep,\n")
    f.write("30 deg helix, 8 bands over z 9.1-34.4). It is the only surface the\n")
    f.write("hand touches - check it on the print before anything else.\n\n")
    for n,t in NOTE.items(): f.write(f"{n:16s} {t}\n")
    f.write("\nBought: iPower GM3506 gimbal; AGFRC C1.5CLS PRO servo; 3x 623ZZ;\n")
    f.write("Waveshare ESP32-P4-WIFI6-Touch-LCD-3.4C; Soberton SP-4005-1 speaker;\n")
    f.write("2x Abracon AHCR-S04R0SA206Q; TMC6300 driver; MT6701 encoder;\n")
    f.write("AEDR-8300 + code strip; DRV2605L + VLV101040A Buzzer.\n")
    f.write("\nThe assembly STEP at the top of this package has every component NAMED\n")
    f.write("and in its assembled position - open that one in Fusion, not the parts.\n")
print(f"\ndone in {time.time()-T0:.0f}s")

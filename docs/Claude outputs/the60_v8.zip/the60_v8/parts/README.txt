the 60 - v8 - printable parts

The knob carries the real diamond knurl (56 starts, 1.0 mm deep,
30 deg helix, 8 bands over z 9.1-34.4). It is the only surface the
hand touches - check it on the print before anything else.

base_plate       STEEL - laser-cut 3 mm S275; Ø44 hole for the gimbal, Ø36 speaker aperture
base_shell       print upright on the plinth, 0.20 mm layers, no supports
halo_diffuser    print on its underside; natural/translucent PETG
knob_body        ONE PIECE, KNURLED. print TOP FACE DOWN, 0.16 mm layers, no supports; 56-start diamond knurl 1.0 deep, 30 deg helix, z 9.1-34.4; bore smooth, no peg holes
collar_0         x3, axis vertical, 0.12 mm; press over a 623ZZ
bush_0           x3, pin up, 0.12 mm; brass in production

Bought: iPower GM3506 gimbal; AGFRC C1.5CLS PRO servo; 3x 623ZZ;
Waveshare ESP32-P4-WIFI6-Touch-LCD-3.4C; Soberton SP-4005-1 speaker;
2x Abracon AHCR-S04R0SA206Q; TMC6300 driver; MT6701 encoder;
AEDR-8300 + code strip; DRV2605L + VLV101040A Buzzer.

The assembly STEP at the top of this package has every component NAMED
and in its assembled position - open that one in Fusion, not the parts.

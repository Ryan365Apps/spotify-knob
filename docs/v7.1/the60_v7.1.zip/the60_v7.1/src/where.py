"""Where do two parts overlap? python where.py state a b [a b ...]  -> bbox of each intersection"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from model import *
state = sys.argv[1]
made = made_parts(state, knurl=False); refs = ref_parts(state)
allp = {**made, **refs}
args = sys.argv[2:]
import math
for a, b in zip(args[::2], args[1::2]):
    A = allp[a] if a != "knob" else made["knob_body"]
    B = allp[b]
    i = A & B
    sols = i.solids() if hasattr(i, "solids") else list(i)
    for s in sols:
        bb = s.bounding_box()
        cx, cy = (bb.min.X + bb.max.X) / 2, (bb.min.Y + bb.max.Y) / 2
        print(f"{a} x {b}: {s.volume:7.2f} mm3  x {bb.min.X:6.1f}..{bb.max.X:6.1f}  y {bb.min.Y:6.1f}..{bb.max.Y:6.1f}  z {bb.min.Z:5.2f}..{bb.max.Z:5.2f}   (r {math.hypot(cx,cy):5.1f}, az {math.degrees(math.atan2(cy,cx))%360:5.1f})")
    if not sols:
        print(f"{a} x {b}: no overlap")

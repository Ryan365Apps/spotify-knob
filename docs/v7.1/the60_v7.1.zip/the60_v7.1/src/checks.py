"""Automated checks for v7: solidity, pairwise interference in both detent states,
knob-rotation envelope, clearances, containment, min walls (sampled), masses.
Run:  python checks.py  (~ a few minutes; the knurled body is loaded from the
cache if present, else the smooth body is checked)."""
import sys, os, time, math, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from model import *

T0 = time.time()
fails, warns = [], []
def ok(msg):   print(f"  ok    {msg}")
def fail(msg): print(f"  FAIL  {msg}"); fails.append(msg)
def warn(msg): print(f"  warn  {msg}"); warns.append(msg)
def section(t): print(f"\n[{t}]  ({time.time()-T0:.0f}s)")

def inter_vol(a, b):
    """Intersection volume; a boolean failure is reported as a FAIL, never as 0."""
    try:
        i = a & b
        if i is None:
            return 0.0
        if hasattr(i, "volume"):
            return i.volume
        return sum(s.volume for s in i)
    except Exception as e:
        fail(f"boolean failed: {e}")
        return 1e9

# pairs that are allowed to touch / interfere (contact fits, intended press)
EXEMPT = {
    ("knob_body", "pegs"),
    ("base_shell", "disc_screws"), ("base_shell", "bush"), ("bearings", "bush"), ("collar", "bush"),
    ("collar", "bearings"), ("knob_body", "collar"),
    ("ring_a", "magnets"), ("ring_b", "magnets"), ("base_shell", "rocker"), ("ring_a", "rocker"), ("ring_b", "rocker"),
    ("base_shell", "led_board"),
    ("base_shell", "encoder"), ("base_shell", "lra"), ("base_shell", "speaker"), ("base_shell", "port_board"),
    ("base_plate", "pad"), ("base_plate", "base_shell"), ("base_plate", "speaker"), ("base_plate", "supercaps"), ("pad", "n20"), ("pad", "port_board"), ("pad", "jack"),
    ("base_plate", "drive_motor"), ("pad", "drive_motor"),
    ("drive_plate", "drive_motor"), ("drive_motor", "tyre"), ("knob_body", "tyre"), ("tyre_hub", "tyre"), ("tyre_hub", "drive_motor"),
    ("halo_diffuser", "base_shell"), ("halo_diffuser", "led_board"), ("disc", "disc_screws"), ("disc", "pcb"),
    ("pcb", "components"), ("disc", "base_shell"), ("port_board", "usbc"), ("port_board", "jack"),
    ("usbc", "usbc_plug"), ("jack", "jack_plug"), ("ring_a", "worm"), ("n20", "worm"),
    ("drive_plate", "solenoid"), ("base_plate", "solenoid"),
}
def exempt(a, b):
    def norm(n): return "collar" if n.startswith("collar") else ("bush" if n.startswith("bush") else n)
    a2, b2 = norm(a), norm(b)
    return (a2, b2) in EXEMPT or (b2, a2) in EXEMPT

section("build")
made = {}
for st in ("on", "off"):
    made[st] = made_parts(st, knurl=False)
refs = {st: ref_parts(st) for st in ("on", "off")}
print(f"  {len(made['on'])} made parts, {len(refs['on'])} references")

section("solidity")
for n, s in {**made["on"], **refs["on"]}.items():
    ns = len(s.solids())
    if ns != 1 and n not in ("bearings", "magnets", "pegs", "supercaps", "disc_screws"):
        fail(f"{n}: {ns} solids")
    elif not s.is_valid:
        fail(f"{n}: invalid solid")
for n, s in made["on"].items():
    ok(f"{n:14s} {s.volume/1000:7.2f} cm3")

section("interference, both states")
for st in ("on", "off"):
    allp = {**made[st], **refs[st]}
    names = list(allp)
    bad = 0
    for a, b in itertools.combinations(names, 2):
        A, B = allp[a], allp[b]
        ba, bb = A.bounding_box(), B.bounding_box()
        if (ba.max.X < bb.min.X or bb.max.X < ba.min.X or ba.max.Y < bb.min.Y or bb.max.Y < ba.min.Y
                or ba.max.Z < bb.min.Z or bb.max.Z < ba.min.Z):
            continue
        v = inter_vol(A, B)
        if v > 0.05 and not exempt(a, b):
            fail(f"[{st}] {a} x {b}: {v:.2f} mm3"); bad += 1
        elif v > 0.05 and exempt(a, b) and v > 60:
            warn(f"[{st}] {a} x {b}: {v:.1f} mm3 (exempt pair, large)")
    if not bad:
        ok(f"[{st}] no unintended interference")

section("knob rotation envelope")
knob = made["on"]["knob_body"] + refs["on"]["pegs"]
statics = [(n, s) for n, s in {**made["off"], **refs["off"]}.items()
           if n not in ("knob_body", "pegs", "tyre", "disc", "pcb", "components", "usbc_plug", "jack_plug")]
for ang in (0.0, 3.0, 17.0, 45.0):
    k = Rot(0, 0, ang) * knob
    for n, s in statics:
        v = inter_vol(k, s)
        if v > 0.05:
            fail(f"knob at {ang} deg x {n}: {v:.2f} mm3")
    # minimum clearance to the base shell and rings
    for n in ("base_shell", "ring_a", "ring_b", "halo_diffuser"):
        d = k.distance_to({**made["off"]}[n])
        if d < GAP_ROTATE - 0.02:
            fail(f"knob at {ang} deg: {d:.2f} mm to {n} (< {GAP_ROTATE})")
ok("knob clear of every static at 0/3/17/45 deg" if not any("knob at" in f for f in fails) else "see failures")
# wheels: engaged flanks nearly touch the groove; retracted (bush turned 180) the collar must clear the bore
kb = made["on"]["knob_body"]
for az in WHEEL_AZ:
    c_eng = made["on"][f"collar_{az}"]
    d = kb.distance_to(c_eng)
    (ok if d <= 0.12 else fail)(f"collar at {az}: {d:.3f} mm off the groove flanks (engaged)")
    c_ret = polar(az, WHEEL_R_RETRACTED, Z_WHEEL0) * wheel_collar()
    d2 = kb.distance_to(c_ret)
    (ok if d2 >= 0.4 else fail)(f"collar at {az}: {d2:.2f} mm clear of the bore when retracted (knob can drop on)")
# the disc passes the bore
(ok if R_SKIRT_BORE - R_DISC >= 0.4 else fail)(f"disc passes the straight bore: {R_SKIRT_BORE - R_DISC:.2f} mm radial clearance")
# disc, board, components are static but inside the knob: check them against the knob too
for n in ("disc", "pcb", "components"):
    d = knob.distance_to(refs["on"][n])
    (ok if d >= GAP_ROTATE - 0.02 else fail)(f"knob to {n}: {d:.2f} mm")
# tyre: engaged state must press 0.1-0.2 into the bore; idle must clear
d_on = made["on"]["knob_body"].distance_to(refs["on"]["tyre"])
(ok if d_on >= DRIVE_LIFT - 0.3 else fail)(f"tyre idle clearance {d_on:.2f} mm")
press = DRIVE_R + TYRE_D / 2 - R_FLANGE_BORE
(ok if 0.1 <= press <= 0.2 else fail)(f"tyre engaged press {press:.2f} mm (geometric)")

section("detent geometry")
for st in ("on", "off"):
    for i, az in enumerate(SLED_AZ):
        sh = sled_shift(i, st)
        m = ref_magnet(az, sh)
        # nearest peg tip to this magnet's face centre
        a = math.radians(az + sh)
        fx, fy = MAG_FACE_R * math.cos(a), MAG_FACE_R * math.sin(a)
        best = min(abs(((az + sh) - k * 6 + 180) % 360 - 180) for k in range(60))
        print(f"  [{st}] magnet {i} at {az + sh:7.2f} deg: nearest peg {best:5.2f} deg off")
ok(f"magnet face gap {MAG_FACE_GAP:.2f} mm (0.4 lip + 0.4 air)")
# in 'off' the two groups must be 3.0 deg apart modulo the 6 deg pitch
ok("groups 3.0 deg apart in 'off'") if abs(2 * RING_TRAVEL_DEG - 3.0) < 1e-6 else fail("group shift is not half a pitch")
ok(f"rocker swing {rocker_swing('off'):.1f} deg")

section("containment and stack")
for n, s in {**made["on"], **refs["on"]}.items():
    bb = s.bounding_box()
    rmax = max(math.hypot(x, y) for x in (bb.min.X, bb.max.X) for y in (bb.min.Y, bb.max.Y))
    if n in ("usbc_plug", "jack_plug"):
        continue
    if bb.max.Z > Z_KNOB_TOP + 0.01:
        fail(f"{n} above the knob top: {bb.max.Z:.2f}")
    if bb.min.Z < -PAD_T - 0.01:
        fail(f"{n} below the pad: {bb.min.Z:.2f}")
for n in ("base_plate", "base_shell", "halo_diffuser", "pad"):
    s = {**made["on"], **refs["on"]}[n]
    bb = s.bounding_box()
    r = max(abs(bb.min.X), bb.max.X, abs(bb.min.Y), bb.max.Y)
    (ok if r <= R_KNOB + 0.01 else fail)(f"{n} stays inside the knob's Ø{2*R_KNOB:.0f}: max {2*r:.1f}")
ok(f"height {Z_KNOB_TOP + PAD_T:.1f} mm incl. pad, Ø{2*R_KNOB:.0f}; knob {KNOB_FRACTION*100:.0f} % of the side")
ok(f"board zone z {Z_COMP_BOT:.1f}-{Z_DISC_BOT:.1f}; inner roof top {Z_INNER_ROOF:.1f}; tyre band {Z_TYRE0}-{Z_TYRE1}")
(ok if Z_INNER_ROOF <= Z_COMP_BOT - 0.4 else fail)("inner roof clears the board's components")
(ok if Z_SLED_TOP + 0.9 <= Z_DISC_BOT - 0.4 else fail)(f"tower caps ({Z_SLED_TOP + 0.9:.1f}) clear the disc ({Z_DISC_BOT})")

section("mass")
rho = {"base_plate": 7.85, "knob_body": 1.27}
for n, s in made["on"].items():
    d = rho.get(n, 1.27)
    print(f"  {n:14s} {s.volume/1000*d:7.1f} g  ({'steel' if d > 5 else 'PETG'}; Al {s.volume/1000*2.7:.0f} g)" if n.startswith("knob") else f"  {n:14s} {s.volume/1000*d:7.1f} g")
tot = sum(s.volume / 1000 * rho.get(n, 1.27) for n, s in made["on"].items())
ok(f"made parts total {tot:.0f} g (+ display ~60 g, bearings, magnets, motors)")

print("\n" + "=" * 62)
print(f"{len(fails)} failures, {len(warns)} warnings   ({time.time()-T0:.0f}s)")
for f in fails: print("  FAIL", f)

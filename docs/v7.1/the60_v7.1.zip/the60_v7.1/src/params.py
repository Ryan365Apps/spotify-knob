"""the 60 (Cadrane) - v7.1 parameter block.  Every dimension lives here.

v7.1 (2026-09-02, after the ruling that the knob must be ONE piece):
  - knob OD 125, ONE machined/printed piece: crown lip, skirt, knurl, both
    chamfers. Its bore is STRAIGHT (Ø116) so the Ø115 display passes through
    from below; the 60 pegs sit flush in the bore, and the three support
    wheels ride in a 90 deg V-GROOVE cut into the bore (a groove, unlike the
    v7 ridge, does not trap the disc)
  - each wheel sits on an ECCENTRIC bush in the base: half a turn with a hex
    key from below moves the wheel 0.9 mm inward so the knob drops on over
    the wheels; turned back it locks hard in the groove (OpenBuilds V-wheel
    practice). The steel plate goes on last, so the hex sockets are reachable
  - the six magnets sit in towers on TWO thin rings under the base's ledge;
    a worm turns ring A +1.5 deg and a rocker turns ring B -1.5 deg, so the two
    groups of three end up half a peg pitch apart and the clicks cancel:
    click strength 0-100 % in ~50 ms, held by the worm ("differential carrier")
  - full 360 deg halo over a rear cable TUNNEL; port board in the plate notch
  - self-turning knob: a flat gimbal-class motor with a Ø30 tyre on a
    pivoting plate, lifted off when idle
Units mm, degrees.  z = 0 is the steel plate's underside; the pad is below.
V = unverified (measure before trusting).
"""
import math as _m

# ------------------------------------------------------------ bought parts (V)
DISC_OD             = 115.00  # display disc (Waveshare 3.4C), spec sheet
DISC_T              = 6.00
ACTIVE_OD           = 87.60   # visible picture
DISC_HOLE_PCD       = 104.00  # V  rear mounting holes
DISC_HOLE_AZ        = [45, 135, 225, 315]
DISC_SCREW          = "M2.5 x 16 (V)"
DISC_STANDOFF       = 1.00    # V  board hangs this far below the disc
PCB_L, PCB_W, PCB_T = 85.50, 65.00, 1.60
PCB_COMP_H          = 6.40    # V  tallest component below the board
PCB_HOLE_DX, PCB_HOLE_DY = 58.00, 49.00
PCB_CORNER_R        = _m.hypot(PCB_L / 2, PCB_W / 2)     # 53.72  the enemy
WHEEL               = "623ZZ 3x10x4 + V-collar Ø13.2 (convex 90 deg V) on an eccentric bush"
WHEEL_OD            = 13.20   # over the V apex
WHEEL_W             = 4.00
WHEEL_BORE          = 3.00
WHEEL_V_H           = 1.30    # radial height of the collar's V (flanks 45 deg); the knob's groove is the same depth
WHEEL_V_FLAT        = 0.60    # flat on the collar apex and in the groove root: contact is on the flanks only
WHEEL_ECC           = 0.90    # eccentric bush offset: half a turn moves the wheel 1.8 mm (out of a 1.3 groove)
BUSH_D, BUSH_FLANGE_D = 5.00, 7.00
BUSH_HEX            = 2.00    # hex socket A/F in the bush's underside
WHEEL_AZ            = [0, 120, 240]
MAG_R, MAG_T, MAG_H = 3.00, 3.00, 6.00   # radial x tangential x AXIAL (6 mm vertical)
MAG_GRADE           = "N42 (N52 option)"
PEG_D               = 3.00    # chrome-steel ball pressed into a blind hole
PEG_N               = 60
PEG_DEPTH           = 2.80    # Ø3 ball pressed 2.8 deep: 0.2 proud of the bore, 0.7 of wall left under the knurl root
PEG_PROUD           = PEG_D - PEG_DEPTH                  #  0.20
CAMMOTOR_D, CAMMOTOR_L = 8.0, 20.0        # V  Ø8 coreless planetary gearmotor for the carrier rings, lies on the pad
WORM_D, WORM_L      = 4.50, 7.00
DRIVE_MOTOR_D, DRIVE_MOTOR_H = 16.0, 7.0    # V  flat gimbal-class BLDC envelope; sits on the pad in a hole in the plate
TYRE_D, TYRE_T      = 51.00, 2.00           # rubber-rimmed disc on the drive motor's shaft (Ø51 keeps the motor inside the rings with the bigger bore)
SOLENOID_D, SOLENOID_L = 6.0, 10.0          # V  push solenoid for the lift-off
ENC                 = "AEDR-8300 + index"   # 4 x 1.5 x 1.2 on a 6 x 8 board
ENC_GAP             = 2.00
LRA_D, LRA_H        = 10.0, 3.6
SPEAKER_D, SPEAKER_T = 36.0, 5.0
SPEAKER_APERTURE    = 34.0
SUPERCAP_D, SUPERCAP_L = 8.0, 16.0          # V  x2 envelope; the real 10 F bank (Ø10 x 30) needs its own pocket - open item
PORT_BOARD_L, PORT_BOARD_W, PORT_BOARD_T = 40.0, 14.0, 1.6
PORT_BOARD_Z0       = 0.95    # on 1 mm standoffs on the pad: USB-C centre lands at z 1.75
PORT_BOARD_T_OFF    = -12.0   # tangential offset of the board's centre (+x side; clear of the supercaps)
USBC_T_OFF, JACK_T_OFF = -10.0, 2.0
JACK_AXIS_Z         = 2.20    # sink-mount jack: plug Ø6.5 spans -1.05..5.45 under the 6.0 tunnel ceiling; body top 4.7 under ring A (4.8)
USBC_W, USBC_H, USBC_DEPTH = 9.0, 3.2, 7.5
JACK_D, JACK_BODY_L, JACK_BODY_W, JACK_BODY_H = 6.0, 14.5, 6.0, 5.0
PLUG_USBC_W, PLUG_USBC_H, PLUG_USBC_L = 11.0, 6.5, 16.0
PLUG_JACK_D, PLUG_JACK_L = 6.5, 14.0
LIGHT_SENSOR_HOLE   = 2.5

# ------------------------------------------------------------ standing rules
GAP_ROTATE          = 0.40    # knob to anything static
GAP_STATIC          = 0.15
GAP_RUN             = 0.30
WALL_MIN            = 1.60
INSERT_M3_D, INSERT_M3_L = 4.0, 5.7
INSERT_M2_D, INSERT_M2_L = 3.2, 4.0
TAP_M25_D           = 2.05

# ------------------------------------------------------------ radii
R_DISC              = DISC_OD / 2                        # 57.50
R_SKIRT_BORE        = R_DISC + 0.50                      # 58.00  STRAIGHT bore, the disc passes through it
R_KNOB              = 62.50                              # knob outside, Ø125
EDGE_OFF            = R_KNOB - 61.50                     # everything at the outer edge grew by this from v7
R_FLANGE_BORE       = R_SKIRT_BORE                       # (kept name) pegs, tyre band, code band are on the same bore
R_CROWN_IN          = ACTIVE_OD / 2 + 0.70               # 44.50  rim reaches in to here
SKIRT_WALL          = R_KNOB - R_SKIRT_BORE              #  3.60
R_GROOVE_ROOT       = R_SKIRT_BORE + WHEEL_V_H           # 59.30  90 deg V-groove in the bore, 0.6 flat at the root
WHEEL_AXIS_R        = R_GROOVE_ROOT - WHEEL_OD / 2 - 0.07 # 52.63  flanks 0.05 off the groove's (the eccentric sets the real preload)
BUSH_R              = WHEEL_AXIS_R - WHEEL_ECC           # 51.73  bush axis; eccentric points outward when engaged
WHEEL_R_RETRACTED   = BUSH_R - WHEEL_ECC                 # 50.83  wheel axis with the bush turned half a turn
WHEEL_POST_D        = 8.00                               # post on the ledge with the Ø5.1 bush bore through it
R_LEDGE_OUT         = R_FLANGE_BORE - PEG_PROUD - GAP_ROTATE   # 57.40  base's outer face: 0.4 from the peg tips
R_LEDGE_IN          = 49.00
R_INNER_ROOF        = 49.50
DISC_POST_D         = 5.00
DISC_POST_R         = DISC_HOLE_PCD / 2                  # 52.00
# magnet carriers: TWO thin rings under the ledge, each with three TOWERS rising
# through slots in the ledge to hold its magnets at the peg height. Ring A turns
# +1.5 deg and ring B -1.5 deg (a rocker links them), so the two groups of three
# magnets end up half a peg pitch apart and the clicks cancel. Ring A is driven
# by the N20's worm on a toothed tab; the worm holds the position.
SLED_AZ             = [30, 90, 150, 210, 270, 330]        # magnet azimuths (A: 30/150/270, B: 90/210/330)
SLED_GROUP          = [+1, -1, +1, -1, +1, -1]           # +1 = ring A, -1 = ring B
RING_TRAVEL_DEG     = 1.50                               # each ring; groups end 3.0 deg = half a peg pitch apart
SLED_R_OUT          = R_LEDGE_OUT                        # 55.50 lip face (rotating bore is 0.4 away)
MAG_LIP_T           = 0.40                               # radial lip in front of the magnet face
MAG_FACE_R          = SLED_R_OUT - MAG_LIP_T             # 55.10
MAG_FACE_GAP        = R_FLANGE_BORE - PEG_PROUD - MAG_FACE_R   #  0.80 to the peg tips (0.4 lip + 0.4 air), as v7
SLED_R_IN           = MAG_FACE_R - MAG_R - 1.00          # 51.10 inner wall 1.0
SLED_WALL_T         = 0.80                               # tangential walls
SLED_W              = MAG_T + 2 * SLED_WALL_T            #  4.60 tangential (the tower)
SLED_TRAVEL         = _m.radians(RING_TRAVEL_DEG) * R_LEDGE_OUT   #  1.51 mm at the tower
POCKET_CLR          = 0.30
POCKET_W            = SLED_W + 2 * (SLED_TRAVEL + POCKET_CLR)   # 8.08
MAG_LIP_W           = 0.60                               # lips at each tangential end of the face
RING_R_IN, RING_R_OUT = 41.00, 45.50                    # both rings: inside the tunnel's back wall (r 46) and the disc-screw heads
RING_A_Z0, RING_A_Z1 = 4.80, 6.00                        # lower ring (worm-driven, teeth on its inner face)
RING_B_Z0, RING_B_Z1 = 6.20, 7.30                        # upper ring (rocker-driven, opposite sense)
RING_SEAT_Z         = 4.60                               # floor ring both rest on
LEG_Z0, LEG_Z1      = 7.60, 8.40                         # horizontal legs from the risers out to the towers
RISER_R_IN, RISER_R_OUT = 39.50, 40.80                   # risers hang inside both rings
TOWER_R_IN          = SLED_R_IN                          # 51.10
WORM_MESH_AZ, WORM_MESH_ARC = 324.0, 16.0                # ring A's inner face carries teeth here (drawn smooth)
WORM_AXIS_R         = 36.0                               # tangential axis; the worm meshes a tab hanging under ring A
CAMMOTOR_AZ         = 350.0                              # body t -10..+10, worm at t -17..-10 meshing ring A's tab
RING_A_TAB_Z0       = 2.40                               # ring A's toothed tab hangs down to here (teeth on its inner face, r 42.3)
RING_A_TAB_R_IN     = 38.50
ROCKER_AZ           = 255.0
ROCKER_PIVOT_R      = 40.75
ROCKER_PIN_R_A, ROCKER_PIN_R_B = 44.0, 37.5              # pins into a slot in ring A (r 44) and ring B's inward tab (r 37.5)
ROCKER_Z0, ROCKER_Z1 = 3.40, 4.40
RING_B_TAB_ARC      = 10.0
ROCKER_PIN_D        = 2.00
RING_B_TAB_R_IN     = 36.0
# drive
DRIVE_AZ            = 180.0                              # the widest free sector: towers at 150/210, posts at 135/225
DRIVE_R             = R_FLANGE_BORE - TYRE_D / 2 + 0.15  # 32.65 tyre pressed 0.15 into the bore when engaged
DRIVE_LIFT          = 1.00                               # tyre backs off this far when idle
DRIVE_ARM_L         = 14.0                               # pivot sits this far along the tangent, so a swing moves the tyre radially
DRIVE_PLATE_HOLE_D  = DRIVE_MOTOR_D + 3.0                # hole in the steel plate the motor sits in (on the pad)
Z_DRIVE_ARM0, Z_DRIVE_ARM1 = 7.60, 8.40                  # the pivot arm lies above ring B, at the legs' height (different azimuths)
SOLENOID_AZ         = 205.0                              # radial push solenoid; its plunger hits a lug on the arm's extension
RING_B_FEET_AZ      = [60, 120, 240]
# encoder, LRA, others
ENC_AZ              = 60.0
LRA_AZ, LRA_R       = 105.0, 44.0
SUPERCAP_AZ, SUPERCAP_R = 105.0, 29.0   # two cells lying RADIALLY at 105 and 119 deg, r 21-37
SUPERCAP_AZ2        = 119.0
AZ_PORTS            = 90.0                               # sockets face away from the user
TUNNEL_W            = 34.0
TUNNEL_R_BACK       = 46.0
PLATE_SCREW_AZ      = [20, 130, 220, 300]
PLATE_SCREW_R       = 37.5
BOSS_D              = 5.60
Z_BOSS_TOP          = 9.00
AZ_LIGHT_SENSOR     = 110.0

# ------------------------------------------------------------ z stack
PAD_T               = 1.50
BASE_PLATE_T        = 3.00
Z_PLATE_TOP         = BASE_PLATE_T                       #  3.0
PLINTH_H            = 3.00
Z_PLINTH_TOP        = Z_PLATE_TOP + PLINTH_H             #  6.0  tunnel ceiling
HALO_H              = 3.00
HALO_Z0             = Z_PLINTH_TOP                       #  6.0
HALO_Z1             = HALO_Z0 + HALO_H                   #  9.0
Z_SKIRT_BOT         = HALO_Z1 + 0.60                     #  9.6  shadow gap 0.6
Z_HALO_ROOF         = HALO_Z1 + 0.40                     #  9.4
Z_LEDGE_TOP         = Z_HALO_ROOF + 1.00                 # 10.4
Z_TYRE0, Z_TYRE1    = 10.20, 12.20                       # tyre band on the flange bore (smooth to 12.4)
Z_SLED_BOT          = Z_LEDGE_TOP                        # 10.4
Z_MAG_BOT           = Z_SLED_BOT + 1.20                  # 11.6  tower floor 1.0 + 0.2
Z_MAG_TOP           = Z_MAG_BOT + MAG_H                  # 17.6
PEG_Z               = (Z_MAG_BOT + Z_MAG_TOP) / 2        # 14.6  radial peg axis
Z_SLED_TOP          = Z_MAG_TOP + 0.40                   # 18.0
Z_CODE0, Z_CODE1    = Z_MAG_TOP - 0.20, Z_SLED_TOP + 0.40   # 17.4-18.4 code band (encoder reads here)
Z_POST_TOP_BUSH     = 18.40                              # wheel post top; the bush flange sits on it
Z_WHEEL0            = 19.00                              # bearing bottom (on the bush flange)
Z_WHEEL1            = Z_WHEEL0 + WHEEL_W                 # 23.0
Z_RIDGE_MID         = (Z_WHEEL0 + Z_WHEEL1) / 2          # 21.0
Z_GROOVE0           = Z_RIDGE_MID - WHEEL_V_H - WHEEL_V_FLAT / 2   # 19.4  groove opening at the bore
Z_GROOVE1           = Z_RIDGE_MID + WHEEL_V_H + WHEEL_V_FLAT / 2   # 22.6
Z_RIDGE0, Z_RIDGE1  = Z_GROOVE0, Z_GROOVE1               # (kept names)
Z_DISC_BOT          = Z_WHEEL1 + 0.40                    # 23.4
Z_DISC_TOP          = Z_DISC_BOT + DISC_T                # 29.4  glass
Z_PCB_TOP           = Z_DISC_BOT - DISC_STANDOFF         # 22.4
Z_PCB_BOT           = Z_PCB_TOP - PCB_T                  # 20.8
Z_COMP_BOT          = Z_PCB_BOT - PCB_COMP_H             # 14.4  board zone floor
Z_INNER_ROOF        = Z_COMP_BOT - 0.60                  # 13.8 inner roof top
Z_INNER_ROOF_BOT    = Z_INNER_ROOF - 1.00                # 12.8
RIM_GAP             = 0.40
Z_CROWN_BOT         = Z_DISC_TOP + RIM_GAP               # 29.8  crown underside over the glass
CROWN_T             = 3.00
Z_CROWN_TOP         = Z_CROWN_BOT + CROWN_T              # 32.8
Z_KNOB_TOP          = Z_CROWN_TOP
CH_TOP              = 2.50    # smooth 45 deg outer chamfer on the crown (diamond-cut on the CNC part)
CH_IN               = 1.00    # smooth chamfer at the glass
CH_BOT              = 1.20    # skirt's lower outside edge
KNOB_FRACTION       = (Z_KNOB_TOP - Z_SKIRT_BOT) / Z_KNOB_TOP   # 0.71

# knurl (side of the body between the lower chamfer and the crown seat)
KNURL_ON            = True
KNURL_N             = 56
KNURL_DEPTH         = 1.00
KNURL_HELIX_DEG     = 30.0
KNURL_ROOT_OFF      = 0.50
KNURL_BANDS         = 6
KNURL_BAND_OV       = -0.03
KNURL_LAND          = 0.80
KNURL_Z0            = Z_SKIRT_BOT + CH_BOT + KNURL_LAND  # 11.6
KNURL_Z1            = Z_KNOB_TOP - CH_TOP - KNURL_LAND  # 29.5  up to a plain land under the top chamfer
KNURL_PITCH         = _m.pi * 2 * R_KNOB / KNURL_N       # 6.9

# halo geometry
LED_WALL_R_IN, LED_WALL_R_OUT = 55.50, 57.00              # LED board on its outer face
LED_BOARD_T         = 1.20
DIFF_R_IN           = LED_WALL_R_OUT + LED_BOARD_T + 0.30 # 58.50
DIFF_R_OUT_BOT      = 61.10 + EDGE_OFF
DIFF_R_OUT_TOP      = R_KNOB                             # 61.50, 7.6 deg lean
PLINTH_R_IN, PLINTH_R_OUT = 55.50, 60.60 + EDGE_OFF
PLATE_R             = 61.00 + EDGE_OFF
PLATE_R_BOT         = 60.60 + EDGE_OFF
LED_N               = 90

# printing
PRINT_MATERIAL      = "PETG"
LAYER               = 0.20

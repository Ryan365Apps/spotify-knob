the 60 - v7.1 - printable parts (knob is ONE piece; wheels on eccentric bushes)

base_plate     STEEL - laser-cut from 3 mm S275 (DXF from the STEP's top face)
base_shell     print upright on the plinth, no supports, 0.2 mm layers
halo_diffuser  print on its underside; natural/translucent PETG
knob_body      ONE PIECE, KNURLED. print TOP FACE DOWN (flip 180 deg), 0.16 mm layers, no supports; peg holes are horizontal
knob_body_smooth the same knob without the knurl - quick fit-check print
ring_a         print as modelled (ring flat on the bed); towers vertical
ring_b         print as modelled
rocker         print flat as modelled
drive_plate    print flat as modelled
tyre_hub       print flat, 0.12 mm layers; fit a 2 mm-section O-ring
collar_0       print axis vertical, 0.12 mm layers (x3)
bush_0         print pin UP, 0.12 mm layers (x3); brass in production

Bought: 3x 623ZZ (+ 3x Ø3 dowels if the bushes are brass); 6x 3x3x6 N42 magnets; 60x Ø3 chrome-steel balls; Ø8 planetary gearmotor + worm;
flat gimbal motor Ø16x7 (V); O-ring 2 mm section ID ~45; 6 mm push solenoid; AEDR-8300; LRA; speaker; port board; LED ring board.

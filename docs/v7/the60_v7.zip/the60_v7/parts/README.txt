the 60 - v7 - printable parts

base_plate     STEEL - laser-cut from 3 mm S275 (DXF from the STEP's top face)
base_shell     print upright on the plinth, no supports, 0.2 mm layers
halo_diffuser  print on its underside; natural/translucent PETG
knob_body      KNURLED. print FLANGE DOWN (as modelled), 0.16 mm layers; peg holes are horizontal
knob_body_smooth  the same part without the knurl - quick fit-check print
knob_crown     print TOP FACE DOWN (flip 180 deg); chamfers become 45 deg overhangs
ring_a         print as modelled (ring flat on the bed); towers vertical
ring_b         print as modelled
rocker         print flat as modelled
drive_plate    print flat as modelled
tyre_hub       print flat, 0.12 mm layers; fit a 2 mm-section O-ring
collar_0       print axis vertical, 0.12 mm layers (x3)

Bought: 3x 623ZZ + Ø3x9 dowel pins; 6x 3x3x6 N42 magnets; 60x Ø3 chrome-steel balls; Ø8 planetary gearmotor + worm;
flat gimbal motor Ø16x7 (V); O-ring 2 mm section ID ~41; 6 mm push solenoid; AEDR-8300; LRA; speaker; port board; LED ring board.

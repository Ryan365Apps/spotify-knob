"""Technical drawings for every MADE component of the 60 v7 (bought parts are
references only). One A3 sheet per part + an assembly sheet.
python drawings.py [sheet ...]   -> out/dwg/NN-name.png + .pdf"""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dwg import *
from model import *
import model as M

DWG = os.path.join(OUT, "dwg"); os.makedirs(DWG, exist_ok=True)
PETG = 1.27
def g(shape, rho=PETG): return shape.volume / 1000 * rho
def S(u, v, view): return view.to_sheet(u, v)

# =====================================================================================
def sheet_crown():
    c = knob_crown()
    sh = Sheet("KNOB CROWN", "60-07-05", "PETG (proto) / 6082 Al, CNC (prod)", "matt black hardcoat Type III; chamfer diamond-cut then clear-sealed",
               "1:1", g(c), notes="Prints top face down.\nSix M2 heat-set inserts from below.\nChamfer knurl-free; CH_TOP diamond-cut after anodising.", stock="Ø125 x 5 Al disc")
    ax = sh.ax
    # section A-A (front), upper-left
    v = View(sh, 110, 200, 1.0)
    section_view(v, c, "XZ", 0.0, direction="front")
    centreline_v(ax, v.ox, v.oy - 8, v.oy + 45)
    # dimensions (model coords via S)
    x1, _ = S(-R_KNOB, 0, v); x2, _ = S(R_KNOB, 0, v)
    zb, zt = Z_CROWN_BOT - CROWN_SEAT_T, Z_CROWN_TOP
    _, yb = S(0, zb, v); _, yt = S(0, zt, v)
    dim_h(ax, x1, x2, yt + 14, yt, f"Ø{2*R_KNOB:.0f}")
    xi1, _ = S(-R_CROWN_IN, 0, v); xi2, _ = S(R_CROWN_IN, 0, v)
    dim_h(ax, xi1, xi2, yt + 8, yt, f"Ø{2*R_CROWN_IN:.1f}")
    xr1, _ = S(-(CROWN_REBATE_R - GAP_STATIC), 0, v); xr2, _ = S(CROWN_REBATE_R - GAP_STATIC, 0, v)
    dim_h(ax, xr1, xr2, yb - 8, yb, f"Ø{2*(CROWN_REBATE_R - GAP_STATIC):.1f}", above=False)
    dim_v(ax, yb, yt, x2 + 10, x2, f"{zt - zb:.1f}")
    dim_v(ax, S(0, Z_CROWN_BOT, v)[1], yt, x2 + 18, x2, f"{CROWN_T:.1f}")
    dim_leader(ax, *S(R_KNOB - CH_TOP / 2, zt - CH_TOP / 2 + 0.3, v), x2 + 6, yt + 5, f"{CH_TOP:.1f} x 45°")
    dim_leader(ax, *S(-R_CROWN_IN - CH_IN / 2, zt - CH_IN / 2 + 0.3, v), x1 - 4, yt + 5, f"{CH_IN:.1f} x 45°", ha="right")
    surface_mark(ax, *S(R_KNOB - 8, zt, v), "0.8")
    view_title(ax, v.ox, yt + 22, "A-A")
    # plan view from below (inserts visible), right
    p = View(sh, 300, 165, 0.9)
    p.project(c, "bottom", hidden=False)
    centre_cross(ax, p.ox, p.oy, 62)
    for az in CROWN_SCREW_AZ:
        cx, cy = S(-CROWN_SCREW_R * math.cos(math.radians(az)), CROWN_SCREW_R * math.sin(math.radians(az)), p)
        centre_cross(ax, cx, cy, 3.0)
    ax.add_patch(MplCircle((p.ox, p.oy), p.s * CROWN_SCREW_R, facecolor="none", edgecolor=BLACK, lw=0.25, ls=(0, (8, 2, 1.5, 2))))
    dim_leader(ax, *S(-CROWN_SCREW_R * math.cos(math.radians(183)), CROWN_SCREW_R * math.sin(math.radians(183)), p), p.ox + 70, p.oy + 40, f"6x M2 heat-set insert Ø{INSERT_M2_D} x {INSERT_M2_L}\non PCD {2*CROWN_SCREW_R:.1f}, at 3° + n·60°")
    section_marks(ax, p.ox - 62, p.oy - 66, p.oy + 66, "A", side=-1)
    view_title(ax, p.ox, p.oy - 72, "VIEW FROM BELOW")
    note_block(ax, 20, 100, ["1. Rim reaches inward over the display's dead border to Ø89.0; picture is Ø87.6.",
                            "2. Underside sits 0.4 above the glass (Z_CROWN_BOT); rebate 0.6 deep locates on the body.",
                            "3. Production part: CNC 6082, Type III hardcoat; the 45° chamfer is diamond-cut after",
                            "   anodising and clear-sealed. Coin-edge reeding on the rim is optional (600 x 0.7 mm).",
                            "4. Prototype: PETG, 0.2 mm layers, top face down, no supports."])
    return sh.save(os.path.join(DWG, "05-knob_crown.png"))

# =====================================================================================
def sheet_diffuser():
    d = halo_diffuser()
    sh = Sheet("HALO DIFFUSER", "60-07-03", "opal PMMA (Satinice 0D010 DF, 83 %) / PETG natural (proto)", "as moulded / laser-cut", "2:1", g(d, 1.19),
               notes="360° ring. Sits on the plinth top, 0.6 under the knob skirt.\nOuter face leans out 7.6°.", stock="Ø125 x 3 sheet")
    ax = sh.ax
    v = View(sh, 150, 190, 2.0)
    section_view(v, d, "XZ", 0.0, direction="front")
    centreline_v(ax, v.ox, v.oy - 4, v.oy + 30)
    x1, yb = S(-DIFF_R_OUT_TOP, HALO_Z0, v); x2, yt = S(DIFF_R_OUT_TOP, HALO_Z1, v)
    dim_h(ax, x1, x2, yt + 16, yt, f"Ø{2*DIFF_R_OUT_TOP:.1f}")
    xb1, _ = S(-DIFF_R_OUT_BOT, 0, v); xb2, _ = S(DIFF_R_OUT_BOT, 0, v)
    dim_h(ax, xb1, xb2, yb - 8, yb, f"Ø{2*DIFF_R_OUT_BOT:.1f}", above=False)
    xi1, _ = S(-DIFF_R_IN, 0, v); xi2, _ = S(DIFF_R_IN, 0, v)
    dim_h(ax, xi1, xi2, yt + 9, yt, f"Ø{2*DIFF_R_IN:.1f}")
    dim_v(ax, yb, yt, x2 + 10, x2, f"{HALO_H:.1f}")
    lean = math.degrees(math.atan((DIFF_R_OUT_TOP - DIFF_R_OUT_BOT) / HALO_H))
    dim_leader(ax, *S(DIFF_R_OUT_BOT + 0.2, HALO_Z0 + 1.5, v), x2 + 20, yb + 2, f"outer face leans {lean:.1f}°")
    view_title(ax, v.ox, yt + 24, "A-A")
    p = View(sh, 300, 150, 0.8)
    p.project(d, "top", hidden=False)
    centre_cross(ax, p.ox, p.oy, 55)
    section_marks(ax, p.ox - 55, p.oy - 58, p.oy + 58, "A", side=-1)
    note_block(ax, 20, 110, ["1. LEDs sit 1.5 mm inside the inner face (r 57.0-58.2 board); a 4 mm stand-off needs the",
                            "   next revision's ring board at r 54.5 - see V6C proposal §3.",
                            "2. Inner face and underside matt; outer face as supplied.",
                            "3. Prototype: natural PETG, 0.2 layers, printed on its underside."])
    return sh.save(os.path.join(DWG, "03-halo_diffuser.png"))

# =====================================================================================
def sheet_collar():
    c = wheel_collar()
    sh = Sheet("WHEEL V-COLLAR (x3)", "60-07-10", "acetal (POM) turned / PETG (proto)", "as turned", "5:1", g(c, 1.41),
               notes="Press fit over a 623ZZ bearing (Ø10 x 4).\n90° V-groove runs in the knob body's ridge.\nThree per unit.", stock="Ø16 POM rod")
    ax = sh.ax
    v = View(sh, 120, 170, 5.0)
    # section through the axis: the collar is built with its axis along Z; show it XZ
    section_view(v, c, "XZ", 0.0, direction="front")
    centreline_v(ax, v.ox, v.oy - 10, v.oy + 5 * WHEEL_W + 10)
    ro, ri, w, gd = WHEEL_OD / 2, 5.05, WHEEL_W, WHEEL_GROOVE_D
    x1, yb = S(-ro, 0, v); x2, yt = S(ro, w, v)
    dim_h(ax, x1, x2, yt + 14, yt, f"Ø{WHEEL_OD:.1f}")
    xi1, _ = S(-ri, 0, v); xi2, _ = S(ri, 0, v)
    dim_h(ax, xi1, xi2, yb - 8, yb, "Ø10.10 H7 (press on 623ZZ)", above=False)
    xr1, _ = S(-(ro - gd), 0, v); xr2, _ = S(ro - gd, 0, v)
    dim_h(ax, xr1, xr2, yt + 7, yt, f"Ø{2*(ro-gd):.1f} groove root")
    dim_v(ax, yb, yt, x2 + 12, x2, f"{w:.1f}")
    dim_v(ax, S(0, w / 2 - gd, v)[1], S(0, w / 2 + gd, v)[1], x2 + 20, x2, f"{2*gd:.1f}")
    dim_ang(ax, *S(ro - gd, w / 2, v), 9, -45, 45, "90°")
    view_title(ax, v.ox, yt + 22, "A-A")
    p = View(sh, 290, 165, 5.0)
    p.project(c, "top", hidden=False)
    centre_cross(ax, p.ox, p.oy, 40)
    section_marks(ax, p.ox - 40, p.oy - 42, p.oy + 42, "A", side=-1)
    note_block(ax, 20, 90, ["1. The rims (Ø13.2) run 0.35 clear of the skirt bore Ø115.8; the V flanks meet the ridge at 45°.",
                            "2. Production: turn from POM or PEEK; press over the bearing warm.",
                            "3. Prototype: PETG, printed axis vertical, 0.12 layers."])
    return sh.save(os.path.join(DWG, "10-wheel_collar.png"))

SHEETS = {"crown": sheet_crown, "diffuser": sheet_diffuser, "collar": sheet_collar}

# =====================================================================================
def _plan_common(ax, p, r_cross=64):
    centre_cross(ax, p.ox, p.oy, r_cross)

def sheet_plate():
    pl = base_plate()
    sh = Sheet("BASE PLATE", "60-07-01", "mild steel S275, laser-cut 3 mm", "zinc plate + black passivate (or powder coat)", "1:1", g(pl, 7.85),
               notes="Edge frustum 0.4 lean (laser taper, cosmetic).\nRubber pad 1.5 bonded below (nitrile).\nAll pockets go through; parts sit on the pad.", stock="3 mm sheet, Ø125")
    ax = sh.ax
    p = View(sh, 150, 160, 1.15)
    p.project(pl, "top", hidden=False)
    _plan_common(ax, p, 72)
    # dimensions
    x1, _ = S(-PLATE_R, 0, p); x2, _ = S(PLATE_R, 0, p)
    _, ytop = S(0, PLATE_R, p)
    dim_h(ax, x1, x2, ytop + 12, ytop, f"Ø{2*PLATE_R:.0f} (top) / Ø{2*PLATE_R_BOT:.1f} (bottom)")
    xs1, _ = S(-SPEAKER_APERTURE / 2, 0, p); xs2, _ = S(SPEAKER_APERTURE / 2, 0, p)
    dim_h(ax, xs1, xs2, S(0, -SPEAKER_APERTURE / 2, p)[1] - 8, S(0, -SPEAKER_APERTURE / 2, p)[1], f"Ø{SPEAKER_APERTURE:.0f} speaker", above=False)
    # tunnel notch
    xt1, yt1 = S(-TUNNEL_W / 2, TUNNEL_R_BACK, p); xt2, _ = S(TUNNEL_W / 2, TUNNEL_R_BACK, p)
    dim_h(ax, xt1, xt2, ytop + 5, ytop, f"{TUNNEL_W:.0f}")
    dim_v(ax, yt1, ytop, x2 + 8, S(TUNNEL_W / 2, 0, p)[0], f"{PLATE_R - TUNNEL_R_BACK:.0f}")
    # screws
    for az in PLATE_SCREW_AZ:
        cx, cy = S(PLATE_SCREW_R * math.cos(math.radians(az)), PLATE_SCREW_R * math.sin(math.radians(az)), p)
        centre_cross(ax, cx, cy, 4.0)
    ax.add_patch(MplCircle((p.ox, p.oy), p.s * PLATE_SCREW_R, facecolor="none", edgecolor=BLACK, lw=0.25, ls=(0, (8, 2, 1.5, 2))))
    cx, cy = S(PLATE_SCREW_R * math.cos(math.radians(20)), PLATE_SCREW_R * math.sin(math.radians(20)), p)
    dim_leader(ax, cx, cy, p.ox + 95, p.oy + 55, f"4x Ø3.4 through, csk Ø6.6 x 90° from below\nPCD {2*PLATE_SCREW_R:.0f}, at 20°, 130°, 220°, 300°")
    # drive motor hole, cam motor slot, port pocket
    (mx, my), _ = drive_geometry(True)
    hx, hy = S(mx - DRIVE_LIFT / 2 * math.cos(math.radians(DRIVE_AZ)), my - DRIVE_LIFT / 2 * math.sin(math.radians(DRIVE_AZ)), p)
    centre_cross(ax, hx, hy, 12)
    dim_leader(ax, hx - p.s * DRIVE_PLATE_HOLE_D / 2, hy, p.ox - 100, p.oy - 30, f"Ø{DRIVE_PLATE_HOLE_D:.0f} drive-motor well\ncentre r {math.hypot(mx, my) - DRIVE_LIFT / 2:.1f} at 180°", ha="right")
    cx, cy = S(WORM_AXIS_R * math.cos(math.radians(CAMMOTOR_AZ)), WORM_AXIS_R * math.sin(math.radians(CAMMOTOR_AZ)), p)
    dim_leader(ax, cx, cy, p.ox + 90, p.oy - 45, f"slot {CAMMOTOR_D + 1:.0f} x {CAM_Y1 - CAM_Y0 + 1:.0f} for the carrier gearmotor,\ntangential at r {WORM_AXIS_R:.0f}, {CAMMOTOR_AZ:.0f}°")
    bx, by = S(0, PORT_R_C + 2, p)
    dim_leader(ax, bx + p.s * 12, by, p.ox + 90, p.oy + 30, f"port-board pocket {PORT_BOARD_W + 3.5:.1f} x {PORT_BOARD_L + 4:.0f}\ncentred r {M.PORT_R_C + 0.25:.2f}, offset {PORT_BOARD_T_OFF:+.0f} tangential")
    section_marks(ax, p.ox, p.oy - 76, p.oy + 76, "A", side=-1)
    view_title(ax, p.ox, p.oy - 88, "PLAN (from above)")
    # section A-A (YZ plane through the tunnel) — shown below-right
    v = View(sh, 300, 225, 1.15)
    section_view(v, pl, "YZ", 0.0, direction="right")
    centreline_v(ax, v.ox, v.oy - 5, v.oy + 12)
    y1, yb = S(-PLATE_R, 0, v); y2, yt = S(PLATE_R, BASE_PLATE_T, v)
    dim_v(ax, yb, yt, y2 + 8, y2, f"{BASE_PLATE_T:.0f}")
    dim_leader(ax, *S(-PLATE_R + 0.2, BASE_PLATE_T - 1.5, v), y1 - 6, yt + 10, "edge leans 0.4 over 3", ha="right")
    view_title(ax, v.ox, yt + 20, "A-A (from +x; +y to the right)")
    note_block(ax, 20, 60, ["1. Ballast: the plate is the object's mass. Cut edges deburred; countersinks from the underside.",
                            "2. Pockets: drive-motor well Ø19, gearmotor slot, port-board pocket and tunnel notch all go through;",
                            "   those parts sit on the rubber pad. The pad is notched at the tunnel only.",
                            "3. Bond the pad with 3M 468MP; nitrile or neoprene, never silicone."])
    return sh.save(os.path.join(DWG, "01-base_plate.png"))

# =====================================================================================
def sheet_shell():
    s = base_shell()
    sh = Sheet("BASE SHELL", "60-07-02", "PETG black (proto) / PA12 MJF (prod)", "as printed; matt black inner faces", "1:1", g(s),
               notes="Prints upright on its plinth, no supports\n(ledge ceilings bridge < 4 mm).\nInserts: 5x M3 in the bosses. Pins pressed after printing.", stock="—", sheet=1, of=2)
    ax = sh.ax
    p = View(sh, 130, 165, 1.05)
    p.project(s, "top", hidden=False)
    _plan_common(ax, p, 66)
    # feature callouts
    def leader_az(az, r, tx, ty, text, ha="left"):
        cx, cy = S(r * math.cos(math.radians(az)), r * math.sin(math.radians(az)), p)
        dim_leader(ax, cx, cy, tx, ty, text, ha=ha)
    leader_az(30, 53.5, p.ox + 80, p.oy + 78, f"6x tower pockets, {POCKET_W:.1f} wide between guide walls,\nat 30° + n·60°; cap over each tower")
    leader_az(0, WHEEL_AXIS_R, p.ox + 80, p.oy + 8, f"3x wheel posts Ø{WHEEL_POST_D:.0f} on Ø7 feet, r {WHEEL_AXIS_R:.2f},\nat 0°/120°/240°; Ø2.9 pin hole 5.2 deep")
    leader_az(45, DISC_POST_R, p.ox + 80, p.oy + 50, f"4x display posts Ø{DISC_POST_D:.0f}, r {DISC_POST_R:.0f} (PCD {DISC_HOLE_PCD:.0f}, V),\nat 45° + n·90°; Ø2.8 through for M2.5 from below")
    leader_az(ENC_AZ, 51.0, p.ox + 80, p.oy + 30, f"encoder tower at {ENC_AZ:.0f}°, pocket for a\n6 x 8 sensor board, face 2.0 from the code band")
    leader_az(AZ_PORTS, 57.0, p.ox + 12, p.oy + 84, f"cable tunnel {TUNNEL_W:.0f} wide, back wall r {TUNNEL_R_BACK:.0f},\nceiling z {Z_PLINTH_TOP:.0f}; jack hole Ø{PLUG_JACK_D + 0.6:.1f}")
    leader_az(180, 40, p.ox - 62, p.oy - 78, f"drive well: ledge and inner roof cut\nr {TYRE_SWEEP_R:.1f} about the tyre centre", ha="right")
    leader_az(20, PLATE_SCREW_R, p.ox + 80, p.oy - 30, f"4x bosses Ø{BOSS_D:.1f}, M3 insert Ø{INSERT_M3_D:.0f} x {INSERT_M3_L:.1f}\nfrom below, PCD {2*PLATE_SCREW_R:.0f}")
    leader_az(ROCKER_AZ, ROCKER_PIVOT_R, p.ox - 40, p.oy - 88, f"rocker pivot pin Ø2.8 at {ROCKER_AZ:.0f}°, r {ROCKER_PIVOT_R:.2f}", ha="right")
    leader_az(CAMMOTOR_AZ, 36, p.ox + 80, p.oy - 55, f"seat ring cut for the gearmotor and\nring A's toothed tab ({WORM_MESH_AZ - WORM_MESH_ARC/2:.0f}°-{WORM_MESH_AZ + WORM_MESH_ARC/2:.0f}°)")
    section_marks(ax, p.ox, p.oy - 70, p.oy + 70, "A", side=1, horizontal=False) if False else None
    # section line A-A along az 30-210 (through a tower and a boss): draw the cutting line at 30°
    a = math.radians(30)
    ax.plot([p.ox - 70 * math.cos(a), p.ox + 70 * math.cos(a)], [p.oy - 70 * math.sin(a), p.oy + 70 * math.sin(a)], lw=0.8, color=BLACK, ls=(0, (6, 2, 1.5, 2)))
    ax.text(p.ox + 74 * math.cos(a), p.oy + 74 * math.sin(a), "A", fontsize=FS_TITLE, weight="bold", ha="center", va="center")
    ax.text(p.ox - 74 * math.cos(a), p.oy - 74 * math.sin(a), "A", fontsize=FS_TITLE, weight="bold", ha="center", va="center")
    b = math.radians(90)
    ax.plot([p.ox, p.ox], [p.oy - 70, p.oy + 70], lw=0.8, color=BLACK, ls=(0, (6, 2, 1.5, 2)))
    ax.text(p.ox, p.oy + 74, "B", fontsize=FS_TITLE, weight="bold", ha="center", va="center")
    ax.text(p.ox, p.oy - 74, "B", fontsize=FS_TITLE, weight="bold", ha="center", va="center")
    view_title(ax, p.ox, p.oy - 82, "PLAN (from above)")
    # section A-A: rotate the shell by -30 so the cut plane becomes XZ
    s30 = Rot(0, 0, -30) * s
    v = View(sh, 300, 200, 1.05)
    section_view(v, s30, "XZ", 0.0, direction="front")
    centreline_v(ax, v.ox, v.oy - 6, v.oy + 30)
    xl, _ = S(-PLINTH_R_OUT, 0, v); xr, _ = S(PLINTH_R_OUT, 0, v)
    _, y3 = S(0, Z_PLATE_TOP, v); _, y6 = S(0, Z_PLINTH_TOP, v); _, y92 = S(0, HALO_Z1 + 0.2, v)
    _, yledge = S(0, Z_LEDGE_TOP, v); _, yroof = S(0, Z_INNER_ROOF, v); _, ytow = S(0, Z_SLED_TOP + 0.9, v); _, ypost = S(0, Z_DISC_BOT, v)
    dim_h(ax, xl, xr, y3 - 8, y3, f"Ø{2*PLINTH_R_OUT:.1f} plinth", above=False)
    xa, _ = S(-R_LEDGE_OUT, 0, v); xb, _ = S(R_LEDGE_OUT, 0, v)
    dim_h(ax, xa, xb, ypost + 12, ypost, f"Ø{2*R_LEDGE_OUT:.0f} ledge / tower faces (0.4 under the flange bore Ø{2*R_FLANGE_BORE:.1f})")
    dim_v(ax, y3, y6, xr + 6, xr, f"{PLINTH_H:.0f}")
    dim_v(ax, y6, y92, xr + 6, xr, f"{HALO_Z1 + 0.2 - Z_PLINTH_TOP:.1f}")
    dim_v(ax, y3, yledge, xr + 14, xr, f"{Z_LEDGE_TOP - Z_PLATE_TOP:.1f}")
    dim_v(ax, y3, yroof, xr + 22, xr, f"{Z_INNER_ROOF - Z_PLATE_TOP:.1f}")
    dim_v(ax, y3, ypost, xr + 30, xr, f"{Z_DISC_BOT - Z_PLATE_TOP:.1f}")
    dim_leader(ax, *S(-LED_WALL_R_OUT + 0.5, HALO_Z0 + 1.5, v), xl - 6, y6 - 14, f"LED wall r {LED_WALL_R_IN:.1f}-{LED_WALL_R_OUT:.1f}; LED board outside it", ha="right")
    dim_leader(ax, *S(RING_R_OUT + 0.5, (Z_PLATE_TOP + RING_SEAT_Z) / 2, v), xr + 6, y3 - 14, f"seat ring r {RISER_R_IN - 1:.1f}-{RING_R_OUT + 1:.1f}, top z {RING_SEAT_Z:.1f}")
    view_title(ax, v.ox, ypost + 22, "A-A (30°-210°)")
    return sh.save(os.path.join(DWG, "02-base_shell.png"))

def sheet_shell2():
    s = base_shell()
    sh = Sheet("BASE SHELL", "60-07-02", "PETG black (proto) / PA12 MJF (prod)", "as printed", "1.6:1 / 4:1", g(s), sheet=2, of=2,
               notes="Section B-B through the tunnel (90°-270°)\nand a plan detail of one tower pocket.")
    ax = sh.ax
    # ---- B-B (rotate so the 90-270 plane becomes XZ; 90° on the right)
    s90 = Rot(0, 0, -90) * s
    v = View(sh, 135, 200, 1.6)
    section_view(v, s90, "XZ", 0.0, direction="front")
    centreline_v(ax, v.ox, v.oy - 8, v.oy + 45)
    _, y3 = S(0, Z_PLATE_TOP, v); _, y6 = S(0, Z_PLINTH_TOP, v); _, yl = S(0, Z_LEDGE_TOP, v); _, yr = S(0, Z_INNER_ROOF, v)
    xt, _ = S(TUNNEL_R_BACK, 0, v); xe, _ = S(PLINTH_R_OUT, 0, v); xw, _ = S(-PLINTH_R_OUT, 0, v)
    dim_h(ax, xt, xe, y3 - 8, y3, f"{PLINTH_R_OUT - TUNNEL_R_BACK:.1f} tunnel", above=False)
    dim_h(ax, xw, xe, y3 - 16, y3, f"Ø{2*PLINTH_R_OUT:.1f}", above=False)
    dim_v(ax, y3, y6, xe + 6, xe, f"{Z_PLINTH_TOP - Z_PLATE_TOP:.0f}")
    dim_v(ax, y3, yl, xe + 14, xe, f"{Z_LEDGE_TOP - Z_PLATE_TOP:.1f}")
    dim_v(ax, y3, yr, xe + 22, xe, f"{Z_INNER_ROOF - Z_PLATE_TOP:.1f}")
    dim_leader(ax, *S(TUNNEL_R_BACK + 0.3, JACK_AXIS_Z + 1, v), xe + 12, y6 + 22, f"jack hole Ø{PLUG_JACK_D + 0.6:.1f} at z {JACK_AXIS_Z:.1f}, {JACK_T_OFF:+.0f} tangential")
    dim_leader(ax, *S(-(R_LEDGE_IN + 2), Z_LEDGE_TOP - 0.3, v), xw + 4, y3 - 28, f"ledge r {R_LEDGE_IN:.0f}-{R_LEDGE_OUT:.1f}, z {M.Z_LEDGE_BOT:.1f}-{Z_LEDGE_TOP:.1f}")
    dim_leader(ax, *S(-30, Z_INNER_ROOF - 0.3, v), xw + 70, y3 - 28, f"inner roof z {Z_INNER_ROOF_BOT:.1f}-{Z_INNER_ROOF:.1f}, r ≤ {R_LEDGE_IN + 0.5:.1f}\n(0.6 under the main board's components)")
    dim_leader(ax, *S(TUNNEL_R_BACK + 2, Z_PLINTH_TOP - 1.5, v), xe + 12, y3 - 20, f"tunnel {TUNNEL_W:.0f} wide, roof z {Z_PLINTH_TOP:.0f}")
    view_title(ax, v.ox, yl + 52, "B-B (90° right, 270° left)")
    # ---- DETAIL C: plan of one tower pocket at 30°, drawn from the parameters (4:1).
    # local axes: u = radial (outward to the right), t = tangential (+ up); arcs drawn straight (< 0.05 mm sagitta)
    k = 4.0; ox, oy = 318, 175; rc = (SLED_R_IN + SLED_R_OUT) / 2
    def P(r, t): return ox + k * (r - rc), oy + k * t
    def rect(r0, r1, t0, t1, **kw):
        ax.add_patch(MplPolygon([P(r0, t0), P(r1, t0), P(r1, t1), P(r0, t1)], closed=True, **kw))
    w_in = SLED_R_IN - 1.0
    # ledge strip (r 49-55.5) shown 14 mm either side of the pocket
    T = 12.0
    rect(R_LEDGE_IN, R_LEDGE_OUT, -T, T, facecolor="none", edgecolor=BLACK, lw=LW_THIN)
    # slot through the ledge
    rect(SLED_R_IN - 0.3, SLED_R_OUT + 0.3, -POCKET_W / 2, POCKET_W / 2, facecolor="white", edgecolor=BLACK, lw=LW_THICK)
    # guide walls (hatched: material above the ledge)
    for sgn in (+1, -1):
        rect(w_in, SLED_R_OUT, sgn * POCKET_W / 2, sgn * (POCKET_W / 2 + 1.2), facecolor="none", edgecolor=BLACK, lw=LW_THICK, hatch="////")
    # cap (hidden, above)
    rect(w_in, SLED_R_OUT - 1.2, -(POCKET_W / 2 + 1.2), POCKET_W / 2 + 1.2, facecolor="none", edgecolor=BLACK, lw=LW_THIN, ls=(0, (4, 2)))
    # tower at rest and at +travel (ring A rotated +1.5°)
    rect(SLED_R_IN, SLED_R_OUT, -SLED_W / 2, SLED_W / 2, facecolor="none", edgecolor=BLUE, lw=0.7)
    rect(MAG_FACE_R - MAG_R, MAG_FACE_R, -MAG_T / 2, MAG_T / 2, facecolor="none", edgecolor=BLUE, lw=0.5, ls=(0, (2, 1.5)))
    rect(SLED_R_IN, SLED_R_OUT, SLED_TRAVEL - SLED_W / 2, SLED_TRAVEL + SLED_W / 2, facecolor="none", edgecolor=BLUE, lw=0.5, ls=(0, (4, 2)))
    ax.plot([P(R_LEDGE_IN - 1, 0)[0], P(R_LEDGE_OUT + 3, 0)[0]], [oy, oy], lw=LW_THIN, color=BLACK, ls=(0, (8, 2, 1.5, 2)))
    ax.text(P(R_LEDGE_OUT + 3.5, 0)[0], oy, "30°", fontsize=FS_DIM, va="center")
    # dimensions
    x_in, _ = P(SLED_R_IN - 0.3, 0); x_out, _ = P(SLED_R_OUT + 0.3, 0); x_li, _ = P(R_LEDGE_IN, 0); x_lo, _ = P(R_LEDGE_OUT, 0)
    _, y_p0 = P(0, -POCKET_W / 2); _, y_p1 = P(0, POCKET_W / 2); _, y_w1 = P(0, POCKET_W / 2 + 1.2); _, y_tw = P(0, SLED_W / 2)
    _, y_T = P(0, T); _, y_mT = P(0, -T)
    dim_h(ax, x_in, x_out, y_T + 8, y_T, f"{SLED_R_OUT - SLED_R_IN + 0.6:.1f} slot")
    dim_h(ax, x_li, x_lo, y_T + 16, y_T, f"{R_LEDGE_OUT - R_LEDGE_IN:.1f} ledge")
    dim_v(ax, y_p0, y_p1, x_lo + 8, x_lo, f"{POCKET_W:.2f} pocket")
    dim_v(ax, y_p1, y_w1, x_lo + 8, x_lo, "1.2")
    dim_v(ax, P(0, -SLED_W / 2)[1], y_tw, x_li - 8, x_li, f"{SLED_W:.1f} tower", left=True)
    dim_v(ax, oy, P(0, SLED_TRAVEL)[1], x_li - 16, x_li, f"{SLED_TRAVEL:.2f} travel", left=True)
    dim_leader(ax, *P(MAG_FACE_R - 0.2, MAG_T / 2 - 0.3), x_lo + 22, y_T - 2, f"magnet {MAG_R:.0f} x {MAG_T:.0f} x {MAG_H:.0f}, face r {MAG_FACE_R:.1f}\n({MAG_FACE_GAP:.1f} to the peg tips)")
    dim_leader(ax, *P(SLED_R_OUT - 0.6, POCKET_W / 2 + 1.0), x_lo + 22, y_T - 14, "guide walls z 10.4-18.6")
    dim_leader(ax, *P(w_in + 0.5, -(POCKET_W / 2 + 0.6)), x_lo + 22, y_mT + 4, "cap 0.6 thick over the tower\n(z 18.3-18.9, hidden)")
    dim_leader(ax, *P(SLED_R_IN + 0.5, SLED_TRAVEL + SLED_W / 2 - 0.3), x_li - 4, y_T + 10, "tower shifted by ring A (+1.5°)", ha="right")
    view_title(ax, ox, y_T + 26, "DETAIL C (4:1) — tower pocket at 30°, plan")
    note_block(ax, 20, 100, [f"1. Six tower pockets at 30° + n·60°: slot {SLED_R_OUT - SLED_R_IN + 0.6:.1f} radial x {POCKET_W:.2f} tangential through the ledge, guide walls 1.2 thick; towers travel ±{SLED_TRAVEL:.2f}.",
                            f"2. Ledge z {M.Z_LEDGE_BOT:.1f}-{Z_LEDGE_TOP:.1f}; inner roof z {Z_INNER_ROOF_BOT:.1f}-{Z_INNER_ROOF:.1f}; the roof clears the main board's components by 0.6.",
                            "3. The drive well and the tyre sweep leave the ledge open between 145° and 215°.",
                            "4. Pins pressed after printing: rocker pivot Ø2.8 (printed), drive-arm pivot Ø2.8 (printed) — replace with steel dowels if they shear.",
                            "5. Blue in DETAIL C is ring A's tower (drawing 60-07-06), shown for fit only."])
    return sh.save(os.path.join(DWG, "02b-base_shell.png"))

# =====================================================================================
def sheet_body():
    b = knob_body_smooth() - peg_holes()
    sh = Sheet("KNOB BODY", "60-07-04", "PETG black (proto) / 6082 Al CNC (prod)", "Type III hardcoat, matt black; knurl per note", "1:1 / 3:1", g(b),
               notes="Prototype prints flange DOWN, no supports.\n60 x Ø3 steel balls pressed into the peg holes.\nDiamond knurl on the side (not drawn): see note 3.", stock="Ø125 x 25 Al", sheet=1, of=1)
    ax = sh.ax
    v = View(sh, 120, 190, 1.0)
    section_view(v, b, "XZ", 0.0, direction="front")
    centreline_v(ax, v.ox, v.oy - 6, v.oy + 36)
    xl, _ = S(-R_KNOB, 0, v); xr, _ = S(R_KNOB, 0, v)
    _, yb = S(0, Z_SKIRT_BOT, v); _, ytop = S(0, Z_CROWN_BOT - CROWN_SEAT_T, v); _, yft = S(0, Z_FLANGE_TOP, v)
    dim_h(ax, xl, xr, ytop + 14, ytop, f"Ø{2*R_KNOB:.0f}")
    xi, _ = S(-R_SKIRT_BORE, 0, v); xj, _ = S(R_SKIRT_BORE, 0, v)
    dim_h(ax, xi, xj, ytop + 8, ytop, f"Ø{2*R_SKIRT_BORE:.1f} H8 (disc Ø{DISC_OD:.0f} + 0.8)")
    xf, _ = S(-R_FLANGE_BORE, 0, v); xg, _ = S(R_FLANGE_BORE, 0, v)
    dim_h(ax, xf, xg, yb - 8, yb, f"Ø{2*R_FLANGE_BORE:.1f} flange bore", above=False)
    xa, _ = S(-R_RIDGE_APEX, 0, v); xb2, _ = S(R_RIDGE_APEX, 0, v)
    dim_h(ax, xa, xb2, yb - 15, yb, f"Ø{2*R_RIDGE_APEX:.1f} ridge apex", above=False)
    dim_v(ax, yb, ytop, xr + 44, xr, f"{Z_CROWN_BOT - CROWN_SEAT_T - Z_SKIRT_BOT:.1f}")
    dim_v(ax, yb, yft, xr + 12, xr, f"{Z_FLANGE_TOP - Z_SKIRT_BOT:.1f}")
    dim_v(ax, yb, S(0, PEG_Z, v)[1], xr + 22, xr, f"{PEG_Z - Z_SKIRT_BOT:.1f} pegs")
    dim_v(ax, yb, S(0, Z_RIDGE_MID, v)[1], xr + 33, xr, f"{Z_RIDGE_MID - Z_SKIRT_BOT:.1f} ridge")
    dim_leader(ax, *S(R_KNOB - CH_BOT / 2, Z_SKIRT_BOT + CH_BOT / 2, v), xr + 6, yb - 6, f"{CH_BOT:.1f} x 45°")
    dim_leader(ax, *S(CROWN_REBATE_R + 0.2, Z_CROWN_BOT - 0.3, v), xr + 6, ytop + 4, f"crown rebate Ø{2*CROWN_REBATE_R:.1f} x {CROWN_SEAT_T:.1f} deep")
    datum(ax, S(R_SKIRT_BORE, Z_CROWN_BOT - 3, v)[0], S(0, Z_CROWN_BOT - 3, v)[1], "A", dx=12, dy=-8)
    tol_frame(ax, xl - 40, yb + 40, "◎", "Ø0.05", "A")
    ax.text(xl - 40, yb + 46, "flange bore, ridge and pegs concentric to A:", fontsize=5.5)
    surface_mark(ax, S(-R_SKIRT_BORE, Z_CROWN_BOT - 6, v)[0] - 2, S(0, Z_CROWN_BOT - 6, v)[1], "1.6")
    view_title(ax, v.ox, ytop + 22, "A-A")
    # detail B: ridge and flange step (3:1), right half only
    clip = Pos(58, 0, 16) * Box(10, 30, 16)
    part = b & clip
    d = View(sh, 300 - 3.0 * 58, 200 - 3.0 * 16, 3.0)
    section_view(d, part, "XZ", 0.0, direction="front")
    xq, _ = S(R_SKIRT_BORE, 0, d); xp, _ = S(R_RIDGE_APEX, 0, d); xk, _ = S(R_KNOB, 0, d)
    _, y0 = S(0, Z_RIDGE0, d); _, y1 = S(0, Z_RIDGE1, d); _, ym = S(0, Z_RIDGE_MID, d); _, yf = S(0, Z_FLANGE_TOP, d); _, yc = S(0, Z_CODE0, d)
    dim_v(ax, y0, y1, xk + 8, xk, f"{Z_RIDGE1 - Z_RIDGE0:.1f}")
    dim_h(ax, xp, xq, y1 + 10, y1, f"{RIDGE_H:.1f}")
    dim_ang(ax, xp, ym, 8, -45, 45, "90°")
    dim_leader(ax, *S(R_FLANGE_BORE + 1, Z_FLANGE_TOP + 0.15, d), xk + 6, yf - 12, f"step {R_SKIRT_BORE - R_FLANGE_BORE:.1f} radial over 0.3 (2 mm bridge when printed)")
    dim_leader(ax, *S(R_FLANGE_BORE, (Z_CODE0 + Z_CODE1) / 2, d), xk + 6, yf - 22, f"code band z {Z_CODE0:.1f}-{Z_CODE1:.1f}: bonded reflective strip + index")
    dim_leader(ax, *S(R_FLANGE_BORE, (Z_TYRE0 + Z_TYRE1) / 2, d), xk + 6, yf - 32, f"tyre band z {Z_TYRE0:.1f}-{Z_TYRE1:.1f}: smooth, Ra 0.8")
    view_title(ax, 300, y1 + 22, "DETAIL B (3:1) — ridge, flange step, bore bands")
    # view from below: peg holes
    p = View(sh, 110, 90, 0.7)
    p.project(b, "bottom", hidden=False)
    _plan_common(ax, p, 48)
    dim_leader(ax, *S(R_FLANGE_BORE + 1, 0, p), p.ox + 52, p.oy + 30, f"{PEG_N}x Ø{PEG_D - 0.1:.1f} x {PEG_D:.1f} deep, radial from the bore\nat z {PEG_Z - Z_SKIRT_BOT:.1f} (Ø3 chrome-steel balls pressed flush);\npitch 6°, first at 0°")
    dim_leader(ax, *S(-CROWN_SCREW_R * math.cos(math.radians(183)), CROWN_SCREW_R * math.sin(math.radians(183)), p), p.ox + 52, p.oy + 8, f"6x Ø{CROWN_SCREW_D:.1f} through the skirt wall,\ncsb Ø{CROWN_SCREW_HEAD_D + 0.3:.1f} x {CROWN_SCREW_HEAD_H + 0.2:.1f} from below; PCD {2*CROWN_SCREW_R:.1f},\nat 3° + n·60° (M2 x 22 into the crown)")
    view_title(ax, p.ox, p.oy - 54, "VIEW FROM BELOW")
    note_block(ax, 232, 110, [f"1. Knurl (prototype): {KNURL_N} diamond, {KNURL_DEPTH:.1f} deep, 30° helix, from z {KNURL_Z0 - Z_SKIRT_BOT:.1f} to {KNURL_Z1 - Z_SKIRT_BOT:.1f} above the skirt bottom,",
                            "   0.8 plain bands at each end. Production (CNC): RGE diamond 1.0 pitch, 0.3 deep, cut before anodising (ID research).",
                            "2. Peg material matters: chrome-steel balls or EN1A mild-steel studs; never hardened grub screws, never stainless.",
                            "3. Concentricity of the flange bore, ridge and peg circle to the skirt bore: 0.05 total (±0.1 runout = ±15-20 % click ripple).",
                            "4. Assembly: knob over the base (wheels engage the ridge) -> display drops in from the top -> crown screwed on from below."])
    return sh.save(os.path.join(DWG, "04-knob_body.png"))

# =====================================================================================
def _ring_sheet(which):
    r = ring_a() if which == "A" else ring_b()
    z0, z1 = (RING_A_Z0, RING_A_Z1) if which == "A" else (RING_B_Z0, RING_B_Z1)
    az_t = 30 if which == "A" else 90
    name = f"MAGNET RING {which}"
    sh = Sheet(name, "60-07-06" if which == "A" else "60-07-07", "PETG (proto) / PA12 MJF or brass (prod)", "as printed", "1:1 / 3:1", g(r),
               notes=("Lower ring: turns +1.5° (worm on its hanging tab).\nTowers at 30°/150°/270°." if which == "A" else
                      "Upper ring: turns -1.5° (rocker). Towers at 90°/210°/330°.\nFeet at 60°/120°/240° stand on the seat ring."), stock="—")
    ax = sh.ax
    p = View(sh, 120, 165, 1.05)
    p.project(r, "top", hidden=True)
    _plan_common(ax, p, 60)
    x1, _ = S(-RING_R_OUT, 0, p); x2, _ = S(RING_R_OUT, 0, p); _, yt = S(0, RING_R_OUT, p)
    dim_h(ax, x1, x2, yt + 14, yt, f"Ø{2*RING_R_OUT:.0f}")
    xi1, _ = S(-RING_R_IN, 0, p); xi2, _ = S(RING_R_IN, 0, p)
    dim_h(ax, xi1, xi2, yt + 8, yt, f"Ø{2*RING_R_IN:.0f}")
    def leader_az(az, rr, tx, ty, text, ha="left"):
        cx, cy = S(rr * math.cos(math.radians(az)), rr * math.sin(math.radians(az)), p)
        dim_leader(ax, cx, cy, tx, ty, text, ha=ha)
    leader_az(az_t, SLED_R_OUT, p.ox + 70, p.oy + 60, f"3x towers {SLED_W:.1f} wide, r {SLED_R_IN:.1f}-{SLED_R_OUT:.1f},\nmagnet pocket {MAG_R:.0f} x {MAG_T:.0f} x {MAG_H:.0f}, face at r {MAG_FACE_R:.1f}, lips {MAG_LIP_W:.1f}")
    leader_az(az_t + 120, RISER_R_IN, p.ox + 70, p.oy + 40, f"risers r {RISER_R_IN:.1f}-{RISER_R_OUT:.1f} hang inside the ring;\nlegs z {LEG_Z0:.1f}-{LEG_Z1:.1f} out to the towers")
    if which == "A":
        leader_az(WORM_MESH_AZ, RING_A_TAB_R_IN, p.ox + 70, p.oy - 62, f"hanging tab r {RING_A_TAB_R_IN:.1f}-{RING_R_IN + 0.6:.1f}, z {RING_A_TAB_Z0:.1f}-{z1:.1f},\n{WORM_MESH_AZ - WORM_MESH_ARC/2:.0f}°-{WORM_MESH_AZ + WORM_MESH_ARC/2:.0f}°: module 0.4 teeth on its inner face (drawn smooth)")
        leader_az(ROCKER_AZ, ROCKER_PIN_R_A, p.ox + 70, p.oy - 44, f"radial slot {ROCKER_PIN_D + 0.3:.1f} wide x 3.6 at {ROCKER_AZ:.0f}°, r {ROCKER_PIN_R_A:.1f} (rocker pin)")
    else:
        leader_az(ROCKER_AZ, RING_B_TAB_R_IN, p.ox + 70, p.oy - 62, f"inward tab r {RING_B_TAB_R_IN:.1f}-{RING_R_IN + 0.5:.1f}, {RING_B_TAB_ARC:.0f}° wide at {ROCKER_AZ:.0f}°,\nradial slot {ROCKER_PIN_D + 0.3:.1f} wide at r {ROCKER_PIN_R_B:.1f}")
        leader_az(60, RING_R_IN - 1.7, p.ox + 70, p.oy - 44, f"3x feet 1.2 x 4.0 down to z {RING_SEAT_Z:.1f}, at 60°/120°/240°")
    view_title(ax, p.ox, p.oy - 68, "PLAN (from above)")
    a = math.radians(az_t)
    ax.plot([p.ox - 66 * math.cos(a), p.ox + 66 * math.cos(a)], [p.oy - 66 * math.sin(a), p.oy + 66 * math.sin(a)], lw=0.8, color=BLACK, ls=(0, (6, 2, 1.5, 2)))
    ax.text(p.ox + 70 * math.cos(a), p.oy + 70 * math.sin(a), "A", fontsize=FS_TITLE, weight="bold", ha="center", va="center")
    ax.text(p.ox - 70 * math.cos(a), p.oy - 70 * math.sin(a), "A", fontsize=FS_TITLE, weight="bold", ha="center", va="center")
    # section through a tower (3:1), right half
    rr = Rot(0, 0, -az_t) * r
    clip = Pos(48, 0, 11) * Box(20, 30, 16)
    part = rr & clip
    d = View(sh, 300 - 3.0 * 48, 200 - 3.0 * 11, 3.0)
    section_view(d, part, "XZ", 0.0, direction="front")
    xa, _ = S(RISER_R_IN, 0, d); xb, _ = S(SLED_R_OUT, 0, d); xc, _ = S(RING_R_IN, 0, d); xd, _ = S(RING_R_OUT, 0, d)
    _, yr0 = S(0, z0, d); _, yr1 = S(0, z1, d); _, ytop = S(0, Z_SLED_TOP, d); _, ymb = S(0, Z_MAG_BOT, d); _, ymt = S(0, Z_MAG_TOP, d)
    dim_h(ax, xa, xb, ytop + 10, ytop, f"{SLED_R_OUT - RISER_R_IN:.1f}")
    dim_h(ax, xc, xd, yr0 - 8, yr0, f"{RING_R_OUT - RING_R_IN:.1f} ring", above=False)
    dim_v(ax, yr0, yr1, xd + 40, xd, f"{z1 - z0:.1f}")
    dim_v(ax, yr0, ytop, xd + 48, xd, f"{Z_SLED_TOP - z0:.1f}")
    dim_v(ax, ymb, ymt, xd + 56, xd, f"{MAG_H:.0f} magnet")
    dim_leader(ax, *S(MAG_FACE_R + 0.2, (Z_MAG_BOT + Z_MAG_TOP) / 2, d), xd + 60, ytop + 6, f"magnet face r {MAG_FACE_R:.1f}; lip {MAG_LIP_T:.1f} thick;\n0.8 to the peg tips (r {R_FLANGE_BORE:.1f})")
    view_title(ax, 300, ytop + 24, f"A-A (3:1) — through the tower at {az_t}°")
    note_block(ax, 20, 80, ["1. Magnet: 3 x 3 x 6 mm N42 (N52 option), 6 mm axis VERTICAL, magnetised radially outward, all six the same",
                            "   polarity. Loaded into the tower from the top before the ring goes in from below; the shell's cap retains it.",
                            "2. Two groups of three: ring A (30°/150°/270°) and ring B (90°/210°/330°). 'Clicks on' = both at 0°;",
                            "   'clicks off' = A at +1.5°, B at -1.5° (groups half a peg pitch apart: the pulls cancel).",
                            "3. Assembly from below: ring B first (upper), then ring A; the towers pass up through the ledge slots.",
                            "4. Concentricity to the base's ledge bore: 0.05 total. Tower outer faces are cylindrical (r 55.5)."])
    return sh.save(os.path.join(DWG, f"0{6 if which == 'A' else 7}-ring_{which.lower()}.png"))

def sheet_ring_a(): return _ring_sheet("A")
def sheet_ring_b(): return _ring_sheet("B")

# =====================================================================================
def sheet_rocker():
    r = rocker()
    r0 = Rot(0, 0, -ROCKER_AZ) * r      # bar along +X, pivot at x = ROCKER_PIVOT_R
    sh = Sheet("ROCKER", "60-07-08", "PETG (proto) / brass (prod)", "as printed", "4:1", g(r),
               notes="Links ring A (+1.5°) to ring B (-1.5°).\nPivots on the shell's Ø2.8 pin; pins up into the rings' slots.", stock="—")
    ax = sh.ax
    k = 4.0
    p = View(sh, 130 - k * ROCKER_PIVOT_R, 200, k)      # pivot lands at sheet x 130
    p.project(r0, "top", hidden=True)
    xc = S(ROCKER_PIVOT_R, 0, p)[0]
    L = ROCKER_PIN_R_A - ROCKER_PIN_R_B
    x1, _ = S(ROCKER_PIN_R_B - 2.5, 0, p); x2, _ = S(ROCKER_PIN_R_A + 2.5, 0, p); _, yt = S(0, 2.5, p); _, yb = S(0, -2.5, p)
    dim_h(ax, x1, x2, yt + 12, yt, f"{L + 5:.1f}")
    dim_h(ax, S(ROCKER_PIN_R_B, 0, p)[0], xc, yb - 8, yb, f"{ROCKER_PIVOT_R - ROCKER_PIN_R_B:.2f}", above=False)
    dim_h(ax, xc, S(ROCKER_PIN_R_A, 0, p)[0], yb - 8, yb, f"{ROCKER_PIN_R_A - ROCKER_PIVOT_R:.2f}", above=False)
    dim_v(ax, yb, yt, x2 + 8, x2, "5.0")
    dim_leader(ax, *S(ROCKER_PIVOT_R, 1.6, p), xc + 6, yt + 22, "Ø3.2 pivot hole")
    dim_leader(ax, *S(ROCKER_PIN_R_A, 1.0, p), xc + 40, yt + 30, f"pin Ø{ROCKER_PIN_D:.0f}, up to z {RING_A_Z1 - 0.2:.1f} (ring A slot)")
    dim_leader(ax, *S(ROCKER_PIN_R_B, 1.0, p), xc - 40, yt + 30, f"pin Ø{ROCKER_PIN_D:.0f}, up to z {RING_B_Z1 - 0.2:.1f} (ring B tab)", ha="right")
    centreline_h(ax, x1 - 6, x2 + 6, p.oy)
    view_title(ax, xc, yt + 42, "PLAN (inner end left, r increases to the right)")
    v = View(sh, 130 - k * ROCKER_PIVOT_R, 130, k)
    section_view(v, r0, "XZ", 0.0, direction="front")
    _, y0 = S(0, ROCKER_Z0, v); _, y1 = S(0, ROCKER_Z1, v); _, ya = S(0, RING_A_Z1 - 0.2, v); _, yb2 = S(0, RING_B_Z1 - 0.2, v)
    xr, _ = S(ROCKER_PIN_R_A + 2.5, 0, v)
    dim_v(ax, y0, y1, xr + 8, xr, f"{ROCKER_Z1 - ROCKER_Z0:.1f}")
    dim_v(ax, y1, ya, xr + 16, xr, f"{RING_A_Z1 - 0.2 - ROCKER_Z1:.1f}")
    dim_v(ax, y1, yb2, xr + 24, xr, f"{RING_B_Z1 - 0.2 - ROCKER_Z1:.1f}")
    view_title(ax, xc, y0 - 12, "A-A")
    note_block(ax, 250, 200, [f"1. Sits at z {ROCKER_Z0}-{ROCKER_Z1} in a clearance pocket of the seat ring at {ROCKER_AZ:.0f}°.",
                              f"2. Swings {rocker_swing('off'):.1f}° between the two states; the slots in the rings take the arc.",
                              "3. Prototype: PETG, printed flat. Production: brass, pins pressed."], title="NOTES")
    return sh.save(os.path.join(DWG, "08-rocker.png"))

# =====================================================================================
def sheet_arm():
    a, (mx, my) = drive_plate(True)
    (mx, my), (px, py) = drive_geometry(True)
    ang = math.degrees(math.atan2(my - py, mx - px))
    a0 = Pos(-px, -py, 0) * a
    a0 = Rot(0, 0, -ang) * a0            # pivot at the origin, motor along +X
    sh = Sheet("DRIVE ARM", "60-07-09", "PETG (proto) / 6082 Al (prod)", "as printed", "2:1", g(a),
               notes="Pivots on the shell's Ø2.8 pin; the flat drive motor hangs\nfrom it on 3x M2; the tyre hub sits on the shaft above.\nSolenoid pushes the hanging lug outward = engaged.", stock="—")
    ax = sh.ax
    p = View(sh, 150, 190, 2.0)
    p.project(a0, "top", hidden=True)
    L = DRIVE_ARM_L
    x1, _ = S(-4, 0, p); x2, _ = S(L + DRIVE_MOTOR_D / 2 + 0.7, 0, p); _, yt = S(0, 5, p)
    dim_h(ax, S(0, 0, p)[0], S(L, 0, p)[0], yt + 22, yt, f"{L:.1f}")
    dim_h(ax, x1, x2, yt + 30, yt, f"{L + DRIVE_MOTOR_D / 2 + 0.7 + 4:.1f}")
    dim_leader(ax, *S(0, 1.6, p), p.ox - 30, yt + 12, "Ø3.2 pivot hole", ha="right")
    dim_leader(ax, *S(L, 3.5, p), p.ox + 60, yt + 12, f"Ø7 shaft clearance; 3x Ø2.2 on PCD 12 for the motor")
    dim_leader(ax, *S(L + DRIVE_MOTOR_D / 2 + 0.7, 0, p), p.ox + 60, yt + 4, f"boss Ø{DRIVE_MOTOR_D + 1.4:.1f}")
    view_title(ax, p.ox, yt + 40, "PLAN")
    v = View(sh, 150, 120, 2.0)
    section_view(v, a0, "XZ", 0.0, direction="front")
    _, y0 = S(0, Z_DRIVE_ARM0, v); _, y1 = S(0, Z_DRIVE_ARM1, v); _, yl = S(0, Z_PLATE_TOP + 0.6, v)
    xr, _ = S(L + DRIVE_MOTOR_D / 2 + 1, 0, v)
    dim_v(ax, y0, y1, xr + 8, xr, f"{Z_DRIVE_ARM1 - Z_DRIVE_ARM0:.1f}")
    dim_v(ax, yl, y0, xr + 16, xr, f"{Z_DRIVE_ARM0 - Z_PLATE_TOP - 0.6:.1f} lug")
    view_title(ax, v.ox, y0 - 12, "A-A")
    note_block(ax, 250, 200, [f"1. Arm at z {Z_DRIVE_ARM0}-{Z_DRIVE_ARM1}, between ring B and the rings' legs (azimuths differ).",
                              f"2. Engaged: tyre pressed {DRIVE_R + TYRE_D / 2 - R_FLANGE_BORE:.2f} into the bore. Idle: swung back {DRIVE_LIFT:.1f}; return spring (not drawn).",
                              f"3. Solenoid Ø{SOLENOID_D:.0f} x {SOLENOID_L:.0f} lies radially at {SOLENOID_AZ:.0f}° on the plate and pushes the lug's inner face.",
                              "4. Prototype: PETG printed flat. Production: aluminium, brass pivot bush."])
    return sh.save(os.path.join(DWG, "09-drive_arm.png"))

# =====================================================================================
def sheet_hub():
    h = tyre_hub()
    sh = Sheet("TYRE HUB", "60-07-11", "PETG (proto) / POM (prod)", "as printed", "2:1", g(h),
               notes=f"Carries a 2 mm-section nitrile O-ring, ID {TYRE_D - 4 - 0.6:.0f} (the tyre).\nÐ5 bore on the motor shaft, M2 grub.", stock="—")
    ax = sh.ax
    v = View(sh, 130, 190, 2.0)
    section_view(v, h, "XZ", 0.0, direction="front")
    centreline_v(ax, v.ox, v.oy - 6, v.oy + 12)
    ro = TYRE_D / 2 - 1.8
    x1, _ = S(-ro, 0, v); x2, _ = S(ro, 0, v); _, yb = S(0, 0, v); _, yt = S(0, TYRE_T, v)
    dim_h(ax, x1, x2, yt + 12, yt, f"Ø{2*ro:.1f}")
    dim_h(ax, S(-(ro - 1.2), 0, v)[0], S(ro - 1.2, 0, v)[0], yt + 6, yt, f"Ø{2*(ro-1.2):.1f} groove root")
    dim_h(ax, S(-2.55, 0, v)[0], S(2.55, 0, v)[0], yb - 8, yb, "Ø5.1", above=False)
    dim_v(ax, yb, yt, x2 + 8, x2, f"{TYRE_T:.1f}")
    dim_leader(ax, *S(ro - 0.6, 1.0, v), x2 + 12, yt + 8, "O-ring groove 1.2 deep, V profile; O-ring stands 1.8 proud")
    view_title(ax, v.ox, yt + 20, "A-A")
    p = View(sh, 300, 170, 1.5)
    p.project(h, "top", hidden=True)
    _plan_common(ax, p, 40)
    section_marks(ax, p.ox - 40, p.oy - 42, p.oy + 42, "A", side=-1)
    note_block(ax, 20, 100, [f"1. With the O-ring fitted the tyre is Ø{TYRE_D:.0f}; it contacts the knob's flange bore (Ø{2*R_FLANGE_BORE:.1f}) at ratio {(2*R_FLANGE_BORE)/TYRE_D:.2f}:1.",
                             "2. Grub screw M2 on a flat of the motor shaft.",
                             "3. Prototype: PETG, printed flat, 0.12 layers."])
    return sh.save(os.path.join(DWG, "11-tyre_hub.png"))

# =====================================================================================
def sheet_assembly():
    made = made_parts("on", knurl=False); refs = ref_parts("on")
    allp = {**made, **refs}
    sh = Sheet("THE 60 — ASSEMBLY", "60-07-00", "—", "—", "1:1", 0, sheet=1, of=1,
               notes="Sections through the assembly, clicks ON, drive idle.\nBought parts shown as envelopes.")
    ax = sh.ax
    # section A-A: YZ plane (90° right = tunnel side, 270° left)
    v = View(sh, 152, 195, 1.4)
    order_made = ["base_plate", "base_shell", "halo_diffuser", "knob_body", "knob_crown", "ring_a", "ring_b", "rocker", "drive_plate", "tyre_hub"] + [k for k in made if k.startswith("collar")]
    hatches = {"base_plate": "xxx", "base_shell": "///", "halo_diffuser": "...", "knob_body": "\\\\\\", "knob_crown": "\\\\\\", "ring_a": "///", "ring_b": "\\\\\\", "rocker": "xx", "drive_plate": "//", "tyre_hub": "//"}
    for n in order_made:
        try:
            section_view(v, made[n], "YZ", 0.0, hatch=hatches.get(n, "//"), direction="right")
        except Exception as e:
            print("section fail", n, e)
    for n in ("disc", "pcb", "components", "port_board", "usbc", "jack", "usbc_plug", "jack_plug", "pad", "led_board", "magnets", "speaker", "tyre", "drive_motor", "supercaps"):
        try:
            section_view(v, refs[n], "YZ", 0.0, hatch="", colour="0.45", direction="right")
        except Exception as e:
            print("ref section fail", n, e)
    centreline_v(ax, v.ox, v.oy - 6, v.oy + 40)
    _, yb = S(0, -PAD_T, v); _, yt = S(0, Z_KNOB_TOP, v); xr, _ = S(R_KNOB, 0, v); xl, _ = S(-R_KNOB, 0, v)
    dim_v(ax, yb, yt, xr + 10, xr, f"{Z_KNOB_TOP + PAD_T:.1f} overall")
    dim_v(ax, S(0, Z_SKIRT_BOT, v)[1], yt, xr + 18, xr, f"{Z_KNOB_TOP - Z_SKIRT_BOT:.1f} knob ({KNOB_FRACTION*100:.0f} %)")
    dim_h(ax, xl, xr, yt + 12, yt, f"Ø{2*R_KNOB:.0f}")
    dim_h(ax, S(-R_CROWN_IN, 0, v)[0], S(R_CROWN_IN, 0, v)[0], yt + 6, yt, f"Ø{2*R_CROWN_IN:.1f} (picture Ø{ACTIVE_OD})")
    dim_leader(ax, *S(TUNNEL_R_BACK + 8, 2, v), xr - 24, yb - 16, "cable tunnel, USB-C and 3.5 mm plugs")
    dim_leader(ax, *S(-53.5, PEG_Z, v), xl - 6, yb - 8, "magnet tower (ring A)\nand the Ø3 pegs", ha="right")
    dim_leader(ax, *S(20, Z_DISC_TOP, v), xr + 4, yt + 16, "display disc Ø115 x 6 on four posts")
    dim_leader(ax, *S(-(DIFF_R_OUT_TOP - 0.3), HALO_Z0 + 1.5, v), xl - 6, yb + 26, "halo: LEDs on the base wall,\nopal ring, 360°", ha="right")
    view_title(ax, v.ox, yt + 22, "A-A  (plane 90°-270°)")
    # section B-B: XZ plane (0° right = wheel, 180° left = drive)
    w = View(sh, 152, 85, 1.4)
    for n in order_made:
        try:
            section_view(w, made[n], "XZ", 0.0, hatch=hatches.get(n, "//"), direction="front")
        except Exception as e:
            print("section fail", n, e)
    for n in ("disc", "pcb", "components", "pad", "led_board", "bearings", "wheel_screws", "speaker", "tyre", "drive_motor", "solenoid"):
        try:
            section_view(w, refs[n], "XZ", 0.0, hatch="", colour="0.45", direction="front")
        except Exception as e:
            print("ref section fail", n, e)
    centreline_v(ax, w.ox, w.oy - 6, w.oy + 40)
    _, yt2 = S(0, Z_KNOB_TOP, w); xr2, _ = S(R_KNOB, 0, w); xl2, _ = S(-R_KNOB, 0, w)
    dim_leader(ax, *S(WHEEL_AXIS_R, Z_RIDGE_MID, w), xr2 + 6, yt2 + 4, "V-collar on 623ZZ\nin the ridge (0°)")
    dim_leader(ax, *S(-R_FLANGE_BORE + 2, (Z_TYRE0 + Z_TYRE1) / 2, w), xl2 - 6, yt2 + 4, "drive tyre, idle 1.0 off\nthe bore; motor (180°)", ha="right")
    view_title(ax, w.ox, yt2 + 22, "B-B  (plane 0°-180°)")
    # parts list
    x0, y0 = 290, 272
    ax.text(x0, y0, "PARTS LIST — made", fontsize=FS_TITLE, weight="bold", va="top")
    rows = [("60-07-01", "Base plate", "laser-cut steel 3 mm", 1), ("60-07-02", "Base shell", "PETG / PA12", 1), ("60-07-03", "Halo diffuser", "opal PMMA / PETG", 1),
            ("60-07-04", "Knob body", "PETG / 6082 Al", 1), ("60-07-05", "Knob crown", "PETG / 6082 Al", 1), ("60-07-06", "Magnet ring A", "PETG / brass", 1),
            ("60-07-07", "Magnet ring B", "PETG / brass", 1), ("60-07-08", "Rocker", "PETG / brass", 1), ("60-07-09", "Drive arm", "PETG / Al", 1),
            ("60-07-10", "Wheel V-collar", "POM / PETG", 3), ("60-07-11", "Tyre hub", "PETG / POM", 1)]
    for i, (no, nm, mat, q) in enumerate(rows):
        yy = y0 - 5.5 * (i + 1)
        ax.text(x0, yy, no, fontsize=5.5, va="top"); ax.text(x0 + 20, yy, nm, fontsize=5.5, va="top"); ax.text(x0 + 55, yy, mat, fontsize=5.5, va="top"); ax.text(x0 + 100, yy, str(q), fontsize=5.5, va="top")
    y1 = y0 - 5.5 * (len(rows) + 2)
    bought = ["BOUGHT (envelopes): display 3.4C Ø115 x 6 + board; 3x 623ZZ + Ø3 dowels;",
              "6x magnets 3x3x6 N42; 60x Ø3 steel balls; Ø8 planetary gearmotor + worm;",
              f"flat gimbal motor Ø{DRIVE_MOTOR_D:.0f} x {DRIVE_MOTOR_H:.0f}; O-ring tyre; solenoid Ø6; AEDR-8300 encoder;",
              "LRA; speaker Ø36; port board (USB-C, hub, CS43131, jack); 2x supercaps Ø8 x 16;",
              "90-LED ring board; rubber pad; screws 4x M3 csk, 4x M2.5 x 16, 6x M2 x 22."]
    for i, line in enumerate(bought):
        ax.text(x0, y1 - 4.5 * i, line, fontsize=5.0, va="top")
    # stack table
    y2 = y1 - 30
    ax.text(x0, y2, "HEIGHT STACK (z from the plate underside)", fontsize=FS_TITLE, weight="bold", va="top")
    stack = [(f"-{PAD_T:.1f} – 0", "rubber pad"), (f"0 – {BASE_PLATE_T:.0f}", "steel plate; port board and motors on the pad in pockets"),
             (f"{Z_PLATE_TOP:.0f} – {Z_PLINTH_TOP:.0f}", "plinth band; cable tunnel at 90°"), (f"{HALO_Z0:.0f} – {HALO_Z1:.0f}", "halo ring (360°)"),
             (f"{RING_A_Z0} – {RING_B_Z1}", "magnet rings A and B under the ledge; legs to 8.4"), (f"{Z_SKIRT_BOT}", "knob skirt bottom (0.6 shadow gap)"),
             (f"{M.Z_LEDGE_BOT} – {Z_LEDGE_TOP}", "ledge: tower slots, posts"), (f"{Z_TYRE0} – {Z_TYRE1}", "drive tyre band on the flange bore"),
             (f"{Z_MAG_BOT:.1f} – {Z_MAG_TOP:.1f}", f"magnets; pegs at {PEG_Z:.1f}"), (f"{Z_CODE0:.1f} – {Z_CODE1:.1f}", "code band (encoder)"),
             (f"{Z_WHEEL0} – {Z_WHEEL1}", "wheels in the ridge"), (f"{Z_DISC_BOT:.1f} – {Z_DISC_TOP:.1f}", f"display disc (board hangs to {Z_COMP_BOT:.1f})"),
             (f"{Z_CROWN_BOT:.1f} – {Z_CROWN_TOP:.1f}", "crown")]
    for i, (z, what) in enumerate(stack):
        yy = y2 - 5.0 * (i + 1)
        ax.text(x0, yy, z, fontsize=5.2, va="top"); ax.text(x0 + 24, yy, what, fontsize=5.2, va="top")
    return sh.save(os.path.join(DWG, "00-assembly.png"))

SHEETS.update({"plate": sheet_plate, "shell": sheet_shell, "shell2": sheet_shell2, "body": sheet_body, "ring_a": sheet_ring_a,
               "ring_b": sheet_ring_b, "rocker": sheet_rocker, "arm": sheet_arm, "hub": sheet_hub, "assembly": sheet_assembly})

if __name__ == "__main__":
    names = sys.argv[1:] or list(SHEETS)
    for n in names:
        print("->", SHEETS[n](), flush=True)

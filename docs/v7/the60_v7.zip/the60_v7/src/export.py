"""Export every made part as STEP + STL (print orientation noted in the README) and
the full assembly (made + references) as one STEP. python export.py"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from model import *
import model as M

T0 = time.time()
made = made_parts("on", knurl=KNURL_ON)
refs = ref_parts("on")
PRINT_NOTE = {
    "base_plate": "STEEL - laser-cut from 3 mm S275 (DXF from the STEP's top face)",
    "base_shell": "print upright on the plinth, no supports, 0.2 mm layers",
    "halo_diffuser": "print on its underside; natural/translucent PETG",
    "knob_body": "print FLANGE DOWN (as modelled), 0.16 mm layers; peg holes are horizontal",
    "knob_crown": "print TOP FACE DOWN (flip 180 deg); chamfers become 45 deg overhangs",
    "ring_a": "print as modelled (ring flat on the bed); towers vertical",
    "ring_b": "print as modelled",
    "rocker": "print flat as modelled",
    "drive_plate": "print flat as modelled",
    "tyre_hub": "print flat, 0.12 mm layers; fit a 2 mm-section O-ring",
    "collar_0": "print axis vertical, 0.12 mm layers (x3)",
}
parts_dir = os.path.join(OUT, "parts"); os.makedirs(parts_dir, exist_ok=True)
for n, s in made.items():
    if n.startswith("collar_") and n != "collar_0":
        continue
    shape = wheel_collar() if n == "collar_0" else (tyre_hub() if n == "tyre_hub" else s)
    export_step(shape, os.path.join(parts_dir, f"{n}.step"), write_pcurves=False)
    export_stl(shape, os.path.join(parts_dir, f"{n}.stl"), tolerance=0.02, angular_tolerance=0.1)
    print(f"  {n:14s} {shape.volume/1000:7.2f} cm3  {PRINT_NOTE.get(n, '')}", flush=True)
# assembly
asm = Compound(children=[s for s in list(made.values()) + list(refs.values())])
export_step(asm, os.path.join(OUT, "the60_v7_assembly.step"), write_pcurves=False)
# assembly in the clicks-off / drive-engaged state too
made_off = made_parts("off", knurl=KNURL_ON); refs_off = ref_parts("off")
asm2 = Compound(children=[s for s in list(made_off.values()) + list(refs_off.values())])
export_step(asm2, os.path.join(OUT, "the60_v7_assembly_clicks_off.step"), write_pcurves=False)
with open(os.path.join(parts_dir, "README.txt"), "w") as f:
    f.write("the 60 - v7 - printable parts\n\n")
    for n, note in PRINT_NOTE.items():
        f.write(f"{n:14s} {note}\n")
    f.write("\nBought: 3x 623ZZ + Ø3x9 dowel pins; 6x 3x3x6 N42 magnets; 60x Ø3 chrome-steel balls; Ø8 planetary gearmotor + worm;\n"
            "flat gimbal motor Ø16x7 (V); O-ring 2 mm section ID ~41; 6 mm push solenoid; AEDR-8300; LRA; speaker; port board; LED ring board.\n")
print(f"done in {time.time()-T0:.0f}s")

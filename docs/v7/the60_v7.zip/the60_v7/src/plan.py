"""Plan-view slices of the whole assembly at several heights (debug aid).
python plan.py [state]  -> out/plan_<state>.png"""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from model import *

state = sys.argv[1] if len(sys.argv) > 1 else "on"
zs = [float(z) for z in sys.argv[2:]] or [1.5, 5.4, 6.8, 8.0, 9.9, 11.2, 15.0, 21.0]
made = made_parts(state, knurl=False); refs = ref_parts(state)
allp = {**made, **refs}
colors = {}
import itertools
palette = plt.cm.tab20.colors
for i, n in enumerate(allp):
    colors[n] = palette[i % 20]

def slice_edges(shape, z):
    slab = Pos(0, 0, z) * Box(300, 300, 0.02, align=(C, C, C))
    try:
        sec = shape & slab
    except Exception:
        return []
    out = []
    if sec is None:
        return out
    for e in sec.edges():
        pts = [e.position_at(t) for t in [i / 12 for i in range(13)]]
        if abs(pts[0].Z - z) > 0.05:
            continue
        out.append([(p.X, p.Y) for p in pts])
    return out

fig, axes = plt.subplots(2, 4, figsize=(26, 13))
for ax, z in zip(axes.flat, zs):
    ax.set_aspect("equal"); ax.set_title(f"z = {z}  [{state}]"); ax.set_xlim(-65, 65); ax.set_ylim(-65, 65)
    ax.add_patch(plt.Circle((0, 0), R_KNOB, fill=False, color="0.7", ls="--"))
    ax.add_patch(plt.Circle((0, 0), R_FLANGE_BORE, fill=False, color="0.8", ls=":"))
    for n, s in allp.items():
        bb = s.bounding_box()
        if bb.min.Z > z or bb.max.Z < z:
            continue
        for seg in slice_edges(s, z):
            xs, ys = zip(*seg)
            ax.plot(xs, ys, color=colors[n], lw=0.9)
        ax.plot([], [], color=colors[n], label=n)
    ax.legend(fontsize=5, loc="upper right", ncol=2)
    ax.grid(alpha=0.2)
plt.tight_layout()
plt.savefig(os.path.join(OUT, f"plan_{state}.png"), dpi=90)
print("wrote", f"out/plan_{state}.png")

"""Technical-drawing framework: A3 sheet, frame, zones, title block, projected
views with hidden lines (OCC HLR), sections with hatching, ISO-style dimensions.
Everything is drawn in sheet millimetres on a matplotlib axes."""
import math, os, sys, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import PathPatch, Polygon as MplPolygon, Circle as MplCircle, FancyArrow
from matplotlib.path import Path
import numpy as np
from build123d import *
from params import *

SHEET_W, SHEET_H = 420.0, 297.0
MARGIN = 10.0
LW_THICK, LW_THIN, LW_HID = 0.5, 0.25, 0.25
FS_DIM, FS_TXT, FS_TITLE = 7.0, 6.0, 8.5         # points (~2.5 / 2.1 / 3 mm)
BLACK = "black"
BLUE = "#1f4e9c"
matplotlib.rcParams["font.family"] = "DejaVu Sans"
matplotlib.rcParams["hatch.linewidth"] = 0.3

# ------------------------------------------------------------------ sheet
class Sheet:
    def __init__(self, title, part_no, material, treatment, scale_txt, weight_g, sheet=1, of=1, notes="", stock="", rev="A", post=""):
        self.fig = plt.figure(figsize=(SHEET_W / 25.4, SHEET_H / 25.4), dpi=200)
        self.ax = self.fig.add_axes([0, 0, 1, 1])
        ax = self.ax
        ax.set_xlim(0, SHEET_W); ax.set_ylim(0, SHEET_H); ax.set_aspect("equal"); ax.axis("off")
        self.title = title
        self._frame()
        self._title_block(title, part_no, material, treatment, scale_txt, weight_g, sheet, of, notes, stock, rev, post)

    def _frame(self):
        ax = self.ax
        ax.add_patch(MplPolygon([(MARGIN, MARGIN), (SHEET_W - MARGIN, MARGIN), (SHEET_W - MARGIN, SHEET_H - MARGIN), (MARGIN, SHEET_H - MARGIN)], fill=False, lw=0.7))
        ax.add_patch(MplPolygon([(2, 2), (SHEET_W - 2, 2), (SHEET_W - 2, SHEET_H - 2), (2, SHEET_H - 2)], fill=False, lw=0.35))
        # zones: 8 columns, 6 rows
        for i in range(8):
            x0 = MARGIN + (SHEET_W - 2 * MARGIN) * i / 8
            x1 = MARGIN + (SHEET_W - 2 * MARGIN) * (i + 1) / 8
            for y in (MARGIN, SHEET_H - MARGIN):
                ax.plot([x1, x1], [y - (8 if y == MARGIN else 0), y + (8 if y != MARGIN else 0)], lw=0.35, color=BLACK) if i < 7 else None
            ax.text((x0 + x1) / 2, 5.5, str(i + 1), ha="center", va="center", fontsize=FS_TXT)
            ax.text((x0 + x1) / 2, SHEET_H - 5.5, str(i + 1), ha="center", va="center", fontsize=FS_TXT)
        for j in range(6):
            y0 = SHEET_H - MARGIN - (SHEET_H - 2 * MARGIN) * j / 6
            y1 = SHEET_H - MARGIN - (SHEET_H - 2 * MARGIN) * (j + 1) / 6
            for x in (MARGIN, SHEET_W - MARGIN):
                if j < 5:
                    ax.plot([x - (8 if x == MARGIN else 0), x + (8 if x != MARGIN else 0)], [y1, y1], lw=0.35, color=BLACK)
            ax.text(5.5, (y0 + y1) / 2, "ABCDEF"[j], ha="center", va="center", fontsize=FS_TXT)
            ax.text(SHEET_W - 5.5, (y0 + y1) / 2, "ABCDEF"[j], ha="center", va="center", fontsize=FS_TXT)

    def _title_block(self, title, part_no, material, treatment, scale_txt, weight_g, sheet, of, notes, stock, rev, post):
        ax = self.ax
        x0, y0 = SHEET_W - MARGIN - 190, MARGIN
        W, H = 190.0, 48.0
        def box(x, y, w, h, lw=0.5):
            ax.add_patch(MplPolygon([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], fill=False, lw=lw))
        def t(x, y, s, fs=FS_TXT, ha="left", va="center", weight="normal"):
            ax.text(x, y, s, fontsize=fs, ha=ha, va=va, weight=weight)
        box(x0, y0, W, H)
        # left column: company / confidentiality
        box(x0, y0 + 30, 60, 18)
        t(x0 + 2, y0 + 45, "CADRANE", fs=FS_TITLE, weight="bold")
        t(x0 + 2, y0 + 41, "the 60 — a haptic desk dial", fs=FS_TXT)
        t(x0 + 2, y0 + 36.5, "© Cadrane 2026. This drawing and the design shown are the", fs=4.2)
        t(x0 + 2, y0 + 34.2, "confidential property of Cadrane; not to be copied or", fs=4.2)
        t(x0 + 2, y0 + 32, "communicated without written consent.", fs=4.2)
        box(x0 + 60, y0 + 30, 30, 18)
        t(x0 + 75, y0 + 43.5, "General tolerance", ha="center", fs=5.2)
        t(x0 + 75, y0 + 39.5, "ISO 2768-mK", ha="center", fs=5.2)
        t(x0 + 75, y0 + 34.5, "unless stated", ha="center", fs=4.5)
        box(x0 + 90, y0 + 30, 26, 18)
        self._projection_symbol(x0 + 103, y0 + 41)
        t(x0 + 103, y0 + 33.5, "First angle", ha="center", fs=4.5)
        # right block
        box(x0 + 116, y0 + 39, 74, 9)
        t(x0 + 118, y0 + 43.5, f"Scale: {scale_txt}")
        t(x0 + 154, y0 + 43.5, (f"Weight [g]: {weight_g:.1f}" if weight_g < 10 else f"Weight [g]: {weight_g:.0f}") if weight_g else "Weight [g]: —")
        box(x0 + 116, y0 + 30, 74, 9)
        t(x0 + 118, y0 + 36.5, f"Material: {material}", fs=5.5)
        t(x0 + 118, y0 + 32.3, f"Surface: {treatment}", fs=5.5)
        # revision table (left, lower)
        box(x0, y0, 60, 30)
        for i in range(1, 5):
            ax.plot([x0, x0 + 60], [y0 + 6 * i, y0 + 6 * i], lw=0.35, color=BLACK)
        for xx in (x0 + 8, x0 + 32, x0 + 46):
            ax.plot([xx, xx], [y0, y0 + 30], lw=0.35, color=BLACK)
        t(x0 + 4, y0 + 3, "Rev.", ha="center", fs=4.8); t(x0 + 20, y0 + 3, "Change", ha="center", fs=4.8)
        t(x0 + 39, y0 + 3, "Date", ha="center", fs=4.8); t(x0 + 53, y0 + 3, "Name", ha="center", fs=4.8)
        t(x0 + 4, y0 + 9, rev, ha="center", fs=4.8); t(x0 + 20, y0 + 9, "v7 initial", ha="center", fs=4.8)
        t(x0 + 39, y0 + 9, datetime.date.today().isoformat(), ha="center", fs=4.4); t(x0 + 53, y0 + 9, "Claude", ha="center", fs=4.8)
        # created / review
        box(x0 + 60, y0, 56, 30)
        ax.plot([x0 + 60, x0 + 116], [y0 + 24, y0 + 24], lw=0.35, color=BLACK)
        ax.plot([x0 + 60, x0 + 116], [y0 + 18, y0 + 18], lw=0.35, color=BLACK)
        ax.plot([x0 + 76, x0 + 76], [y0 + 12, y0 + 30], lw=0.35, color=BLACK)
        ax.plot([x0 + 96, x0 + 96], [y0 + 12, y0 + 30], lw=0.35, color=BLACK)
        t(x0 + 86, y0 + 27, "Date", ha="center", fs=4.8); t(x0 + 106, y0 + 27, "Name", ha="center", fs=4.8)
        t(x0 + 62, y0 + 21, "Created", fs=4.8); t(x0 + 86, y0 + 21, datetime.date.today().isoformat(), ha="center", fs=4.4); t(x0 + 106, y0 + 21, "Claude", ha="center", fs=4.8)
        t(x0 + 62, y0 + 15, "Review", fs=4.8); t(x0 + 106, y0 + 15, "R. (Cadrane)", ha="center", fs=4.5)
        t(x0 + 88, y0 + 6, "Post treatment: " + (post or "—"), ha="center", fs=4.8)
        # notes and identity
        box(x0 + 116, y0 + 12, 74, 18)
        t(x0 + 118, y0 + 27, "Notes:", fs=5.2)
        for i, line in enumerate(notes.split("\n")[:4]):
            t(x0 + 118, y0 + 23.5 - 3.2 * i, line, fs=4.5)
        box(x0 + 116, y0, 74, 12)
        ax.plot([x0 + 116, x0 + 190], [y0 + 6, y0 + 6], lw=0.35, color=BLACK)
        ax.plot([x0 + 156, x0 + 156], [y0, y0 + 12], lw=0.35, color=BLACK)
        ax.plot([x0 + 173, x0 + 173], [y0, y0 + 12], lw=0.35, color=BLACK)
        t(x0 + 118, y0 + 9.5, f"Item: {part_no}", fs=5.5, weight="bold")
        t(x0 + 118, y0 + 3, title, fs=6.0, weight="bold")
        t(x0 + 158, y0 + 9.5, "Status", fs=4.5); t(x0 + 158, y0 + 7, "PROTOTYPE", fs=4.5, weight="bold")
        t(x0 + 158, y0 + 3.5, "Stock: " + (stock or "—"), fs=4.2)
        t(x0 + 175, y0 + 9.5, "Format", fs=4.5); t(x0 + 175, y0 + 7, "A3", fs=5)
        t(x0 + 175, y0 + 3.5, f"Sheet {sheet} / {of}", fs=4.5)

    def _projection_symbol(self, cx, cy):
        ax = self.ax
        # first-angle: truncated cone (side) on the left, two circles (end view) on the right
        ax.add_patch(MplPolygon([(cx - 11, cy - 2.2), (cx - 4, cy - 3.2), (cx - 4, cy + 3.2), (cx - 11, cy + 2.2)], fill=False, lw=0.5))
        ax.plot([cx - 11, cx - 4], [cy, cy], lw=0.3, color=BLACK, ls=(0, (6, 2, 1, 2)))
        ax.add_patch(MplCircle((cx + 5, cy), 3.2, facecolor="none", edgecolor=BLACK, lw=0.5))
        ax.add_patch(MplCircle((cx + 5, cy), 2.2, facecolor="none", edgecolor=BLACK, lw=0.5))
        ax.plot([cx + 0.5, cx + 9.5], [cy, cy], lw=0.3, color=BLACK, ls=(0, (6, 2, 1, 2)))
        ax.plot([cx + 5, cx + 5], [cy - 4.5, cy + 4.5], lw=0.3, color=BLACK, ls=(0, (6, 2, 1, 2)))

    def text(self, x, y, s, fs=FS_TXT, **kw):
        self.ax.text(x, y, s, fontsize=fs, **kw)

    def save(self, path):
        self.fig.savefig(path, dpi=200)
        pdf = os.path.splitext(path)[0] + ".pdf"
        self.fig.savefig(pdf)
        plt.close(self.fig)
        return path

# ------------------------------------------------------------------ views
class View:
    """A 2D view of a shape placed on the sheet. Model units -> sheet via scale;
    (u, v) view coordinates map to sheet (ox + s*u, oy + s*v)."""
    def __init__(self, sheet, ox, oy, scale=1.0):
        self.sheet, self.ax, self.ox, self.oy, self.s = sheet, sheet.ax, ox, oy, scale
    def to_sheet(self, u, v):
        return self.ox + self.s * u, self.oy + self.s * v
    def plot_edges(self, edges, lw, ls="-", color=BLACK, n=24):
        for e in edges:
            if e.geom_type == GeomType.LINE:
                pts = [e.start_point(), e.end_point()]
            else:
                n = max(12, min(600, int(e.length * self.s / 0.6)))
                pts = [e.position_at(i / n) for i in range(n + 1)]
            xs = [self.ox + self.s * p.X for p in pts]; ys = [self.oy + self.s * p.Y for p in pts]
            self.ax.plot(xs, ys, lw=lw, color=color, ls=ls, solid_capstyle="round")
    def project(self, shape, direction="front", hidden=True, up=None, colour=BLACK, lw=None):
        """direction: 'front' (looking along +Y, sees X-Z), 'top' (sees X-Y), 'right' (sees Y-Z), 'bottom'."""
        D = 100000.0
        if direction == "front":
            org, up_ = (0, -D, 0), (0, 0, 1)
        elif direction == "back":
            org, up_ = (0, D, 0), (0, 0, 1)
        elif direction == "top":
            org, up_ = (0, 0, D), (0, 1, 0)
        elif direction == "bottom":
            org, up_ = (0, 0, -D), (0, 1, 0)
        elif direction == "right":
            org, up_ = (D, 0, 0), (0, 0, 1)
        elif direction == "left":
            org, up_ = (-D, 0, 0), (0, 0, 1)
        else:
            org, up_ = direction, up or (0, 0, 1)
        vis, hid = shape.project_to_viewport(org, viewport_up=up_, look_at=(0, 0, 0))
        if hidden:
            self.plot_edges(hid, LW_HID, ls=(0, (3, 1.5)), color="0.35")
        self.plot_edges(vis, lw or LW_THICK, color=colour)
        return vis, hid
    def section(self, shape, plane="XZ", offset=0.0, hatch="////", fill_hidden=False, colour=BLACK):
        """Cut the shape with a plane (XZ: y=offset, YZ: x=offset, XY: z=offset)
        and hatch the cut faces. Returns the cut faces' 2D polygons (u, v)."""
        eps = 0.02
        if plane == "XZ":
            slab = Pos(0, offset, 0) * Box(400, eps, 400, align=(Align.CENTER, Align.CENTER, Align.CENTER))
            uv = lambda p: (p.X, p.Z)
            nrm = (0, 1, 0)
        elif plane == "YZ":
            slab = Pos(offset, 0, 0) * Box(eps, 400, 400, align=(Align.CENTER, Align.CENTER, Align.CENTER))
            uv = lambda p: (-p.Y, p.Z) if False else (p.Y, p.Z)
            nrm = (1, 0, 0)
        else:
            slab = Pos(0, 0, offset) * Box(400, 400, eps, align=(Align.CENTER, Align.CENTER, Align.CENTER))
            uv = lambda p: (p.X, p.Y)
            nrm = (0, 0, 1)
        sec = shape & slab
        polys = []
        faces = sec.faces() if hasattr(sec, "faces") else []
        for f in faces:
            n = f.normal_at()
            if abs(abs(n.dot(Vector(*nrm))) - 1) > 0.01:
                continue
            # keep faces on the +side of the slab only (one of the two parallel faces)
            c = f.center()
            coord = {"XZ": c.Y, "YZ": c.X, "XY": c.Z}[plane]
            if coord < offset:
                continue
            wires = [f.outer_wire()] + list(f.inner_wires())
            rings = []
            for w in wires:
                pts = []
                for e in w.edges():
                    k = 2 if e.geom_type == GeomType.LINE else 16
                    pts += [uv(e.position_at(i / k)) for i in range(k)]
                # order the points along the wire
                pts = _order_wire(w, uv)
                rings.append(pts)
            polys.append(rings)
        for rings in polys:
            verts, codes = [], []
            for ring in rings:
                if len(ring) < 3:
                    continue
                pts = [self.to_sheet(u, v) for u, v in ring] + [self.to_sheet(*ring[0])]
                verts += pts
                codes += [Path.MOVETO] + [Path.LINETO] * (len(pts) - 2) + [Path.CLOSEPOLY]
            if not verts:
                continue
            patch = PathPatch(Path(verts, codes), facecolor="none", edgecolor=colour, hatch=hatch, lw=LW_THICK)
            self.ax.add_patch(patch)
        return polys

def half_behind(shape, plane="XZ", offset=0.0):
    """The part of the shape behind the cutting plane (kept side: +Y for XZ, +X for YZ, +Z for XY)."""
    big = 500.0
    if plane == "XZ":
        keep = Pos(0, offset + big / 2, 0) * Box(big, big, big)
    elif plane == "YZ":
        keep = Pos(offset - big / 2, 0, 0) * Box(big, big, big)     # viewed from +X: keep what lies beyond the cut
    else:
        keep = Pos(0, 0, offset - big / 2) * Box(big, big, big)     # viewed from +Z
    return shape & keep

def section_view(view, shape, plane="XZ", offset=0.0, hatch="////", direction=None, hidden=False, colour=BLACK, section_only=False):
    """A proper section: only what lies behind the cutting plane is drawn, the cut
    faces are hatched. direction defaults to looking at the cut face."""
    if not section_only:
        half = half_behind(shape, plane, offset)
        d = direction or {"XZ": "front", "YZ": "right", "XY": "top"}[plane]
        view.project(half, d, hidden=hidden, colour=colour, lw=(LW_THICK if colour == BLACK else 0.35))
    view.section(shape, plane, offset, hatch=hatch, colour=colour)
    return None

def _order_wire(w, uv):
    pts = []
    for e in w.edges():
        k = 2 if e.geom_type == GeomType.LINE else max(12, min(600, int(e.length / 0.4)))
        seg = [e.position_at(i / k) for i in range(k + 1)]
        if pts and (seg[0] - pts[-1]).length > (seg[-1] - pts[-1]).length:
            seg = seg[::-1]
        if pts and (seg[0] - pts[-1]).length > 0.5 and (seg[-1] - pts[0]).length < 0.5:
            pts = pts[::-1]
        pts += seg[1:] if pts and (seg[0] - pts[-1]).length < 0.5 else seg
    return [uv(p) for p in pts]

# ------------------------------------------------------------------ dimensions (sheet coordinates)
ARROW = dict(head_width=1.4, head_length=3.0, lw=0.25, color=BLACK, length_includes_head=True)

def _arrow(ax, x0, y0, x1, y1):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0), arrowprops=dict(arrowstyle="-|>", lw=LW_THIN, color=BLACK, mutation_scale=6, shrinkA=0, shrinkB=0))

def dim_h(ax, x1, x2, y_line, y_ext0, text, above=True, ext=2.0, fs=FS_DIM, text_dx=0.0):
    """Horizontal dimension between x1 and x2, dimension line at y_line, extension lines from y_ext0."""
    for x in (x1, x2):
        d = 1 if y_line > y_ext0 else -1
        ax.plot([x, x], [y_ext0 + 0.8 * d, y_line + ext * d], lw=LW_THIN, color=BLACK)
    if abs(x2 - x1) > 8:
        _arrow(ax, (x1 + x2) / 2, y_line, x1, y_line); _arrow(ax, (x1 + x2) / 2, y_line, x2, y_line)
    else:
        _arrow(ax, x1 - 6, y_line, x1, y_line); _arrow(ax, x2 + 6, y_line, x2, y_line)
        ax.plot([x1, x2], [y_line, y_line], lw=LW_THIN, color=BLACK)
    ax.text((x1 + x2) / 2 + text_dx, y_line + (1.0 if above else -1.0), text, ha="center", va="bottom" if above else "top", fontsize=fs)

def dim_v(ax, y1, y2, x_line, x_ext0, text, left=False, ext=2.0, fs=FS_DIM, text_dy=0.0):
    for y in (y1, y2):
        d = 1 if x_line > x_ext0 else -1
        ax.plot([x_ext0 + 0.8 * d, x_line + ext * d], [y, y], lw=LW_THIN, color=BLACK)
    if abs(y2 - y1) > 8:
        _arrow(ax, x_line, (y1 + y2) / 2, x_line, y1); _arrow(ax, x_line, (y1 + y2) / 2, x_line, y2)
    else:
        _arrow(ax, x_line, y1 - 6, x_line, y1); _arrow(ax, x_line, y2 + 6, x_line, y2)
        ax.plot([x_line, x_line], [y1, y2], lw=LW_THIN, color=BLACK)
    ax.text(x_line + (-1.0 if left else 1.0), (y1 + y2) / 2 + text_dy, text, ha="right" if left else "left", va="center", fontsize=fs, rotation=90)

def dim_leader(ax, x, y, tx, ty, text, fs=FS_DIM, ha="left", dot=False):
    _arrow(ax, tx, ty, x, y)
    ax.plot([tx, tx + (3 if ha == "left" else -3)], [ty, ty], lw=LW_THIN, color=BLACK)
    ax.text(tx + (3.5 if ha == "left" else -3.5), ty, text, ha=ha, va="center", fontsize=fs)
    if dot:
        ax.plot([x], [y], "o", ms=1.5, color=BLACK)

def dim_r(ax, cx, cy, r, ang_deg, text, L=8.0, fs=FS_DIM):
    a = math.radians(ang_deg)
    px, py = cx + r * math.cos(a), cy + r * math.sin(a)
    tx, ty = cx + (r + L) * math.cos(a), cy + (r + L) * math.sin(a)
    _arrow(ax, tx, ty, px, py)
    ax.text(tx + 1.0 * math.cos(a), ty + 1.0 * math.sin(a), text, fontsize=fs, ha="left" if math.cos(a) >= 0 else "right", va="center")

def dim_ang(ax, cx, cy, r, a0, a1, text, fs=FS_DIM):
    th = np.linspace(math.radians(a0), math.radians(a1), 30)
    ax.plot(cx + r * np.cos(th), cy + r * np.sin(th), lw=LW_THIN, color=BLACK)
    am = math.radians((a0 + a1) / 2)
    ax.text(cx + (r + 2.5) * math.cos(am), cy + (r + 2.5) * math.sin(am), text, fontsize=fs, ha="center", va="center")

def centreline_h(ax, x0, x1, y):
    ax.plot([x0, x1], [y, y], lw=0.25, color=BLACK, ls=(0, (8, 2, 1.5, 2)))
def centreline_v(ax, x, y0, y1):
    ax.plot([x, x], [y0, y1], lw=0.25, color=BLACK, ls=(0, (8, 2, 1.5, 2)))
def centre_cross(ax, x, y, r):
    centreline_h(ax, x - r, x + r, y); centreline_v(ax, x, y - r, y + r)

def datum(ax, x, y, letter, dx=0.0, dy=-6.0):
    ax.add_patch(MplPolygon([(x - 1.2, y), (x + 1.2, y), (x, y + 1.8)], closed=True, color=BLACK))
    ax.plot([x, x + dx], [y + 1.8, y + 1.8 + dy * 0 + (dy if dx == 0 else 0)], lw=LW_THIN, color=BLACK) if False else None
    bx, by = x + dx, y + dy
    ax.plot([x, bx], [y, by + (2.0 if dy < 0 else -2.0)], lw=LW_THIN, color=BLACK)
    ax.add_patch(MplPolygon([(bx - 2.2, by - 2.0), (bx + 2.2, by - 2.0), (bx + 2.2, by + 2.0), (bx - 2.2, by + 2.0)], fill=False, lw=LW_THIN))
    ax.text(bx, by, letter, ha="center", va="center", fontsize=FS_DIM)

def tol_frame(ax, x, y, symbol, value, datum_ref=None):
    w = 6.0 + 9.0 + (5.0 if datum_ref else 0)
    ax.add_patch(MplPolygon([(x, y - 2.2), (x + w, y - 2.2), (x + w, y + 2.2), (x, y + 2.2)], fill=False, lw=LW_THIN))
    ax.plot([x + 6, x + 6], [y - 2.2, y + 2.2], lw=LW_THIN, color=BLACK)
    ax.text(x + 3, y, symbol, ha="center", va="center", fontsize=FS_DIM)
    ax.text(x + 10.5, y, value, ha="center", va="center", fontsize=FS_DIM)
    if datum_ref:
        ax.plot([x + 15, x + 15], [y - 2.2, y + 2.2], lw=LW_THIN, color=BLACK)
        ax.text(x + 17.5, y, datum_ref, ha="center", va="center", fontsize=FS_DIM)

def surface_mark(ax, x, y, ra, fs=5.5, angle=0.0):
    """ISO 1302-style tick with Ra value."""
    a = math.radians(angle)
    def r(px, py):
        return x + px * math.cos(a) - py * math.sin(a), y + px * math.sin(a) + py * math.cos(a)
    pts = [r(0, 0), r(1.6, 3.2), r(3.2, 0)][::-1]
    xs = [r(-1.6, 0)[0], r(0, 0)[0]]  # unused
    p1, p2, p3 = r(-1.8, 0), r(0, -3.0), r(2.4, 3.6)
    ax.plot([p1[0], p2[0], p3[0]], [p1[1], p2[1], p3[1]], lw=LW_THIN, color=BLACK)
    t = r(-2.0, 1.8)
    ax.text(t[0], t[1], f"Ra {ra}", fontsize=fs, ha="right", va="center", rotation=angle)

def section_marks(ax, x, y0, y1, label, side=1, horizontal=False):
    """Cutting-plane marks with arrows and letters at both ends."""
    if not horizontal:
        for y, d in ((y0, -1), (y1, 1)):
            ax.plot([x, x], [y, y + d * 6], lw=0.8, color=BLACK)
            _arrow(ax, x + side * 8, y + d * 4, x + side * 2, y + d * 4)
            ax.text(x + side * 10, y + d * 4, label, fontsize=FS_TITLE, ha="center", va="center", weight="bold")
    else:
        for xx, d in ((y0, -1), (y1, 1)):
            ax.plot([xx, xx + d * 6], [x, x], lw=0.8, color=BLACK)
            _arrow(ax, xx + d * 4, x + side * 8, xx + d * 4, x + side * 2)
            ax.text(xx + d * 4, x + side * 10, label, fontsize=FS_TITLE, ha="center", va="center", weight="bold")

def view_title(ax, x, y, text):
    ax.text(x, y, text, fontsize=FS_TITLE, ha="center", va="center", weight="bold")
    ax.plot([x - 8, x + 8], [y - 3.2, y - 3.2], lw=0.5, color=BLACK)

def note_block(ax, x, y, lines, fs=FS_TXT, title="NOTES"):
    ax.text(x, y, title, fontsize=fs + 0.5, weight="bold", va="top")
    for i, l in enumerate(lines):
        ax.text(x, y - 4.2 * (i + 1), l, fontsize=fs, va="top")

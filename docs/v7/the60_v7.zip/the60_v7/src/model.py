"""the 60 - v7 parametric model (build123d 0.11, algebra mode).

Made parts:  base_plate (steel), base_shell, halo_diffuser, knob_body, knob_crown,
             ring_a, ring_b, rocker, drive_plate, wheel_collar x3
Bought parts drawn as references (ref_*): disc, pcb, components, bearings, magnets,
pegs, N20 + worm, drive motor + tyre, solenoid, encoder, LRA, speaker, port board,
USB-C, jack, plugs, supercaps, pad, LED board, light sensor.
"""
import math, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build123d import *
from params import *

C, MN, MX = Align.CENTER, Align.MIN, Align.MAX
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
os.makedirs(OUT, exist_ok=True)

# --------------------------------------------------------------- primitives
def cyl(r, z0, z1):
    return Pos(0, 0, z0) * Cylinder(r, z1 - z0, align=(C, C, MN))

def tube(ro, ri, z0, z1, eps=0.01):
    return cyl(ro, z0, z1) - cyl(ri, z0 - eps, z1 + eps)

def frustum(r0, r1, z0, z1):
    return Pos(0, 0, z0) * Cone(r0, r1, z1 - z0, align=(C, C, MN))

def polar(az, r, z=0.0):
    a = math.radians(az)
    return Pos(r * math.cos(a), r * math.sin(a), z)

def blk(radial, tangential, z0, z1, az, r, t=0.0):
    """Box centred at (az, r), radial x tangential footprint, tangential offset t."""
    b = Box(radial, tangential, z1 - z0, align=(C, C, MN))
    return polar(az, r, z0) * Rot(0, 0, az) * Pos(0, t, 0) * b

def xyblk(x0, x1, y0, y1, z0, z1):
    return Pos(x0, y0, z0) * Box(x1 - x0, y1 - y0, z1 - z0, align=(MN, MN, MN))

def zbore(d, z0, z1, az=0.0, r=0.0, t=0.0):
    return polar(az, r, z0) * Rot(0, 0, az) * Pos(0, t, 0) * Cylinder(d / 2, z1 - z0, align=(C, C, MN))

def rbore(d, r0, r1, az, z, t=0.0):
    """Radial cylinder from r0 to r1 at azimuth az, height z, tangential offset t."""
    c = Cylinder(d / 2, r1 - r0, align=(C, C, MN))
    return Pos(0, 0, z) * Rot(0, 0, az) * Pos(0, t, 0) * Rot(0, 90, 0) * Pos(0, 0, r0) * c

def tcyl(d, length, az, r, z, t=0.0):
    """Cylinder with a TANGENTIAL axis, centred at (az, r, z), offset t along its axis."""
    c = Cylinder(d / 2, length, align=(C, C, C))
    return Pos(0, 0, z) * Rot(0, 0, az) * Pos(r, t, 0) * Rot(90, 0, 0) * c

def revolve_profile(pts):
    return revolve(Plane.XZ * Polygon(*pts, align=None), Axis.Z)

def sector(az_mid, arc_deg, r_out, z0, z1, r_in=0.0):
    """Wedge (apex at the axis, or an annular sector if r_in > 0)."""
    n = max(4, int(arc_deg / 5) + 1)
    outer = [((r_out) * math.cos(math.radians(az_mid - arc_deg / 2 + arc_deg * i / n)),
              (r_out) * math.sin(math.radians(az_mid - arc_deg / 2 + arc_deg * i / n))) for i in range(n + 1)]
    if r_in > 0:
        inner = [((r_in) * math.cos(math.radians(az_mid - arc_deg / 2 + arc_deg * i / n)),
                  (r_in) * math.sin(math.radians(az_mid - arc_deg / 2 + arc_deg * i / n))) for i in range(n, -1, -1)]
        pts = outer + inner
    else:
        pts = [(0.0, 0.0)] + outer
    return extrude(Plane.XY.offset(z0) * Polygon(*pts, align=None), z1 - z0)

def ring_of(fn, azs):
    out = None
    for az in azs:
        s = fn(az)
        out = s if out is None else out + s
    return out

def volume_mm3(s):
    return s.volume

# --------------------------------------------------------------- derived
PCB_HOLES = [(sx * PCB_HOLE_DX / 2, sy * PCB_HOLE_DY / 2) for sx in (-1, 1) for sy in (-1, 1)]
Z_LEDGE_BOT = 8.60
RING_SEAT_Z = RING_SEAT_Z
SPK_R = SPEAKER_D / 2 + 0.3
TYRE_SWEEP_R = TYRE_D / 2 + DRIVE_LIFT / 2 + 0.5   # footprint the tyre needs free (centre at mid-travel)
CAM_Y0, CAM_Y1 = -CAMMOTOR_L / 2 - WORM_L - 1.0, CAMMOTOR_L / 2   # worm from -18 to -11, motor body -10..+10 along the tangent at CAMMOTOR_AZ
CROWN_REBATE_R = R_KNOB - CH_TOP - 0.4            # crown sits inside this on the skirt top
PORT_R_C = TUNNEL_R_BACK - PORT_BOARD_W / 2 - 0.5 # 38.5: port board centre radius; its outer edge at 45.5

# =============================================================== STEEL PLATE
def base_plate():
    """Laser-cut 3 mm steel. Ø122 with a tunnel notch at the back, the speaker
    aperture, six M3 countersinks, a pocket for the N20 (sits on the pad) and a
    pocket for the port board."""
    p = frustum(PLATE_R_BOT, PLATE_R, 0.0, BASE_PLATE_T)
    p -= cyl(SPEAKER_APERTURE / 2, -1, BASE_PLATE_T + 1)
    p -= tunnel_cut(-2.0)
    for az in PLATE_SCREW_AZ:
        p -= zbore(3.4, -1, BASE_PLATE_T + 1, az, PLATE_SCREW_R)
        p -= polar(az, PLATE_SCREW_R, -0.01) * Cone(3.4, 6.6, 1.6, align=(C, C, MN))
    p -= cam_motor_pocket()
    p -= sector(WORM_MESH_AZ, WORM_MESH_ARC + 2 * RING_TRAVEL_DEG + 2, RING_R_IN + 1.2, RING_A_TAB_Z0 - 0.5, BASE_PLATE_T + 1, r_in=RING_A_TAB_R_IN - 0.6)   # ring A's hanging tab sweeps here
    p -= port_bay(-1.0, BASE_PLATE_T + 1.0)
    (mx, my), _ = drive_geometry(True)
    p -= Pos(mx - DRIVE_LIFT / 2 * math.cos(math.radians(DRIVE_AZ)), my - DRIVE_LIFT / 2 * math.sin(math.radians(DRIVE_AZ)), -1) * Cylinder(DRIVE_PLATE_HOLE_D / 2, BASE_PLATE_T + 2, align=(C, C, MN))
    return p

def tunnel_cut(z0):
    """The rear cable tunnel: TUNNEL_W wide, from the back wall to beyond the edge."""
    return blk(PLATE_R - TUNNEL_R_BACK + 6.0, TUNNEL_W, z0, Z_PLINTH_TOP, AZ_PORTS,
               TUNNEL_R_BACK + (PLATE_R - TUNNEL_R_BACK + 6.0) / 2)

def cam_motor_pocket():
    """Slot through the plate for the Ø8 gearmotor + worm lying on the pad."""
    return polar(CAMMOTOR_AZ, WORM_AXIS_R, -2.0) * Rot(0, 0, CAMMOTOR_AZ) * Pos(0, (CAM_Y0 + CAM_Y1) / 2, 0) * \
        Box(CAMMOTOR_D + 1.0, CAM_Y1 - CAM_Y0 + 1.0, BASE_PLATE_T + 6, align=(C, C, MN))

def port_bay(z0, z1):
    """Pocket through the plate for the port board and its sockets (the board sits
    on the pad)."""
    return blk(PORT_BOARD_W + 3.5, PORT_BOARD_L + 4.0, z0, z1, AZ_PORTS, PORT_R_C + 0.25, t=PORT_BOARD_T_OFF)

def socket_bay():
    """What the shell must leave free above the plate: the USB-C receptacle and the
    jack body, each with 1 mm around."""
    zc = PORT_BOARD_Z0 + PORT_BOARD_T / 2
    u = blk(USBC_DEPTH + 2, USBC_W + 2, Z_PLATE_TOP - 1, zc + USBC_H / 2 + 0.4, AZ_PORTS, PORT_R_C + PORT_BOARD_W / 2 - USBC_DEPTH / 2 + 1.0, t=USBC_T_OFF)
    j = blk(JACK_BODY_L + 2, JACK_BODY_W + 2, Z_PLATE_TOP - 1, JACK_AXIS_Z + JACK_BODY_H / 2 + 0.1, AZ_PORTS, PORT_R_C + PORT_BOARD_W / 2 - JACK_BODY_L / 2, t=JACK_T_OFF)
    return u + j

# =============================================================== HALO DIFFUSER
def halo_diffuser():
    """Translucent 360 deg ring: inner face vertical at DIFF_R_IN, outer face leaning
    out from 61.1 to 61.5 (7.6 deg). Sits on the plinth top, 0.6 under the skirt."""
    pts = [(DIFF_R_IN, HALO_Z0), (DIFF_R_OUT_BOT, HALO_Z0), (DIFF_R_OUT_TOP, HALO_Z1), (DIFF_R_IN, HALO_Z1)]
    return revolve_profile(pts)

# =============================================================== BASE SHELL
def sled_pocket_walls(az):
    """Two tangential guide walls and a back wall around one tower, standing on
    the ledge; a cap over the tower keeps the magnet down."""
    w_in = SLED_R_IN - 1.0
    walls = blk(SLED_R_OUT - w_in, 1.2, Z_LEDGE_TOP, Z_SLED_TOP + 0.6, az, (SLED_R_OUT + w_in) / 2, +POCKET_W / 2 + 0.6)
    walls += blk(SLED_R_OUT - w_in, 1.2, Z_LEDGE_TOP, Z_SLED_TOP + 0.6, az, (SLED_R_OUT + w_in) / 2, -POCKET_W / 2 - 0.6)
    walls += blk(SLED_R_OUT - w_in - 1.2, POCKET_W + 2.4, Z_SLED_TOP + 0.3, Z_SLED_TOP + 0.9, az, (SLED_R_OUT - 1.2 + w_in) / 2)
    return walls

def tower_slot(az):
    """Slot through the ledge for a tower (+/- its travel)."""
    return blk(SLED_R_OUT - SLED_R_IN + 0.6, POCKET_W, Z_LEDGE_BOT - 1, Z_LEDGE_TOP + 1, az, (SLED_R_IN + SLED_R_OUT) / 2)

def base_shell():
    s = None
    # plinth ring (dark band) and the floor ring the cam rests on
    s = tube(PLINTH_R_OUT, PLINTH_R_IN, Z_PLATE_TOP, Z_PLINTH_TOP)
    s += tube(RING_R_OUT + 1.0, RISER_R_IN - 1.0, Z_PLATE_TOP, RING_SEAT_Z)         # seat ring the carrier rings rest on (bosses overlap its inner edge)
    # LED wall (LEDs on its outer face) and the ledge the towers/posts stand on
    s += tube(LED_WALL_R_OUT, 54.50, Z_PLINTH_TOP - 0.2, HALO_Z1 + 0.2)
    s += tube(R_LEDGE_OUT, R_LEDGE_IN, Z_LEDGE_BOT, Z_LEDGE_TOP)
    # step wall and inner roof
    s += tube(R_INNER_ROOF, R_LEDGE_IN, Z_LEDGE_TOP - 0.4, Z_INNER_ROOF)
    s += cyl(R_INNER_ROOF, Z_INNER_ROOF_BOT, Z_INNER_ROOF)
    # speaker cradle (stops under the tyre band) and two columns up to the inner roof
    s += tube(SPK_R + 2.0, SPK_R, Z_PLATE_TOP, Z_TYRE0 - 0.4)
    s += tube(SPK_R + 2.0, SPEAKER_APERTURE / 2, Z_PLATE_TOP + SPEAKER_T + 0.4, Z_PLATE_TOP + SPEAKER_T + 1.0)
    for az in (30, 300):
        s += blk(3.0, 4.0, Z_TYRE0 - 0.6, Z_INNER_ROOF_BOT + 0.2, az, SPK_R + 0.5)
    # plate-screw bosses with M3 inserts (low: the tyre sweeps above them)
    for az in PLATE_SCREW_AZ:
        s += zbore(BOSS_D, Z_PLATE_TOP, Z_BOSS_TOP, az, PLATE_SCREW_R)
    (mx, my), (px, py) = drive_geometry(True)
    s += Pos(px, py, Z_PLATE_TOP - 0.01) * Cylinder(1.4, Z_DRIVE_ARM1 + 0.6 - Z_PLATE_TOP, align=(C, C, MN))   # drive arm pivot pin
    s += Pos(px, py, Z_PLATE_TOP - 0.01) * Cylinder(3.5, Z_DRIVE_ARM0 - 0.3 - Z_PLATE_TOP, align=(C, C, MN))   # ... on a boss
    paz, pr = math.degrees(math.atan2(py, px)), math.hypot(px, py)
    s += blk(RISER_R_IN - pr + 2.0, 5.0, Z_PLATE_TOP, Z_PLATE_TOP + 0.8, paz, (pr + RISER_R_IN) / 2)   # bridge to the seat ring
    # three columns tie the seat ring to the ledge (between the rings and the disc-screw heads)
    for az in WHEEL_AZ:
        s += blk(3.2, 4.0, RING_SEAT_Z - 0.2, Z_LEDGE_BOT + 0.2, az, 47.8)
    # sled pockets, disc posts, wheel posts (all on the ledge)
    for az in SLED_AZ:
        s += sled_pocket_walls(az) & cyl(R_LEDGE_OUT, 0, 40)
    for az in DISC_HOLE_AZ:
        s += zbore(DISC_POST_D, Z_LEDGE_TOP - 0.5, Z_DISC_BOT, az, DISC_POST_R)
    for az in WHEEL_AZ:
        s += zbore(WHEEL_POST_D + 2.0, Z_LEDGE_TOP - 0.5, Z_LEDGE_TOP + 2.0, az, WHEEL_AXIS_R)   # foot (r 48.4-55.4)
        s += zbore(WHEEL_POST_D, Z_LEDGE_TOP - 0.5, Z_WHEEL0 - 0.3, az, WHEEL_AXIS_R)
    # encoder mount: a small tower on the ledge at ENC_AZ with a pocket for the sensor board
    s += blk(4.0, 9.0, Z_LEDGE_TOP - 0.5, Z_CODE1 + 0.6, ENC_AZ, R_LEDGE_OUT - ENC_GAP - 2.4)
    # ---- cuts
    s -= tunnel_cut(-1.0)
    s -= rbore(PLUG_JACK_D + 0.6, PORT_R_C + PORT_BOARD_W / 2 - 1, TUNNEL_R_BACK + 2, AZ_PORTS, JACK_AXIS_Z, t=JACK_T_OFF)   # jack plug reaches the recessed jack
    for az in PLATE_SCREW_AZ:                                       # M3 inserts from below
        s -= zbore(INSERT_M3_D, Z_PLATE_TOP - 0.5, Z_PLATE_TOP + INSERT_M3_L + 0.3, az, PLATE_SCREW_R)
    for az in DISC_HOLE_AZ:                                         # disc screws up through the posts
        s -= zbore(2.8, Z_LEDGE_BOT - 1, Z_DISC_BOT + 1, az, DISC_POST_R)
    for az in WHEEL_AZ:                                             # Ø3 pin hole in each wheel post
        s -= zbore(2.9, Z_WHEEL0 - 5.2, Z_WHEEL0 + 1, az, WHEEL_AXIS_R)
    for az in SLED_AZ:
        s -= tower_slot(az)
    s -= blk(ROCKER_PIN_R_A - ROCKER_PIN_R_B + 8, 7.0, Z_PLATE_TOP + 0.4, RING_SEAT_Z + 0.01, ROCKER_AZ, (ROCKER_PIN_R_A + ROCKER_PIN_R_B) / 2)  # rocker clearance in the seat ring
    # the tyre sweeps z Z_TYRE0..Z_TYRE1 out to the bore: clear the ledge and the inner roof there
    (mx, my), _ = drive_geometry(True)
    cx, cy = mx - DRIVE_LIFT / 2 * math.cos(math.radians(DRIVE_AZ)), my - DRIVE_LIFT / 2 * math.sin(math.radians(DRIVE_AZ))
    s -= Pos(cx, cy, Z_TYRE0 - 0.4) * Cylinder(TYRE_SWEEP_R, Z_TYRE1 - Z_TYRE0 + 0.8, align=(C, C, MN))
    s -= Pos(cx, cy, Z_TYRE1 - 0.01) * Cylinder(TYRE_SWEEP_R - 2.0, Z_INNER_ROOF - Z_TYRE1 + 1, align=(C, C, MN))
    s -= cam_motor_pocket()                                                     # cam motor + worm through the seat ring
    s -= sector(WORM_MESH_AZ, WORM_MESH_ARC + 2 * RING_TRAVEL_DEG + 2, RING_R_IN + 1.2, Z_PLATE_TOP - 1, RING_SEAT_Z + 1, r_in=RING_A_TAB_R_IN - 0.6)   # ring A's hanging tab sweeps here
    s -= socket_bay()                                                            # sockets behind the tunnel
    (mx, my), _ = drive_geometry(True)
    s -= Pos(mx - DRIVE_LIFT / 2 * math.cos(math.radians(DRIVE_AZ)), my - DRIVE_LIFT / 2 * math.sin(math.radians(DRIVE_AZ)), Z_PLATE_TOP - 1) * \
        Cylinder(DRIVE_PLATE_HOLE_D / 2 + 0.3, DRIVE_MOTOR_H + 1.6, align=(C, C, MN))   # drive motor clearance in the seat ring
    s -= rbore(LIGHT_SENSOR_HOLE, PLINTH_R_IN - 1, PLINTH_R_OUT + 1, AZ_LIGHT_SENSOR, (Z_PLATE_TOP + Z_PLINTH_TOP) / 2)
    s -= rbore(3.0, LED_WALL_R_IN - 1, LED_WALL_R_OUT + 1, AZ_PORTS + 25, HALO_Z0 + 1.5)    # LED wiring
    # encoder pocket (the sensor looks outward at the code band)
    s -= blk(2.0, 7.0, Z_CODE0 - 0.8, Z_CODE1 + 0.8, ENC_AZ, R_LEDGE_OUT - ENC_GAP - 0.5)
    s += zbore(2.8, Z_PLATE_TOP - 0.01, RING_A_Z0 - 0.2, ROCKER_AZ, ROCKER_PIVOT_R)   # rocker pivot pin (after the cuts), under ring A
    return s

# =============================================================== KNOB BODY
def body_profile():
    """Half-section (r, z) of the knob body, revolved. Skirt + inward flange."""
    rb, rf, rk = R_SKIRT_BORE, R_FLANGE_BORE, R_KNOB
    zs, zft, zc = Z_SKIRT_BOT, Z_FLANGE_TOP, Z_CROWN_BOT - CROWN_SEAT_T
    ra = R_RIDGE_APEX
    pts = [
        (rf, zs), (rk - CH_BOT, zs), (rk, zs + CH_BOT),               # flange underside, lower chamfer
        (rk, zc), (CROWN_REBATE_R, zc), (CROWN_REBATE_R, Z_CROWN_BOT), # crown rebate
        (rb, Z_CROWN_BOT),                                             # skirt bore beside the disc
        (rb, Z_RIDGE1), (ra, Z_RIDGE_MID), (rb, Z_RIDGE0),             # 90 deg V-ridge (1.5 over +/-1.5)
        (rb, zft + 0.3), (rf, zft),                                    # step down to the flange bore (a 2 mm ceiling bridge when printed flange-down)
    ]
    return pts

def knob_body_smooth():
    b = revolve_profile(body_profile())
    # crown screw holes through the skirt wall, heads recessed in the flange underside
    for az in CROWN_SCREW_AZ:
        b -= zbore(CROWN_SCREW_D, Z_SKIRT_BOT - 1, Z_CROWN_BOT + 1, az, CROWN_SCREW_R)
        b -= zbore(CROWN_SCREW_HEAD_D + 0.3, Z_SKIRT_BOT - 1, Z_SKIRT_BOT + CROWN_SCREW_HEAD_H + 0.2, az, CROWN_SCREW_R)
    return b

def peg_holes():
    tool = None
    for i in range(PEG_N):
        h = rbore(PEG_D - 0.10, R_FLANGE_BORE - 0.5, R_FLANGE_BORE + PEG_D, i * 360 / PEG_N, PEG_Z)
        tool = h if tool is None else tool + h
    return tool

def knob_body(knurl=None):
    """Body with peg holes. Knurl via knurl.py (subprocess bands) when KNURL_ON."""
    if (KNURL_ON if knurl is None else knurl):
        return knurl_apply(None)          # cached: knurl + peg holes already cut
    return knob_body_smooth() - peg_holes()

def knurl_apply(b):
    from knurl import apply_knurl
    return apply_knurl(b)

# =============================================================== CROWN
def knob_crown():
    """The rim: reaches in over the display's dead border. Sits in the skirt's
    rebate; six M2 inserts from below."""
    ri, ro, z0, z1 = R_CROWN_IN, R_KNOB, Z_CROWN_BOT - CROWN_SEAT_T, Z_CROWN_TOP
    pts = [(ri + CH_IN, z1), (ro - CH_TOP, z1), (ro, z1 - CH_TOP), (ro, Z_CROWN_BOT - CROWN_SEAT_T + 0.0),
           (CROWN_REBATE_R - GAP_STATIC, z0), (CROWN_REBATE_R - GAP_STATIC, Z_CROWN_BOT), (ri, Z_CROWN_BOT), (ri, z1 - CH_IN)]
    c = revolve_profile(pts)
    for az in CROWN_SCREW_AZ:
        c -= zbore(INSERT_M2_D, Z_CROWN_BOT - CROWN_SEAT_T - 0.5, Z_CROWN_BOT - CROWN_SEAT_T + INSERT_M2_L, az, CROWN_SCREW_R)
    return c

# =============================================================== MAGNET RINGS
def tower_arm(az, zring0, zring1):
    """One L-arm: riser (hangs inside the ring), horizontal leg under the ledge,
    tower rising through the ledge slot holding the magnet at the peg height.
    Magnet pocket open outward with lips; the magnet is loaded from the top."""
    w = SLED_W
    riser = xyblk(RISER_R_IN, RISER_R_OUT, -w / 2, w / 2, zring0, LEG_Z1)
    riser += xyblk(RISER_R_IN, RING_R_IN + 0.6, -w / 2, w / 2, zring0, zring1)     # bridge into its own ring only
    leg = xyblk(RISER_R_IN, SLED_R_IN + 1.0, -w / 2, w / 2, LEG_Z0, LEG_Z1)
    tw = xyblk(SLED_R_IN, SLED_R_OUT, -w / 2, w / 2, LEG_Z0, Z_SLED_TOP)
    t = riser + leg + tw
    t = t & cyl(SLED_R_OUT, RING_A_Z0 - 1, Z_SLED_TOP + 1)          # outer face is cylindrical: 0.4 to the bore at any shift
    t -= xyblk(MAG_FACE_R - MAG_R, MAG_FACE_R + 0.01, -MAG_T / 2, MAG_T / 2, Z_MAG_BOT, Z_SLED_TOP + 1)
    t -= xyblk(MAG_FACE_R - 0.01, SLED_R_OUT + 1, -MAG_T / 2 + MAG_LIP_W, MAG_T / 2 - MAG_LIP_W, Z_MAG_BOT - 0.01, Z_SLED_TOP + 1)
    return Rot(0, 0, az) * t

def ring_a(rot=0.0):
    """Lower ring: arms at 30/150/270, worm teeth on its inner face at 165-195
    (drawn smooth), a radial slot for the rocker pin at r 48. rot = +1.5 deg 'off'."""
    r = tube(RING_R_OUT, RING_R_IN, RING_A_Z0, RING_A_Z1)
    r += sector(WORM_MESH_AZ, WORM_MESH_ARC, RING_R_IN + 0.6, RING_A_TAB_Z0, RING_A_Z1, r_in=RING_A_TAB_R_IN)   # hanging toothed tab
    for i, az in enumerate(SLED_AZ):
        if SLED_GROUP[i] > 0:
            r += tower_arm(az, RING_A_Z0, RING_A_Z1)
    r -= blk(3.6, ROCKER_PIN_D + 0.3, RING_A_Z0 - 1, RING_A_Z1 + 1, ROCKER_AZ, ROCKER_PIN_R_A)
    return Rot(0, 0, rot) * r

def ring_b(rot=0.0):
    """Upper ring: arms at 90/210/330, an inward tab at ROCKER_AZ with a radial
    slot for the rocker's other pin, three feet down to the seat. rot = -1.5 'off'."""
    r = tube(RING_R_OUT, RING_R_IN, RING_B_Z0, RING_B_Z1)
    for i, az in enumerate(SLED_AZ):
        if SLED_GROUP[i] < 0:
            r += tower_arm(az, RING_B_Z0, RING_B_Z1)
    r += sector(ROCKER_AZ, RING_B_TAB_ARC, RING_R_IN + 0.5, RING_B_Z0, RING_B_Z1, r_in=RING_B_TAB_R_IN)
    r -= blk(3.6, ROCKER_PIN_D + 0.3, RING_B_Z0 - 1, RING_B_Z1 + 1, ROCKER_AZ, ROCKER_PIN_R_B)
    for az in RING_B_FEET_AZ:                   # feet: inside ring A, bridged into ring B
        r += blk(1.2, 4.0, RING_SEAT_Z, RING_B_Z1, az, RING_R_IN - 1.7)
        r += blk(3.0, 4.0, RING_B_Z0, RING_B_Z1, az, RING_R_IN - 0.4)
    return Rot(0, 0, rot) * r

def rocker(swing=0.0):
    """Flat bar under the rings on a base pivot pin; pins up into ring A's slot
    (r 48) and ring B's tab slot (r 41). +1.5 deg on A gives -1.5 deg on B."""
    L = ROCKER_PIN_R_A - ROCKER_PIN_R_B
    bar = Pos((ROCKER_PIN_R_A + ROCKER_PIN_R_B) / 2, 0, ROCKER_Z0) * Box(L + 5.0, 5.0, ROCKER_Z1 - ROCKER_Z0, align=(C, C, MN))
    bar -= Pos(ROCKER_PIVOT_R, 0, ROCKER_Z0 - 1) * Cylinder(1.6, 3, align=(C, C, MN))
    for rp, ztop in ((ROCKER_PIN_R_A, RING_A_Z1 - 0.2), (ROCKER_PIN_R_B, RING_B_Z1 - 0.2)):
        bar += Pos(rp, 0, ROCKER_Z1 - 0.01) * Cylinder(ROCKER_PIN_D / 2, ztop - ROCKER_Z1, align=(C, C, MN))
    bar = Pos(ROCKER_PIVOT_R, 0, 0) * Rot(0, 0, swing) * Pos(-ROCKER_PIVOT_R, 0, 0) * bar
    return Rot(0, 0, ROCKER_AZ) * bar

def rocker_swing(state):
    if state == "on":
        return 0.0
    d = math.radians(RING_TRAVEL_DEG) * ROCKER_PIN_R_A
    return math.degrees(math.asin(d / (ROCKER_PIN_R_A - ROCKER_PIVOT_R)))

def ref_magnet(az, shift_deg=0.0):
    m = xyblk(MAG_FACE_R - MAG_R, MAG_FACE_R, -MAG_T / 2, MAG_T / 2, Z_MAG_BOT, Z_MAG_TOP)
    return Rot(0, 0, az + shift_deg) * m

def sled_shift(i, state):
    """Rotation (deg) of magnet i's ring for state 'on' (0) or 'off' (+/-1.5)."""
    return 0.0 if state == "on" else SLED_GROUP[i] * RING_TRAVEL_DEG

# =============================================================== DRIVE ARM
def drive_geometry(engaged=True):
    """Motor centre and pivot in XY. The pivot sits DRIVE_ARM_L along the tangent
    at the motor, so swinging the arm moves the tyre almost purely radially."""
    a = math.radians(DRIVE_AZ)
    mx, my = DRIVE_R * math.cos(a), DRIVE_R * math.sin(a)
    tx, ty = -math.sin(a), math.cos(a)
    px, py = mx - DRIVE_ARM_L * tx, my - DRIVE_ARM_L * ty
    if not engaged:
        dth = DRIVE_LIFT / DRIVE_ARM_L
        ang = math.atan2(my - py, mx - px)
        for sgn in (+1, -1):
            nx, ny = px + DRIVE_ARM_L * math.cos(ang + sgn * dth), py + DRIVE_ARM_L * math.sin(ang + sgn * dth)
            if math.hypot(nx, ny) < math.hypot(mx, my):
                mx, my = nx, ny
                break
    return (mx, my), (px, py)

def drive_plate(engaged=True):
    """The pivot ARM: a flat bar above the motor, pivoting on a base pin; the motor
    hangs from it (three M2 screws), its shaft passes up through it to the tyre;
    a lug beyond the pivot is pushed by the solenoid."""
    (mx, my), (px, py) = drive_geometry(engaged)
    z0, z1 = Z_DRIVE_ARM0, Z_DRIVE_ARM1
    L = math.hypot(mx - px, my - py)
    ang = math.degrees(math.atan2(my - py, mx - px))
    arm = Pos(px, py, z0) * Rot(0, 0, ang) * (Pos(L / 2, 0, 0) * Box(L, 10.0, z1 - z0, align=(C, C, MN)))
    arm += Pos(px, py, z0) * Cylinder(4.0, z1 - z0, align=(C, C, MN))
    arm += Pos(mx, my, z0) * Cylinder(DRIVE_MOTOR_D / 2 + 0.7, z1 - z0, align=(C, C, MN))
    # extension past the motor toward SOLENOID_AZ, with a lug hanging down for the solenoid's plunger
    sa = math.radians(SOLENOID_AZ)
    lr = DRIVE_R + 3.0
    lx, ly = lr * math.cos(sa), lr * math.sin(sa)
    ext_ang = math.degrees(math.atan2(ly - my, lx - mx))
    ext_L = math.hypot(lx - mx, ly - my)
    arm += Pos(mx, my, z0) * Rot(0, 0, ext_ang) * (Pos(ext_L / 2, 0, 0) * Box(ext_L, 6.0, z1 - z0, align=(C, C, MN)))
    zl = Z_PLATE_TOP + 0.6
    arm += Pos(lx, ly, zl) * Rot(0, 0, SOLENOID_AZ) * Box(2.0, 6.0, z1 - zl, align=(C, C, MN))
    arm -= Pos(px, py, z0 - 1) * Cylinder(1.6, 4, align=(C, C, MN))                    # pivot pin
    arm -= Pos(mx, my, z0 - 1) * Cylinder(3.5, 4, align=(C, C, MN))                    # shaft / bearing boss
    for k in range(3):                                                                # motor screws
        t = math.radians(ang + 90 + 120 * k)
        arm -= Pos(mx + 6.0 * math.cos(t), my + 6.0 * math.sin(t), z0 - 1) * Cylinder(1.1, 4, align=(C, C, MN))
    return arm, (mx, my)

# =============================================================== TYRE HUB
def tyre_hub():
    """Printed disc on the drive motor's shaft carrying a 2 mm-section O-ring
    (the tyre). Groove root at TYRE_D/2 - 1.8; Ø5 bore, M2 grub."""
    ro = TYRE_D / 2 - 1.8
    h = revolve_profile([(2.5, 0), (ro, 0), (ro, 0.4), (ro - 1.2, 1.0), (ro, 1.6), (ro, TYRE_T), (2.5, TYRE_T)])
    h = h - Pos(0, 0, -1) * Cylinder(2.55, 5, align=(C, C, MN))
    h = h - Pos(0, 0, TYRE_T / 2) * Rot(0, 90, 0) * Cylinder(0.85, ro, align=(C, C, MN))   # grub hole
    return h

# =============================================================== WHEEL COLLAR
def wheel_collar(az=None):
    """Turned (printed for the fit check) V-collar pressed over a 623ZZ: Ø12, 90 deg
    V-groove 1.5 deep centred on the width."""
    ro, ri, w, g = WHEEL_OD / 2, 5.0 + 0.05, WHEEL_W, WHEEL_GROOVE_D
    pts = [(ri, 0), (ro, 0), (ro, w / 2 - g), (ro - g, w / 2), (ro, w / 2 + g), (ro, w), (ri, w)]   # 90 deg V, 0.7 rims
    c = revolve_profile(pts)
    if az is None:
        return c
    return polar(az, WHEEL_AXIS_R, Z_WHEEL0) * c

# =============================================================== REFERENCES
def ref_disc():
    d = cyl(R_DISC, Z_DISC_BOT, Z_DISC_TOP)
    return d
def ref_pcb():
    return xyblk(-PCB_L / 2, PCB_L / 2, -PCB_W / 2, PCB_W / 2, Z_PCB_BOT, Z_PCB_TOP)
def ref_components():
    return xyblk(-PCB_L / 2 + 2, PCB_L / 2 - 2, -PCB_W / 2 + 2, PCB_W / 2 - 2, Z_COMP_BOT, Z_PCB_BOT)
def ref_bearings():
    out = None
    for az in WHEEL_AZ:
        b = polar(az, WHEEL_AXIS_R, Z_WHEEL0) * (Cylinder(5.0, WHEEL_W, align=(C, C, MN)) - Cylinder(1.5, WHEEL_W, align=(C, C, MN)))
        out = b if out is None else out + b
    return out
def ref_wheel_screws():
    """Ø3 dowel pins pressed 5 mm into the posts; the V-ridge keeps the wheels on."""
    out = None
    for az in WHEEL_AZ:
        b = zbore(3.0, Z_WHEEL0 - 5.0, Z_WHEEL1 - 0.2, az, WHEEL_AXIS_R)
        out = b if out is None else out + b
    return out
def ref_magnets(state="on"):
    out = None
    for i, az in enumerate(SLED_AZ):
        m = ref_magnet(az, sled_shift(i, state))
        out = m if out is None else out + m
    return out
def ref_pegs():
    out = None
    for i in range(PEG_N):
        a = i * 360 / PEG_N
        b = polar(a, R_FLANGE_BORE + PEG_D / 2, PEG_Z) * Sphere(PEG_D / 2)
        out = b if out is None else out + b
    return out
def ref_n20():
    """The Ø8 gearmotor for the carrier rings (kept under the old name)."""
    return tcyl(CAMMOTOR_D, CAMMOTOR_L, CAMMOTOR_AZ, WORM_AXIS_R, CAMMOTOR_D / 2, t=0.0)
def ref_worm():
    return tcyl(WORM_D, WORM_L, CAMMOTOR_AZ, WORM_AXIS_R, CAMMOTOR_D / 2, t=-CAMMOTOR_L / 2 - WORM_L / 2 - 1.0)
def ref_drive_motor(engaged=True):
    (mx, my), _ = drive_geometry(engaged)
    return Pos(mx, my, 0.0) * Cylinder(DRIVE_MOTOR_D / 2, DRIVE_MOTOR_H, align=(C, C, MN)) + \
        Pos(mx, my, DRIVE_MOTOR_H) * Cylinder(2.5, Z_TYRE1 - DRIVE_MOTOR_H, align=(C, C, MN))
def ref_tyre(engaged=True):
    (mx, my), _ = drive_geometry(engaged)
    return Pos(mx, my, Z_TYRE0) * Cylinder(TYRE_D / 2, TYRE_T, align=(C, C, MN))
def ref_solenoid():
    """Push solenoid on the floor, radial at SOLENOID_AZ, its plunger pressing the
    arm's hanging lug outward (engage); a spring returns the arm (lift-off)."""
    r1 = DRIVE_R + 3.0 - 1.5 - 2.0
    return rbore(SOLENOID_D, r1 - SOLENOID_L, r1, SOLENOID_AZ, SOLENOID_D / 2 + Z_PLATE_TOP + 0.3)
def ref_encoder():
    return blk(1.4, 6.0, Z_CODE0, Z_CODE1, ENC_AZ, R_LEDGE_OUT - ENC_GAP - 0.7)
def ref_lra():
    return polar(LRA_AZ, LRA_R, Z_INNER_ROOF_BOT - LRA_H) * Cylinder(LRA_D / 2, LRA_H, align=(C, C, MN))
def ref_speaker():
    return cyl(SPEAKER_D / 2, Z_PLATE_TOP, Z_PLATE_TOP + SPEAKER_T)
def ref_supercaps():
    out = None
    for az in (SUPERCAP_AZ, SUPERCAP_AZ2):
        c = rbore(SUPERCAP_D, SUPERCAP_R - SUPERCAP_L / 2, SUPERCAP_R + SUPERCAP_L / 2, az, Z_PLATE_TOP + SUPERCAP_D / 2)
        out = c if out is None else out + c
    return out
def ref_port_board():
    return blk(PORT_BOARD_W, PORT_BOARD_L, PORT_BOARD_Z0, PORT_BOARD_Z0 + PORT_BOARD_T, AZ_PORTS, PORT_R_C, t=PORT_BOARD_T_OFF)
def ref_usbc():
    zc = PORT_BOARD_Z0 + PORT_BOARD_T / 2
    return blk(USBC_DEPTH, USBC_W, zc - USBC_H / 2, zc + USBC_H / 2, AZ_PORTS, PORT_R_C + PORT_BOARD_W / 2 - USBC_DEPTH / 2 + 1.0, t=USBC_T_OFF)
def ref_jack():
    return blk(JACK_BODY_L, JACK_BODY_W, JACK_AXIS_Z - JACK_BODY_H / 2, JACK_AXIS_Z + JACK_BODY_H / 2, AZ_PORTS, PORT_R_C + PORT_BOARD_W / 2 - JACK_BODY_L / 2, t=JACK_T_OFF)
def ref_usbc_plug():
    zc = PORT_BOARD_Z0 + PORT_BOARD_T / 2
    return blk(PLUG_USBC_L, PLUG_USBC_W, zc - PLUG_USBC_H / 2, zc + PLUG_USBC_H / 2, AZ_PORTS, TUNNEL_R_BACK + 0.5 + PLUG_USBC_L / 2, t=USBC_T_OFF)
def ref_jack_plug():
    return rbore(PLUG_JACK_D, TUNNEL_R_BACK + 0.3, TUNNEL_R_BACK + 0.5 + PLUG_JACK_L, AZ_PORTS, JACK_AXIS_Z, t=JACK_T_OFF)
def ref_pad():
    return frustum(PLATE_R_BOT - 0.3, PLATE_R_BOT, -PAD_T, 0.0) - tunnel_cut(-3.0)
def ref_led_board():
    return tube(LED_WALL_R_OUT + LED_BOARD_T, LED_WALL_R_OUT, HALO_Z0 + 0.3, HALO_Z1 - 0.3)
def ref_disc_screws():
    out = None
    for az in DISC_HOLE_AZ:
        b = zbore(2.5, Z_LEDGE_BOT - 2.0, Z_DISC_BOT + 4.0, az, DISC_POST_R) + zbore(4.5, Z_LEDGE_BOT - 2.0, Z_LEDGE_BOT - 0.1, az, DISC_POST_R)
        out = b if out is None else out + b
    return out
def ref_crown_screws():
    out = None
    for az in CROWN_SCREW_AZ:
        b = zbore(2.0, Z_SKIRT_BOT + 0.2, Z_CROWN_BOT - CROWN_SEAT_T + INSERT_M2_L - 0.5, az, CROWN_SCREW_R) + \
            zbore(CROWN_SCREW_HEAD_D, Z_SKIRT_BOT + 0.2, Z_SKIRT_BOT + 0.2 + CROWN_SCREW_HEAD_H, az, CROWN_SCREW_R)
        out = b if out is None else out + b
    return out

# =============================================================== ASSEMBLY
def made_parts(state="on", knurl=None):
    parts = {
        "base_plate": base_plate(),
        "base_shell": base_shell(),
        "halo_diffuser": halo_diffuser(),
        "knob_body": knob_body(knurl),
        "knob_crown": knob_crown(),
        "ring_a": ring_a(0.0 if state == "on" else +RING_TRAVEL_DEG),
        "ring_b": ring_b(0.0 if state == "on" else -RING_TRAVEL_DEG),
        "rocker": rocker(rocker_swing(state)),
        "drive_plate": drive_plate(state != "on")[0],
    }
    for az in WHEEL_AZ:
        parts[f"collar_{az}"] = wheel_collar(az)
    (mx, my), _ = drive_geometry(state != "on")
    parts["tyre_hub"] = Pos(mx, my, Z_TYRE0) * tyre_hub()
    return parts

def ref_parts(state="on"):
    eng = state == "on"
    return {
        "disc": ref_disc(), "pcb": ref_pcb(), "components": ref_components(),
        "bearings": ref_bearings(), "wheel_screws": ref_wheel_screws(),
        "magnets": ref_magnets(state), "pegs": ref_pegs(),
        "n20": ref_n20(), "worm": ref_worm(),
        "drive_motor": ref_drive_motor(not eng), "tyre": ref_tyre(not eng), "solenoid": ref_solenoid(),
        "encoder": ref_encoder(), "lra": ref_lra(), "speaker": ref_speaker(), "supercaps": ref_supercaps(),
        "port_board": ref_port_board(), "usbc": ref_usbc(), "jack": ref_jack(),
        "usbc_plug": ref_usbc_plug(), "jack_plug": ref_jack_plug(),
        "pad": ref_pad(), "led_board": ref_led_board(), "disc_screws": ref_disc_screws(), "crown_screws": ref_crown_screws(),
    }
